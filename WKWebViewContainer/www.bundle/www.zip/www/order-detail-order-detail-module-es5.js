function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["order-detail-order-detail-module"], {
  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/order-detail/order-detail.page.html":
  /*!*************************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/order-detail/order-detail.page.html ***!
    \*************************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppPagesOrderDetailOrderDetailPageHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-header>\n  <ion-toolbar color=\"ysw\">\n    <ion-buttons slot=\"start\">\n      <ion-back-button></ion-back-button>\n    </ion-buttons>\n    <ion-title>订单详情</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <ion-header collapse=\"condense\">\n    <ion-toolbar color=\"ysw\">\n      <ion-title size=\"large\">订单详情</ion-title>\n    </ion-toolbar>\n  </ion-header>\n\n  <skeleton [loading]=\"loading\">\n    <ion-list>\n      <ion-card>\n        <ion-card-header class=\"m-b-5\">\n          <ion-card-title class=\"flex ion-justify-content-between ion-align-items-center\">\n            <ion-label>\n              <ion-text>{{order.ipOrderNo}}</ion-text>\n              <ion-icon class=\"m-l-5\" src=\"assets/imgs/mat/mat-meituan.svg\" *ngIf=\"order.orderRefer===4\"></ion-icon>\n            </ion-label>\n            <ion-badge [color]=\"genStatusColor(order.orderStatusCode)\" style=\"flex-shrink: 0;\">{{order.orderStatusName}}\n            </ion-badge>\n          </ion-card-title>\n          <ion-card-subtitle class=\"flex ion-justify-content-between ion-align-items-center m-t-5\">\n            <ion-label>{{order.matInfo.matName}} <small>{{order.matInfo.matSerial}}</small></ion-label>\n            <ion-label *ngIf=\"order.outOrderSeq\">{{order.outOrderSeq}}号单</ion-label>\n          </ion-card-subtitle>\n        </ion-card-header>\n      </ion-card>\n\n      <ion-card *ngIf=\"order.consignee\">\n        <split-label class=\"\">配送信息</split-label>\n        <ion-card-content class=\"m-b-10\">\n          <div *ngIf=\"order.outOrderId\" class=\"flex ion-justify-content-between ion-align-items-center content-line\">\n            <ion-label color=\"dark font-non-bold\">外卖订单号</ion-label>\n            <ion-label>{{order.outOrderId}}</ion-label>\n          </div>\n          <div class=\"flex ion-justify-content-between ion-align-items-center content-line\">\n            <ion-label color=\"dark font-non-bold\">收货人员</ion-label>\n            <ion-label color=\"dark font-non-bold\">{{order.consignee}} {{order.consigneeCellphone}}</ion-label>\n          </div>\n          <div class=\"flex ion-justify-content-between ion-align-items-center content-line\">\n            <ion-label color=\"dark font-non-bold\" class=\"w-120\">收货地址</ion-label>\n            <ion-label color=\"dark font-non-bold\">{{order.deliveryAddressDetails}}</ion-label>\n          </div>\n          <div *ngIf=\"order.deliveryman||order.deliverymanCellphone\"\n            class=\"flex ion-justify-content-between ion-align-items-center content-line\">\n            <ion-label color=\"dark font-non-bold\">配送人员</ion-label>\n            <ion-label color=\"dark font-non-bold\">{{order.deliveryman || '-'}} <ion-text color=\"primary\"\n                (click)=\"callNumber(order.deliverymanCellphone, order)\">\n                {{order.deliverymanCellphone || '-'}}</ion-text>\n            </ion-label>\n          </div>\n        </ion-card-content>\n      </ion-card>\n\n      <ion-card>\n        <split-label class=\"\">商品详情</split-label>\n        <ion-card-content>\n          <ng-container *ngFor=\"let goods of order.goodsInfo;last as isLastItem\">\n            <ion-item lines=\"none\" class=\"card-item p-b-10\">\n              <ion-thumbnail slot=\"start\">\n                <ion-img [src]=\"goods.goodsThumb\"></ion-img>\n              </ion-thumbnail>\n              <ion-label style=\"width: calc(100% - 100px);\">\n                <ion-label color=\"dark\" class=\"ion-text-wrap\">{{goods.brandName || ''}} {{goods.goodsName}}</ion-label>\n                <ion-label class=\"ion-text-wrap\">{{'规格：' + goods.goodsPackage}}</ion-label>\n                <ion-label class=\"ion-text-wrap\">{{'厂商：' + goods.mfrName}}</ion-label>\n                <ion-label *ngIf=\"goods.batchNo\" class=\"ion-text-wrap\">批号：{{goods.batchNo}}</ion-label>\n                <ion-label *ngIf=\"goods.expireDate\" class=\"ion-text-wrap\">效期：{{goods.expireDate| date: 'yyyy-MM-dd'}}\n                </ion-label>\n                <ion-label class=\"flex ion-justify-content-between ion-align-items-center\">\n                  <ion-label class=\"flex ion-justify-content-start ion-text-wrap\">\n                    价格：<ion-label color=\"danger\">{{goods.goodsPrice| currency: '￥'}}</ion-label>\n                  </ion-label>\n                  <ion-label class=\"ion-text-wrap\">{{'x ' + goods.quantity}}</ion-label>\n                </ion-label>\n              </ion-label>\n            </ion-item>\n          </ng-container>\n        </ion-card-content>\n      </ion-card>\n\n      <ion-card>\n        <split-label class=\"\">结算信息</split-label>\n        <ion-card-content>\n          <div class=\"flex ion-justify-content-between ion-align-items-center content-line\">\n            <ion-label color=\"dark font-non-bold\">商品总价</ion-label>\n            <ion-label color=\"danger font-non-bold\">{{order.totalAmount| currency: '￥'}}</ion-label>\n          </div>\n          <div *ngIf=\"order.serviceFee\" class=\"flex ion-justify-content-between ion-align-items-center content-line\">\n            <ion-label color=\"dark font-non-bold\">服务费</ion-label>\n            <ion-label color=\"danger font-non-bold\">{{order.serviceFee| currency: '￥'}}</ion-label>\n          </div>\n          <div *ngIf=\"order.deliveryFee\" class=\"flex ion-justify-content-between ion-align-items-center content-line\">\n            <ion-label color=\"dark font-non-bold\">配送费</ion-label>\n            <ion-label color=\"danger font-non-bold\">{{order.deliveryFee| currency: '￥'}}</ion-label>\n          </div>\n          <div *ngIf=\"order.packageFee\" class=\"flex ion-justify-content-between ion-align-items-center content-line\">\n            <ion-label color=\"dark font-non-bold\">包装费</ion-label>\n            <ion-label color=\"danger font-non-bold\">{{order.packageFee| currency: '￥'}}</ion-label>\n          </div>\n          <div *ngIf=\"order.deductionAmount\"\n            class=\"flex ion-justify-content-between ion-align-items-center content-line\">\n            <ion-label color=\"dark font-non-bold\">优惠券</ion-label>\n            <ion-label color=\"danger font-non-bold\">-{{order.deductionAmount| currency: '￥'}}</ion-label>\n          </div>\n          <div *ngIf=\"order.refundAmount\" class=\"flex ion-justify-content-between ion-align-items-center content-line\">\n            <ion-label color=\"dark font-non-bold\">退款</ion-label>\n            <ion-label color=\"danger font-non-bold\">-{{order.refundAmount| currency: '￥'}}</ion-label>\n          </div>\n          <div class=\"flex ion-justify-content-between ion-align-items-center content-line\">\n            <ion-label color=\"dark\">实际支付</ion-label>\n            <ion-label color=\"danger\" class=\"text-large\">{{order.actualTotalAmount| currency: '￥'}}</ion-label>\n          </div>\n        </ion-card-content>\n      </ion-card>\n\n      <ion-card>\n        <split-label class=\"\">支付信息</split-label>\n\n        <ion-card-content>\n          <div class=\"flex ion-justify-content-between ion-align-items-center content-line\">\n            <ion-label class=\"dark font-non-bold\">支付方式</ion-label>\n            <ion-label>\n              <ng-container [ngSwitch]=\"order.client\">\n                <ng-container *ngSwitchCase=\"'H5_ALIPAY'\">\n                  <svg t=\"1584424856410\" class=\"icon\" viewBox=\"0 0 1325 1024\" version=\"1.1\"\n                    xmlns=\"http://www.w3.org/2000/svg\" p-id=\"2099\" width=\"30\" height=\"30\">\n                    <path\n                      d=\"M240.941176 512c0 233.411765 188.235294 421.647059 421.647059 421.647059s421.647059-188.235294 421.647059-421.647059S896 90.352941 662.588235 90.352941 240.941176 278.588235 240.941176 512z\"\n                      fill=\"#5A9EF7\" p-id=\"2100\"></path>\n                    <path\n                      d=\"M751.435294 564.705882s15.058824-21.082353 30.117647-63.247058c16.564706-42.164706 18.070588-66.258824 18.070588-66.258824l-120.470588-1.505882v-40.658824l146.070588-1.505882v-30.117647H677.647059v-66.258824h-72.282353V361.411765H466.823529v30.117647l137.035295-1.505883v45.176471h-108.42353v24.094118h225.882353c-1.505882 15.058824-6.023529 28.611765-10.541176 42.164706-9.035294 22.588235-18.070588 43.670588-18.070589 43.670588s-105.411765-37.647059-162.635294-37.647059c-55.717647 0-123.482353 22.588235-131.011764 87.341176-6.023529 64.752941 31.623529 100.894118 85.835294 112.941177 52.705882 12.047059 102.4 0 146.070588-21.082353 43.670588-21.082353 85.835294-69.270588 85.835294-69.270588l224.376471 109.929411s13.552941-21.082353 24.094117-40.658823c7.529412-13.552941 13.552941-28.611765 19.576471-42.164706l-233.411765-79.811765z m-231.905882 106.917647c-79.811765 0-94.870588-39.152941-94.870588-66.258823 0-27.105882 16.564706-58.729412 84.329411-63.247059 66.258824-4.517647 158.117647 48.188235 158.117647 48.188235s-67.764706 81.317647-147.57647 81.317647z\"\n                      fill=\"#FFFFFF\" p-id=\"2101\"></path>\n                  </svg>\n                </ng-container>\n                <ng-container *ngSwitchCase=\"'H5_WECHAT'\">\n                  <svg t=\"1584426309362\" class=\"icon\" viewBox=\"0 0 1024 1024\" version=\"1.1\"\n                    xmlns=\"http://www.w3.org/2000/svg\" p-id=\"2947\" width=\"20\" height=\"20\">\n                    <path\n                      d=\"M0 485.324264a511.945427 485.324264 0 1 0 1023.890853 0 511.945427 485.324264 0 1 0-1023.890853 0Z\"\n                      fill=\"#FFFFFF\" p-id=\"2948\"></path>\n                    <path\n                      d=\"M390.102415 644.539292c-61.433451 36.860071-70.136523-20.989762-70.136523-20.989762L243.174078 430.034158c-29.692835-92.150177 25.597271-41.46758 25.597271-41.467579s47.098979 38.907852 83.447105 62.457342c35.83618 23.54949 76.791814 7.167236 76.791814 7.167236l502.218463-250.853259C838.054663 81.399323 684.982981 0 511.945427 0 229.351551 0 0 217.064861 0 485.324264c0 154.095573 75.767923 291.296948 194.027317 380.375452L172.525609 998.293582s-10.238909 38.907852 25.597271 20.989762c24.57338-12.28669 87.030723-56.313997 124.402739-82.935159 60.40956 23.037544 124.402739 34.300344 189.419808 34.300344 282.593875 0 511.945427-217.064861 511.945426-485.324265 0-77.815705-19.453926-151.023901-53.75427-216.04097C810.40961 373.720161 438.225285 615.870348 390.102415 644.539292z\"\n                      fill=\"#41B035\" p-id=\"2949\"></path>\n                  </svg>\n                </ng-container>\n                <ng-container *ngSwitchCase=\"'XCX'\">\n                  <svg t=\"1584426351148\" class=\"icon\" viewBox=\"0 0 1024 1024\" version=\"1.1\"\n                    xmlns=\"http://www.w3.org/2000/svg\" p-id=\"3841\" width=\"20\" height=\"20\">\n                    <path\n                      d=\"M512 0C229.2224 0 0 229.2224 0 512s229.2224 512 512 512 512-229.2224 512-512S794.7776 0 512 0z\"\n                      fill=\"#55B737\" p-id=\"3842\"></path>\n                    <path\n                      d=\"M691.456 554.2912s-71.0144 5.7344-54.528-54.1696c-2.3552-17.6128 86.528-58.4192 74.752-114.7904-18.8416-66.9184-128.2048-86.4768-156.5696-2.3552v266.0864c1.1776 37.376-72.8576 160.0512-225.9968 108.3392 0 0-102.2976-43.6224-96.6144-153.4976 4.5056-49.8176 51.6096-110.7968 104.4992-130.8672 58.8288-16.384 80.384 41.8816 54.528 67.7376-18.7904 9.3696-134.656 57.7024-54.528 135.3728 43.52 43.4688 116.4288 15.9744 134.0416-25.9072 2.3552-29.3376 2.304-242.5856 2.304-271.9744 0-29.3376 87.296-186.2144 246.5792-97.1264 0 0 179.2 104.4992-28.4672 273.152z\"\n                      fill=\"#FFFFFF\" p-id=\"3843\"></path>\n                  </svg>\n                </ng-container>\n              </ng-container>\n            </ion-label>\n          </div>\n          <div class=\"flex ion-justify-content-between ion-align-items-center content-line\">\n            <ion-label color=\"dark font-non-bold\">交易流水号</ion-label>\n            <ion-label color=\"medium\">{{order.paymentInfo.paymentNo}}</ion-label>\n          </div>\n          <!--\n          <div class=\"flex ion-justify-content-between ion-align-items-center content-line\">\n            <ion-label color=\"dark font-non-bold\">支付账户</ion-label>\n            <ion-label color=\"medium\">{{order.paymentInfo.paidBy}}</ion-label>\n          </div>\n          -->\n          <div class=\"flex ion-justify-content-between ion-align-items-center content-line\">\n            <ion-label color=\"dark font-non-bold\">支付时间</ion-label>\n            <ion-label color=\"medium\">\n              {{order.paymentInfo.paymentDate| date: 'yyyy-MM-dd HH:mm:ss'}}</ion-label>\n          </div>\n        </ion-card-content>\n      </ion-card>\n\n      <ion-card *ngIf=\"order.internalComments\">\n        <split-label class=\"\">内部评论</split-label>\n        <ion-card-content>\n          <ion-label color=\"medium\" style=\"font-size: 0.9em;\">{{order.internalComments}}</ion-label>\n        </ion-card-content>\n      </ion-card>\n    </ion-list>\n  </skeleton>\n</ion-content>";
    /***/
  },

  /***/
  "./src/app/pages/order-detail/order-detail.module.ts":
  /*!***********************************************************!*\
    !*** ./src/app/pages/order-detail/order-detail.module.ts ***!
    \***********************************************************/

  /*! exports provided: OrderDetailPageModule */

  /***/
  function srcAppPagesOrderDetailOrderDetailModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "OrderDetailPageModule", function () {
      return OrderDetailPageModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/fesm2015/common.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/fesm2015/forms.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
    /* harmony import */


    var _order_detail_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ./order-detail.page */
    "./src/app/pages/order-detail/order-detail.page.ts");
    /* harmony import */


    var _module_index__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
    /*! ../module/index */
    "./src/app/pages/module/index.ts");

    var OrderDetailPageModule = function OrderDetailPageModule() {
      _classCallCheck(this, OrderDetailPageModule);
    };

    OrderDetailPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"], _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild([{
        path: '',
        component: _order_detail_page__WEBPACK_IMPORTED_MODULE_6__["OrderDetailPage"]
      }]), _module_index__WEBPACK_IMPORTED_MODULE_7__["StringSecurityModule"], _module_index__WEBPACK_IMPORTED_MODULE_7__["SplitLabelModule"], _module_index__WEBPACK_IMPORTED_MODULE_7__["SkeletonModule"]],
      declarations: [_order_detail_page__WEBPACK_IMPORTED_MODULE_6__["OrderDetailPage"]]
    })], OrderDetailPageModule);
    /***/
  },

  /***/
  "./src/app/pages/order-detail/order-detail.page.scss":
  /*!***********************************************************!*\
    !*** ./src/app/pages/order-detail/order-detail.page.scss ***!
    \***********************************************************/

  /*! exports provided: default */

  /***/
  function srcAppPagesOrderDetailOrderDetailPageScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "ion-card-content {\n  padding: 0 10px 10px 15px;\n}\n\nion-card:first-child {\n  margin-top: 15px;\n}\n\nion-card {\n  margin-bottom: 15px;\n  margin-top: 15px;\n}\n\nion-card:last-child {\n  margin-bottom: 20px;\n}\n\nion-card-subtitle ion-label {\n  font-size: 1.1em;\n}\n\nion-label[color=dark] {\n  font-size: 14px !important;\n}\n\n.order-date-subtitle {\n  margin-top: 6px;\n  font-size: 0.9em;\n  color: var(--ion-color-medium-tint);\n}\n\nion-item.card-item {\n  --padding-start: 0px;\n  --inner-padding-end: 0px;\n}\n\nion-thumbnail {\n  max-width: 90px;\n  width: 90px;\n  height: 90px;\n}\n\nion-item ion-label.ion-text-wrap {\n  font-size: 13px;\n  margin-top: 2px;\n}\n\nion-item:first-child {\n  margin-top: 10px !important;\n  border-bottom: solid 1px #eee !important;\n}\n\nion-label {\n  margin-top: 0px;\n  margin-bottom: 0px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Vc2Vycy9jaGFubmluZy9EZXNrdG9wL3lzdy1hcHAtc2VydmljZTQvc3JjL2FwcC9wYWdlcy9vcmRlci1kZXRhaWwvb3JkZXItZGV0YWlsLnBhZ2Uuc2NzcyIsInNyYy9hcHAvcGFnZXMvb3JkZXItZGV0YWlsL29yZGVyLWRldGFpbC5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSx5QkFBQTtBQ0NGOztBRENBO0VBQ0UsZ0JBQUE7QUNFRjs7QURBQTtFQUNFLG1CQUFBO0VBQ0EsZ0JBQUE7QUNHRjs7QUREQTtFQUNFLG1CQUFBO0FDSUY7O0FERkE7RUFDRSxnQkFBQTtBQ0tGOztBREhBO0VBQ0UsMEJBQUE7QUNNRjs7QURKQTtFQUNFLGVBQUE7RUFDQSxnQkFBQTtFQUNBLG1DQUFBO0FDT0Y7O0FETEE7RUFDRSxvQkFBQTtFQUNBLHdCQUFBO0FDUUY7O0FETkE7RUFDRSxlQUFBO0VBQ0EsV0FBQTtFQUNBLFlBQUE7QUNTRjs7QURQQTtFQUNFLGVBQUE7RUFDQSxlQUFBO0FDVUY7O0FEUkE7RUFDRSwyQkFBQTtFQUNBLHdDQUFBO0FDV0Y7O0FEVEE7RUFDRSxlQUFBO0VBQ0Esa0JBQUE7QUNZRiIsImZpbGUiOiJzcmMvYXBwL3BhZ2VzL29yZGVyLWRldGFpbC9vcmRlci1kZXRhaWwucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiaW9uLWNhcmQtY29udGVudCB7XG4gIHBhZGRpbmc6IDAgMTBweCAxMHB4IDE1cHg7XG59XG5pb24tY2FyZDpmaXJzdC1jaGlsZCB7XG4gIG1hcmdpbi10b3A6IDE1cHg7XG59XG5pb24tY2FyZCB7XG4gIG1hcmdpbi1ib3R0b206IDE1cHg7XG4gIG1hcmdpbi10b3A6IDE1cHg7XG59XG5pb24tY2FyZDpsYXN0LWNoaWxkIHtcbiAgbWFyZ2luLWJvdHRvbTogMjBweDtcbn1cbmlvbi1jYXJkLXN1YnRpdGxlIGlvbi1sYWJlbCB7XG4gIGZvbnQtc2l6ZTogMS4xZW07XG59XG5pb24tbGFiZWxbY29sb3I9XCJkYXJrXCJdIHtcbiAgZm9udC1zaXplOiAxNHB4ICFpbXBvcnRhbnQ7XG59XG4ub3JkZXItZGF0ZS1zdWJ0aXRsZSB7XG4gIG1hcmdpbi10b3A6IDZweDtcbiAgZm9udC1zaXplOiAwLjllbTtcbiAgY29sb3I6IHZhcigtLWlvbi1jb2xvci1tZWRpdW0tdGludCk7XG59XG5pb24taXRlbS5jYXJkLWl0ZW0ge1xuICAtLXBhZGRpbmctc3RhcnQ6IDBweDtcbiAgLS1pbm5lci1wYWRkaW5nLWVuZDogMHB4O1xufVxuaW9uLXRodW1ibmFpbCB7XG4gIG1heC13aWR0aDogOTBweDtcbiAgd2lkdGg6IDkwcHg7XG4gIGhlaWdodDogOTBweDtcbn1cbmlvbi1pdGVtIGlvbi1sYWJlbC5pb24tdGV4dC13cmFwIHtcbiAgZm9udC1zaXplOiAxM3B4O1xuICBtYXJnaW4tdG9wOiAycHg7XG59XG5pb24taXRlbTpmaXJzdC1jaGlsZCB7XG4gIG1hcmdpbi10b3A6IDEwcHggIWltcG9ydGFudDtcbiAgYm9yZGVyLWJvdHRvbTogc29saWQgMXB4ICNlZWUgIWltcG9ydGFudDtcbn1cbmlvbi1sYWJlbCB7XG4gIG1hcmdpbi10b3A6IDBweDtcbiAgbWFyZ2luLWJvdHRvbTogMHB4O1xufVxuIiwiaW9uLWNhcmQtY29udGVudCB7XG4gIHBhZGRpbmc6IDAgMTBweCAxMHB4IDE1cHg7XG59XG5cbmlvbi1jYXJkOmZpcnN0LWNoaWxkIHtcbiAgbWFyZ2luLXRvcDogMTVweDtcbn1cblxuaW9uLWNhcmQge1xuICBtYXJnaW4tYm90dG9tOiAxNXB4O1xuICBtYXJnaW4tdG9wOiAxNXB4O1xufVxuXG5pb24tY2FyZDpsYXN0LWNoaWxkIHtcbiAgbWFyZ2luLWJvdHRvbTogMjBweDtcbn1cblxuaW9uLWNhcmQtc3VidGl0bGUgaW9uLWxhYmVsIHtcbiAgZm9udC1zaXplOiAxLjFlbTtcbn1cblxuaW9uLWxhYmVsW2NvbG9yPWRhcmtdIHtcbiAgZm9udC1zaXplOiAxNHB4ICFpbXBvcnRhbnQ7XG59XG5cbi5vcmRlci1kYXRlLXN1YnRpdGxlIHtcbiAgbWFyZ2luLXRvcDogNnB4O1xuICBmb250LXNpemU6IDAuOWVtO1xuICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLW1lZGl1bS10aW50KTtcbn1cblxuaW9uLWl0ZW0uY2FyZC1pdGVtIHtcbiAgLS1wYWRkaW5nLXN0YXJ0OiAwcHg7XG4gIC0taW5uZXItcGFkZGluZy1lbmQ6IDBweDtcbn1cblxuaW9uLXRodW1ibmFpbCB7XG4gIG1heC13aWR0aDogOTBweDtcbiAgd2lkdGg6IDkwcHg7XG4gIGhlaWdodDogOTBweDtcbn1cblxuaW9uLWl0ZW0gaW9uLWxhYmVsLmlvbi10ZXh0LXdyYXAge1xuICBmb250LXNpemU6IDEzcHg7XG4gIG1hcmdpbi10b3A6IDJweDtcbn1cblxuaW9uLWl0ZW06Zmlyc3QtY2hpbGQge1xuICBtYXJnaW4tdG9wOiAxMHB4ICFpbXBvcnRhbnQ7XG4gIGJvcmRlci1ib3R0b206IHNvbGlkIDFweCAjZWVlICFpbXBvcnRhbnQ7XG59XG5cbmlvbi1sYWJlbCB7XG4gIG1hcmdpbi10b3A6IDBweDtcbiAgbWFyZ2luLWJvdHRvbTogMHB4O1xufSJdfQ== */";
    /***/
  },

  /***/
  "./src/app/pages/order-detail/order-detail.page.ts":
  /*!*********************************************************!*\
    !*** ./src/app/pages/order-detail/order-detail.page.ts ***!
    \*********************************************************/

  /*! exports provided: OrderDetailPage */

  /***/
  function srcAppPagesOrderDetailOrderDetailPageTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "OrderDetailPage", function () {
      return OrderDetailPage;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");
    /* harmony import */


    var js_base64__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! js-base64 */
    "./node_modules/js-base64/base64.js");
    /* harmony import */


    var js_base64__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(js_base64__WEBPACK_IMPORTED_MODULE_3__);
    /* harmony import */


    var _components_index__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! ../../components/index */
    "./src/app/components/index.ts");
    /* harmony import */


    var _service_index__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ../../service/index */
    "./src/app/service/index.ts");
    /* harmony import */


    var _order_list_order_list_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ../order-list/order-list.page */
    "./src/app/pages/order-list/order-list.page.ts");

    var OrderDetailPage = /*#__PURE__*/function () {
      function OrderDetailPage(commonUtils, activeRoute, nativeUtils, orderListPage, orderService) {
        var _this = this;

        _classCallCheck(this, OrderDetailPage);

        this.commonUtils = commonUtils;
        this.activeRoute = activeRoute;
        this.nativeUtils = nativeUtils;
        this.orderListPage = orderListPage;
        this.orderService = orderService;
        this.order = {
          goodsInfoList: [],
          matInfo: {},
          paymentInfo: {}
        };
        this.loading = true;
        this.activeRoute.queryParams.subscribe(function (params) {
          if (!_this.commonUtils.isNull(params.orderId)) {
            try {
              _this.orderId = JSON.parse(js_base64__WEBPACK_IMPORTED_MODULE_3__["Base64"].decode(params.orderId));
            } catch (e) {
              _this.order = {};
              console.error(e);
            }
          }
        });
      }

      _createClass(OrderDetailPage, [{
        key: "ngOnInit",
        value: function ngOnInit() {
          return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
            return regeneratorRuntime.wrap(function _callee$(_context) {
              while (1) {
                switch (_context.prev = _context.next) {
                  case 0:
                    _context.next = 2;
                    return this.loadOrderDetails(this.orderId);

                  case 2:
                    this.order = _context.sent;
                    console.log(this.order);
                    this.loading = false;

                  case 5:
                  case "end":
                    return _context.stop();
                }
              }
            }, _callee, this);
          }));
        }
      }, {
        key: "loadOrderDetails",
        value: function loadOrderDetails(orderId) {
          return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee2() {
            var data;
            return regeneratorRuntime.wrap(function _callee2$(_context2) {
              while (1) {
                switch (_context2.prev = _context2.next) {
                  case 0:
                    _context2.next = 2;
                    return this.orderService.getOrderDetails(orderId);

                  case 2:
                    data = _context2.sent;
                    return _context2.abrupt("return", data);

                  case 4:
                  case "end":
                    return _context2.stop();
                }
              }
            }, _callee2, this);
          }));
        }
      }, {
        key: "copyOrderNumber",
        value: function copyOrderNumber(orderNumber) {
          this.nativeUtils.copyToClipboard(orderNumber);
        }
      }, {
        key: "genStatusColor",
        value: function genStatusColor(status) {
          return this.orderListPage.genStatusColor(status);
        }
      }, {
        key: "callNumber",
        value: function callNumber(cellNumber, order) {
          var numbers = cellNumber.split('_');

          if (numbers.length >= 0) {
            this.nativeUtils.callNumber(numbers[0]); // 设置已拨打

            this.orderService.markCalledDeliveryman(order.orderNumber, order.deliveryman);
          }
        }
      }]);

      return OrderDetailPage;
    }();

    OrderDetailPage.ctorParameters = function () {
      return [{
        type: _components_index__WEBPACK_IMPORTED_MODULE_4__["CommonUtils"]
      }, {
        type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"]
      }, {
        type: _components_index__WEBPACK_IMPORTED_MODULE_4__["NativeUtils"]
      }, {
        type: _order_list_order_list_page__WEBPACK_IMPORTED_MODULE_6__["OrderListPage"]
      }, {
        type: _service_index__WEBPACK_IMPORTED_MODULE_5__["OrderService"]
      }];
    };

    OrderDetailPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-order-detail',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./order-detail.page.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/order-detail/order-detail.page.html")).default,
      providers: [_service_index__WEBPACK_IMPORTED_MODULE_5__["OrderService"], _order_list_order_list_page__WEBPACK_IMPORTED_MODULE_6__["OrderListPage"]],
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./order-detail.page.scss */
      "./src/app/pages/order-detail/order-detail.page.scss")).default]
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_components_index__WEBPACK_IMPORTED_MODULE_4__["CommonUtils"], _angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"], _components_index__WEBPACK_IMPORTED_MODULE_4__["NativeUtils"], _order_list_order_list_page__WEBPACK_IMPORTED_MODULE_6__["OrderListPage"], _service_index__WEBPACK_IMPORTED_MODULE_5__["OrderService"]])], OrderDetailPage);
    /***/
  }
}]);
//# sourceMappingURL=order-detail-order-detail-module-es5.js.map