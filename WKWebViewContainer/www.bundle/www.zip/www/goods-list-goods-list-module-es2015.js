(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["goods-list-goods-list-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/goods-list/goods-list.page.html":
/*!*********************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/goods-list/goods-list.page.html ***!
  \*********************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\n  <ion-toolbar color=\"ysw\">\n    <ion-buttons slot=\"start\">\n      <ion-back-button></ion-back-button>\n    </ion-buttons>\n    <ion-title>{{title}}</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <ion-header collapse=\"condense\">\n    <ion-toolbar color=\"ysw\">\n      <ion-title size=\"large\">{{title}}</ion-title>\n    </ion-toolbar>\n  </ion-header>\n\n  <ion-list>\n    <ng-container *ngFor=\"let goods of goodsList\">\n      <ion-card>\n        <ion-card-header>\n          <ion-card-title class=\"flex ion-justify-content-between ion-align-items-center m-b-5\">\n            <ion-label style=\"width: 85px;\">\n              <ion-label [color]=\"goods.goodsId && goods.goodsName ? '' : 'medium'\">{{goods.goodsTrack}}</ion-label>\n              <!--\n              <ion-icon class=\"lock-icon\" *ngIf=\"!goods.isPublish\" color=\"danger\" name=\"lock-closed-outline\"></ion-icon>\n              -->\n            </ion-label>\n            <ion-label>\n              <ng-container *ngIf=\"goods.goodsId && goods.goodsName;else noGoods\">\n                <ion-label>{{(goods.brandName || '') + ' '}}{{goods.goodsName}}</ion-label>\n              </ng-container>\n              <ng-template #noGoods>\n                <ion-label color=\"medium\">暂未绑定商品</ion-label>\n              </ng-template>\n            </ion-label>\n          </ion-card-title>\n        </ion-card-header>\n        <ion-card-content>\n          <div class=\"flex ion-justify-content-start ion-align-items-start\">\n            <ion-img (ionError)=\"imageError($event)\" *ngIf=\"goods.goodsId && goods.goodsName\"\n              [src]=\"goods.goodsThumb || 'assets/imgs/mat/goods-no-image.svg'\" [alt]=\"goods.goodsTrack\">\n            </ion-img>\n            <div *ngIf=\"!goods.goodsId || !goods.goodsName\"\n              class=\"track-no-goods flex ion-justify-content-center ion-align-items-center\">\n              暂未绑定商品\n            </div>\n            <div class=\"flex ion-justify-content-center ion-align-items-start flex-column\">\n              <ion-label>\n                <ion-label color=\"dark\">规格：</ion-label>{{goods.goodsPackage || '-'}}\n              </ion-label>\n              <ion-label class=\"m-t-5\">\n                <ion-label color=\"dark\">厂商：</ion-label>{{goods.mfrName || '-'}}\n              </ion-label>\n              <ion-label class=\"flex ion-justify-content-between ion-align-items-center m-t-5 w-100p\">\n                <ion-label>\n                  <ion-label color=\"dark\">最大：</ion-label>{{goods.maxNumber || '-'}} {{goods.goodsUnit}}\n                </ion-label>\n                <ion-label class=\"w-55p\">\n                  <ion-label color=\"dark\">库存：</ion-label>\n                  <ng-container *ngIf=\"goods.goodsNumber && goods.goodsNumber > 0;else noGoodsNumber\">\n                    <ion-label color=\"warning\">\n                      {{goods.goodsNumber}}<ion-label color=\"danger\" *ngIf=\"goods.lockedNumber\">[{{goods.lockedNumber || '-'}}]</ion-label> {{goods.goodsUnit}}\n                    </ion-label>\n                  </ng-container>\n                  <ng-template #noGoodsNumber>\n                    <ion-label color=\"danger\">售罄</ion-label>\n                  </ng-template>\n                </ion-label>\n              </ion-label>\n              <ion-label class=\"flex ion-justify-content-between ion-align-items-center m-t-5 w-100p\">\n                <ion-label>\n                  <ion-label color=\"dark\">限购：</ion-label>{{goods.limitation}} {{goods.goodsUnit}}\n                </ion-label>\n                <ion-label class=\"w-55p\">\n                  <ion-label color=\"dark\">价格：</ion-label>\n                  <ion-label color=\"danger\">{{goods.goodsPrice| currency: '￥'}}</ion-label>\n                </ion-label>\n              </ion-label>\n            </div>\n          </div>\n        </ion-card-content>\n      </ion-card>\n    </ng-container>\n  </ion-list>\n</ion-content>");

/***/ }),

/***/ "./src/app/pages/goods-list/goods-list.module.ts":
/*!*******************************************************!*\
  !*** ./src/app/pages/goods-list/goods-list.module.ts ***!
  \*******************************************************/
/*! exports provided: GoodsListPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "GoodsListPageModule", function() { return GoodsListPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm2015/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
/* harmony import */ var _goods_list_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./goods-list.page */ "./src/app/pages/goods-list/goods-list.page.ts");







let GoodsListPageModule = class GoodsListPageModule {
};
GoodsListPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"],
            _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild([
                {
                    path: 'list',
                    component: _goods_list_page__WEBPACK_IMPORTED_MODULE_6__["GoodsListPage"]
                }, {
                    path: 'detail',
                    component: _goods_list_page__WEBPACK_IMPORTED_MODULE_6__["GoodsListPage"]
                }
            ])
        ],
        declarations: [_goods_list_page__WEBPACK_IMPORTED_MODULE_6__["GoodsListPage"]]
    })
], GoodsListPageModule);



/***/ }),

/***/ "./src/app/pages/goods-list/goods-list.page.scss":
/*!*******************************************************!*\
  !*** ./src/app/pages/goods-list/goods-list.page.scss ***!
  \*******************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("ion-card-title ion-label {\n  font-size: 0.8em;\n}\n\nion-img {\n  max-width: 90px;\n  width: 90px;\n  height: 100px;\n}\n\nion-label[color=dark] {\n  font-weight: bold;\n}\n\n.track-no-goods {\n  width: 90px;\n  min-width: 90px;\n  height: 90px;\n  border: 0.55px solid #eee;\n  border-radius: 6px;\n  font-size: 0.8em;\n}\n\nion-img + div,\n.track-no-goods + div {\n  width: calc(100% - 100px);\n  margin-left: 10px;\n  font-size: 0.95em;\n}\n\nion-button {\n  --padding-start: 6px;\n  --padding-end: 6px;\n}\n\n.lock-icon {\n  top: -3px;\n  position: absolute;\n  left: 13px;\n  font-size: 30px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Vc2Vycy9jaGFubmluZy9EZXNrdG9wL3lzdy1hcHAtc2VydmljZTQvc3JjL2FwcC9wYWdlcy9nb29kcy1saXN0L2dvb2RzLWxpc3QucGFnZS5zY3NzIiwic3JjL2FwcC9wYWdlcy9nb29kcy1saXN0L2dvb2RzLWxpc3QucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0UsZ0JBQUE7QUNDRjs7QURDQTtFQUNFLGVBQUE7RUFDQSxXQUFBO0VBQ0EsYUFBQTtBQ0VGOztBREFBO0VBQ0UsaUJBQUE7QUNHRjs7QUREQTtFQUNFLFdBQUE7RUFDQSxlQUFBO0VBQ0EsWUFBQTtFQUNBLHlCQUFBO0VBQ0Esa0JBQUE7RUFDQSxnQkFBQTtBQ0lGOztBREZBOztFQUVFLHlCQUFBO0VBQ0EsaUJBQUE7RUFDQSxpQkFBQTtBQ0tGOztBREhBO0VBQ0Usb0JBQUE7RUFDQSxrQkFBQTtBQ01GOztBREpBO0VBQ0UsU0FBQTtFQUNBLGtCQUFBO0VBQ0EsVUFBQTtFQUNBLGVBQUE7QUNPRiIsImZpbGUiOiJzcmMvYXBwL3BhZ2VzL2dvb2RzLWxpc3QvZ29vZHMtbGlzdC5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJpb24tY2FyZC10aXRsZSBpb24tbGFiZWwge1xuICBmb250LXNpemU6IDAuOGVtO1xufVxuaW9uLWltZyB7XG4gIG1heC13aWR0aDogOTBweDtcbiAgd2lkdGg6IDkwcHg7XG4gIGhlaWdodDogMTAwcHg7XG59XG5pb24tbGFiZWxbY29sb3I9XCJkYXJrXCJdIHtcbiAgZm9udC13ZWlnaHQ6IGJvbGQ7XG59XG4udHJhY2stbm8tZ29vZHMge1xuICB3aWR0aDogOTBweDtcbiAgbWluLXdpZHRoOiA5MHB4O1xuICBoZWlnaHQ6IDkwcHg7XG4gIGJvcmRlcjogMC41NXB4IHNvbGlkICNlZWU7XG4gIGJvcmRlci1yYWRpdXM6IDZweDtcbiAgZm9udC1zaXplOiAwLjhlbTtcbn1cbmlvbi1pbWcgKyBkaXYsXG4udHJhY2stbm8tZ29vZHMgKyBkaXYge1xuICB3aWR0aDogY2FsYygxMDAlIC0gMTAwcHgpO1xuICBtYXJnaW4tbGVmdDogMTBweDtcbiAgZm9udC1zaXplOiAwLjk1ZW07XG59XG5pb24tYnV0dG9uIHtcbiAgLS1wYWRkaW5nLXN0YXJ0OiA2cHg7XG4gIC0tcGFkZGluZy1lbmQ6IDZweDtcbn1cbi5sb2NrLWljb24ge1xuICB0b3A6IC0zcHg7XG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgbGVmdDogMTNweDtcbiAgZm9udC1zaXplOiAzMHB4O1xufVxuIiwiaW9uLWNhcmQtdGl0bGUgaW9uLWxhYmVsIHtcbiAgZm9udC1zaXplOiAwLjhlbTtcbn1cblxuaW9uLWltZyB7XG4gIG1heC13aWR0aDogOTBweDtcbiAgd2lkdGg6IDkwcHg7XG4gIGhlaWdodDogMTAwcHg7XG59XG5cbmlvbi1sYWJlbFtjb2xvcj1kYXJrXSB7XG4gIGZvbnQtd2VpZ2h0OiBib2xkO1xufVxuXG4udHJhY2stbm8tZ29vZHMge1xuICB3aWR0aDogOTBweDtcbiAgbWluLXdpZHRoOiA5MHB4O1xuICBoZWlnaHQ6IDkwcHg7XG4gIGJvcmRlcjogMC41NXB4IHNvbGlkICNlZWU7XG4gIGJvcmRlci1yYWRpdXM6IDZweDtcbiAgZm9udC1zaXplOiAwLjhlbTtcbn1cblxuaW9uLWltZyArIGRpdixcbi50cmFjay1uby1nb29kcyArIGRpdiB7XG4gIHdpZHRoOiBjYWxjKDEwMCUgLSAxMDBweCk7XG4gIG1hcmdpbi1sZWZ0OiAxMHB4O1xuICBmb250LXNpemU6IDAuOTVlbTtcbn1cblxuaW9uLWJ1dHRvbiB7XG4gIC0tcGFkZGluZy1zdGFydDogNnB4O1xuICAtLXBhZGRpbmctZW5kOiA2cHg7XG59XG5cbi5sb2NrLWljb24ge1xuICB0b3A6IC0zcHg7XG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgbGVmdDogMTNweDtcbiAgZm9udC1zaXplOiAzMHB4O1xufSJdfQ== */");

/***/ }),

/***/ "./src/app/pages/goods-list/goods-list.page.ts":
/*!*****************************************************!*\
  !*** ./src/app/pages/goods-list/goods-list.page.ts ***!
  \*****************************************************/
/*! exports provided: GoodsListPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "GoodsListPage", function() { return GoodsListPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _components_index__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../components/index */ "./src/app/components/index.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");




let GoodsListPage = class GoodsListPage {
    constructor(commonUtils, storageUtils, router, activeRoute) {
        this.commonUtils = commonUtils;
        this.storageUtils = storageUtils;
        this.router = router;
        this.activeRoute = activeRoute;
        this.title = '商品列表';
        this.goodsList = [];
        this.activeRoute.queryParams.subscribe((params) => {
            if (!this.commonUtils.isNullOrEmptyString(params.title)) {
                this.title = decodeURI(params.title);
            }
        });
        this.goodsList = this.storageUtils.get(_components_index__WEBPACK_IMPORTED_MODULE_2__["ProjectConstant"].STORAGE_KEY_ALERT_GOODS_INFO);
    }
    ngOnInit() { }
    genGoodsNumber(goods) {
        return goods.goodsNumber === 1 ? `仅剩 1 ${goods.goodsUnit}` : `${goods.goodsNumber} ${goods.goodsUnit}`;
    }
    imageError(event) {
        event.target.src = 'assets/imgs/mat/goods-no-image.svg';
    }
    ngOnDestroy() {
        this.storageUtils.remove(_components_index__WEBPACK_IMPORTED_MODULE_2__["ProjectConstant"].STORAGE_KEY_ALERT_GOODS_INFO);
    }
};
GoodsListPage.ctorParameters = () => [
    { type: _components_index__WEBPACK_IMPORTED_MODULE_2__["CommonUtils"] },
    { type: _components_index__WEBPACK_IMPORTED_MODULE_2__["StorageUtils"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_3__["ActivatedRoute"] }
];
GoodsListPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-goods-list',
        template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./goods-list.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/goods-list/goods-list.page.html")).default,
        styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./goods-list.page.scss */ "./src/app/pages/goods-list/goods-list.page.scss")).default]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_components_index__WEBPACK_IMPORTED_MODULE_2__["CommonUtils"],
        _components_index__WEBPACK_IMPORTED_MODULE_2__["StorageUtils"],
        _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"],
        _angular_router__WEBPACK_IMPORTED_MODULE_3__["ActivatedRoute"]])
], GoodsListPage);



/***/ })

}]);
//# sourceMappingURL=goods-list-goods-list-module-es2015.js.map