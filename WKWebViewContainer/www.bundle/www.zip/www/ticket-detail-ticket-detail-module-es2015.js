(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["ticket-detail-ticket-detail-module"],{

/***/ "./src/app/pages/ticket-detail/ticket-detail.module.ts":
/*!*************************************************************!*\
  !*** ./src/app/pages/ticket-detail/ticket-detail.module.ts ***!
  \*************************************************************/
/*! exports provided: TicketDetailPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TicketDetailPageModule", function() { return TicketDetailPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm2015/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
/* harmony import */ var _ticket_detail_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./ticket-detail.page */ "./src/app/pages/ticket-detail/ticket-detail.page.ts");
/* harmony import */ var _module_index__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../module/index */ "./src/app/pages/module/index.ts");








let TicketDetailPageModule = class TicketDetailPageModule {
};
TicketDetailPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"],
            _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild([
                {
                    path: '',
                    component: _ticket_detail_page__WEBPACK_IMPORTED_MODULE_6__["TicketDetailPage"]
                }
            ]),
            _module_index__WEBPACK_IMPORTED_MODULE_7__["StringSecurityModule"],
            _module_index__WEBPACK_IMPORTED_MODULE_7__["SplitLabelModule"],
            _module_index__WEBPACK_IMPORTED_MODULE_7__["CardSwapModule"],
            _module_index__WEBPACK_IMPORTED_MODULE_7__["EmptyModule"],
            _module_index__WEBPACK_IMPORTED_MODULE_7__["CollaspeModule"]
        ],
        declarations: [_ticket_detail_page__WEBPACK_IMPORTED_MODULE_6__["TicketDetailPage"]]
    })
], TicketDetailPageModule);



/***/ })

}]);
//# sourceMappingURL=ticket-detail-ticket-detail-module-es2015.js.map