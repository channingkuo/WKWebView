function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["mat-track-mat-track-module"], {
  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/mat-track/mat-track.page.html":
  /*!*******************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/mat-track/mat-track.page.html ***!
    \*******************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppPagesMatTrackMatTrackPageHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-header>\n  <ion-toolbar color=\"ysw\">\n    <ion-buttons slot=\"start\">\n      <ion-back-button></ion-back-button>\n    </ion-buttons>\n    <ion-title>{{matName}} <small>{{matNo}}</small></ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <ion-refresher slot=\"fixed\" (ionRefresh)=\"doRefresh($event)\" pullMax=\"2000\">\n    <ion-refresher-content></ion-refresher-content>\n  </ion-refresher>\n\n  <ion-header collapse=\"condense\">\n    <ion-toolbar color=\"ysw\">\n      <ion-title size=\"large\">货道·商品 - <small>{{matName}}</small></ion-title>\n    </ion-toolbar>\n\n    <ion-toolbar color=\"ysw\">\n      <ion-searchbar color=\"light\" placeholder=\"轨道编号、商品名称\" showCancelButton=\"focus\" cancelButtonText=\"取消\"\n        inputmode=\"search\" [(ngModel)]=\"queryString\" [debounce]=\"2000\" (ionInput)=\"onSearch($event)\"></ion-searchbar>\n    </ion-toolbar>\n  </ion-header>\n\n  <skeleton [loading]=\"loading\">\n    <ion-list>\n      <ng-container *ngFor=\"let matTrack of matTrackList\">\n        <ion-card>\n          <ion-card-header>\n            <ion-card-title class=\"flex ion-justify-content-between ion-align-items-center m-b-5\">\n              <ion-label style=\"width: 100px;\">\n                <ion-label [color]=\"matTrack.goodsId && matTrack.goodsName ? '' : 'medium'\">{{matTrack.goodsTrack}}\n                </ion-label>\n                <ion-icon class=\"lock-icon\" *ngIf=\"!matTrack.isPublish\" color=\"danger\" name=\"lock-closed-outline\">\n                </ion-icon>\n              </ion-label>\n              <ion-label>\n                <ng-container *ngIf=\"matTrack.goodsId && matTrack.goodsName;else noGoods\">\n                  <ion-label>{{(matTrack.brandName || '') + ' '}}{{matTrack.goodsName}}</ion-label>\n                </ng-container>\n                <ng-template #noGoods>\n                  <ion-label color=\"medium\">暂未绑定商品</ion-label>\n                </ng-template>\n              </ion-label>\n            </ion-card-title>\n          </ion-card-header>\n          <ion-card-content>\n            <div class=\"flex ion-justify-content-start ion-align-items-start\">\n              <ion-img (ionError)=\"imageError($event)\" *ngIf=\"matTrack.goodsId && matTrack.goodsName\"\n                [src]=\"matTrack.goodsImage || 'assets/imgs/mat/goods-no-image.svg'\" [alt]=\"matTrack.goodsTrack\">\n              </ion-img>\n              <div *ngIf=\"!matTrack.goodsId || !matTrack.goodsName\"\n                class=\"track-no-goods flex ion-justify-content-center ion-align-items-center\">\n                暂未绑定商品\n              </div>\n              <div class=\"flex ion-justify-content-center ion-align-items-start flex-column\">\n                <ion-label>\n                  <ion-label color=\"dark\">规格：</ion-label>{{matTrack.goodsPackage || '-'}}\n                </ion-label>\n                <ion-label class=\"m-t-10\">\n                  <ion-label color=\"dark\">厂商：</ion-label>{{matTrack.mfrName || '-'}}\n                </ion-label>\n                <ion-label class=\"flex ion-justify-content-between ion-align-items-center m-t-10 w-100p\">\n                  <ion-label>\n                    <ion-label color=\"dark\">最大：</ion-label>{{matTrack.maxNumber || '-'}} {{matTrack.goodsUnit}}\n                  </ion-label>\n                  <ion-label class=\"w-55p\">\n                    <ion-label color=\"dark\">库存：</ion-label>\n                    <ng-container *ngIf=\"matTrack.goodsNumber && matTrack.goodsNumber > 0;else noGoodsNumber\">\n                      <ion-label [color]=\"matTrack.goodsNumber <= storageAlert ? 'warning' : ''\">\n                        {{matTrack.goodsNumber}}<ion-label color=\"danger\" *ngIf=\"matTrack.lockedNumber\">\n                          [{{matTrack.lockedNumber || '-'}}]</ion-label> {{matTrack.goodsUnit}}\n                      </ion-label>\n                    </ng-container>\n                    <ng-template #noGoodsNumber>\n                      <ion-label color=\"danger\">售罄</ion-label>\n                    </ng-template>\n                  </ion-label>\n                </ion-label>\n                <ion-label class=\"flex ion-justify-content-between ion-align-items-center m-t-10 w-100p\">\n                  <ion-label>\n                    <ion-label color=\"dark\">限购：</ion-label>{{matTrack.limitation}} {{matTrack.goodsUnit}}\n                  </ion-label>\n                  <ion-label class=\"w-55p\">\n                    <ion-label color=\"dark\">价格：</ion-label>\n                    <ion-label color=\"danger\">{{matTrack.goodsPrice| currency: '￥'}}</ion-label>\n                  </ion-label>\n                </ion-label>\n              </div>\n            </div>\n            <div *ngIf=\"hideActions !== 1\" class=\"m-t-5 text-right\">\n              <ion-button *ngIf=\"matTrack.trackType === 1\" style=\"height: 32px;\" (click)=\"openMatTrack(matTrack)\"\n                size=\"small\" color=\"ysw\">打开</ion-button>\n              <ion-button style=\"height: 32px;\" (click)=\"bindGoods(matTrack)\" size=\"small\" color=\"ysw\">绑定商品</ion-button>\n              <ion-button *ngIf=\"canModityQuantity\" style=\"height: 32px;\" (click)=\"supplyGoods(matTrack)\" size=\"small\"\n                color=\"ysw\">调整库存\n              </ion-button>\n              <ion-button style=\"height: 32px;\" (click)=\"changeGoodsPrice(matTrack)\" size=\"small\" color=\"ysw\">调整价格\n              </ion-button>\n              <ion-button *ngIf=\"canViewMore\" style=\"height: 32px;\" (click)=\"showMoreActions(matTrack)\" size=\"small\"\n                color=\"ysw\">更多\n              </ion-button>\n            </div>\n          </ion-card-content>\n        </ion-card>\n      </ng-container>\n    </ion-list>\n  </skeleton>\n</ion-content>";
    /***/
  },

  /***/
  "./src/app/pages/mat-track/mat-track.module.ts":
  /*!*****************************************************!*\
    !*** ./src/app/pages/mat-track/mat-track.module.ts ***!
    \*****************************************************/

  /*! exports provided: MatTrackPageModule */

  /***/
  function srcAppPagesMatTrackMatTrackModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "MatTrackPageModule", function () {
      return MatTrackPageModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/fesm2015/common.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/fesm2015/forms.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
    /* harmony import */


    var _mat_track_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ./mat-track.page */
    "./src/app/pages/mat-track/mat-track.page.ts");
    /* harmony import */


    var _module_index__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
    /*! ../module/index */
    "./src/app/pages/module/index.ts");

    var MatTrackPageModule = function MatTrackPageModule() {
      _classCallCheck(this, MatTrackPageModule);
    };

    MatTrackPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"], _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild([{
        path: '',
        component: _mat_track_page__WEBPACK_IMPORTED_MODULE_6__["MatTrackPage"]
      }, {
        path: 'supply',
        loadChildren: function loadChildren() {
          return __webpack_require__.e(
          /*! import() | mat-track-supply-mat-track-supply-module */
          "mat-track-supply-mat-track-supply-module").then(__webpack_require__.bind(null,
          /*! ../mat-track-supply/mat-track-supply.module */
          "./src/app/pages/mat-track-supply/mat-track-supply.module.ts")).then(function (m) {
            return m.MatTrackSupplyPageModule;
          });
        }
      }]), _module_index__WEBPACK_IMPORTED_MODULE_7__["EmptyModule"], _module_index__WEBPACK_IMPORTED_MODULE_7__["SkeletonModule"]],
      declarations: [_mat_track_page__WEBPACK_IMPORTED_MODULE_6__["MatTrackPage"]]
    })], MatTrackPageModule);
    /***/
  },

  /***/
  "./src/app/pages/mat-track/mat-track.page.scss":
  /*!*****************************************************!*\
    !*** ./src/app/pages/mat-track/mat-track.page.scss ***!
    \*****************************************************/

  /*! exports provided: default */

  /***/
  function srcAppPagesMatTrackMatTrackPageScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "ion-card-title ion-label {\n  font-size: 0.8em;\n}\n\nion-img {\n  max-width: 90px;\n  width: 90px;\n  height: 100px;\n}\n\n.track-no-goods {\n  width: 90px;\n  min-width: 90px;\n  height: 90px;\n  border: 0.55px solid #eee;\n  border-radius: 6px;\n  font-size: 0.8em;\n}\n\nion-img + div,\n.track-no-goods + div {\n  width: calc(100% - 100px);\n  margin-left: 10px;\n  font-size: 0.95em;\n}\n\nion-button {\n  --padding-start: 6px;\n  --padding-end: 6px;\n}\n\n.lock-icon {\n  top: -3px;\n  position: absolute;\n  left: 9px;\n  font-size: 30px;\n}\n\nion-card-content ion-label {\n  font-size: 13px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Vc2Vycy9jaGFubmluZy9EZXNrdG9wL3lzdy1hcHAtc2VydmljZTQvc3JjL2FwcC9wYWdlcy9tYXQtdHJhY2svbWF0LXRyYWNrLnBhZ2Uuc2NzcyIsInNyYy9hcHAvcGFnZXMvbWF0LXRyYWNrL21hdC10cmFjay5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSxnQkFBQTtBQ0NGOztBRENBO0VBQ0UsZUFBQTtFQUNBLFdBQUE7RUFDQSxhQUFBO0FDRUY7O0FEQUE7RUFDRSxXQUFBO0VBQ0EsZUFBQTtFQUNBLFlBQUE7RUFDQSx5QkFBQTtFQUNBLGtCQUFBO0VBQ0EsZ0JBQUE7QUNHRjs7QUREQTs7RUFFRSx5QkFBQTtFQUNBLGlCQUFBO0VBQ0EsaUJBQUE7QUNJRjs7QURGQTtFQUNFLG9CQUFBO0VBQ0Esa0JBQUE7QUNLRjs7QURIQTtFQUNFLFNBQUE7RUFDQSxrQkFBQTtFQUNBLFNBQUE7RUFDQSxlQUFBO0FDTUY7O0FESkE7RUFDRSxlQUFBO0FDT0YiLCJmaWxlIjoic3JjL2FwcC9wYWdlcy9tYXQtdHJhY2svbWF0LXRyYWNrLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbImlvbi1jYXJkLXRpdGxlIGlvbi1sYWJlbCB7XG4gIGZvbnQtc2l6ZTogMC44ZW07XG59XG5pb24taW1nIHtcbiAgbWF4LXdpZHRoOiA5MHB4O1xuICB3aWR0aDogOTBweDtcbiAgaGVpZ2h0OiAxMDBweDtcbn1cbi50cmFjay1uby1nb29kcyB7XG4gIHdpZHRoOiA5MHB4O1xuICBtaW4td2lkdGg6IDkwcHg7XG4gIGhlaWdodDogOTBweDtcbiAgYm9yZGVyOiAwLjU1cHggc29saWQgI2VlZTtcbiAgYm9yZGVyLXJhZGl1czogNnB4O1xuICBmb250LXNpemU6IDAuOGVtO1xufVxuaW9uLWltZyArIGRpdixcbi50cmFjay1uby1nb29kcyArIGRpdiB7XG4gIHdpZHRoOiBjYWxjKDEwMCUgLSAxMDBweCk7XG4gIG1hcmdpbi1sZWZ0OiAxMHB4O1xuICBmb250LXNpemU6IDAuOTVlbTtcbn1cbmlvbi1idXR0b24ge1xuICAtLXBhZGRpbmctc3RhcnQ6IDZweDtcbiAgLS1wYWRkaW5nLWVuZDogNnB4O1xufVxuLmxvY2staWNvbiB7XG4gIHRvcDogLTNweDtcbiAgcG9zaXRpb246IGFic29sdXRlO1xuICBsZWZ0OiA5cHg7XG4gIGZvbnQtc2l6ZTogMzBweDtcbn1cbmlvbi1jYXJkLWNvbnRlbnQgaW9uLWxhYmVsIHtcbiAgZm9udC1zaXplOiAxM3B4O1xufSIsImlvbi1jYXJkLXRpdGxlIGlvbi1sYWJlbCB7XG4gIGZvbnQtc2l6ZTogMC44ZW07XG59XG5cbmlvbi1pbWcge1xuICBtYXgtd2lkdGg6IDkwcHg7XG4gIHdpZHRoOiA5MHB4O1xuICBoZWlnaHQ6IDEwMHB4O1xufVxuXG4udHJhY2stbm8tZ29vZHMge1xuICB3aWR0aDogOTBweDtcbiAgbWluLXdpZHRoOiA5MHB4O1xuICBoZWlnaHQ6IDkwcHg7XG4gIGJvcmRlcjogMC41NXB4IHNvbGlkICNlZWU7XG4gIGJvcmRlci1yYWRpdXM6IDZweDtcbiAgZm9udC1zaXplOiAwLjhlbTtcbn1cblxuaW9uLWltZyArIGRpdixcbi50cmFjay1uby1nb29kcyArIGRpdiB7XG4gIHdpZHRoOiBjYWxjKDEwMCUgLSAxMDBweCk7XG4gIG1hcmdpbi1sZWZ0OiAxMHB4O1xuICBmb250LXNpemU6IDAuOTVlbTtcbn1cblxuaW9uLWJ1dHRvbiB7XG4gIC0tcGFkZGluZy1zdGFydDogNnB4O1xuICAtLXBhZGRpbmctZW5kOiA2cHg7XG59XG5cbi5sb2NrLWljb24ge1xuICB0b3A6IC0zcHg7XG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgbGVmdDogOXB4O1xuICBmb250LXNpemU6IDMwcHg7XG59XG5cbmlvbi1jYXJkLWNvbnRlbnQgaW9uLWxhYmVsIHtcbiAgZm9udC1zaXplOiAxM3B4O1xufSJdfQ== */";
    /***/
  },

  /***/
  "./src/app/pages/mat-track/mat-track.page.ts":
  /*!***************************************************!*\
    !*** ./src/app/pages/mat-track/mat-track.page.ts ***!
    \***************************************************/

  /*! exports provided: MatTrackPage */

  /***/
  function srcAppPagesMatTrackMatTrackPageTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "MatTrackPage", function () {
      return MatTrackPage;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
    /* harmony import */


    var _components_index__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! ../../components/index */
    "./src/app/components/index.ts");
    /* harmony import */


    var _service_index__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ../../service/index */
    "./src/app/service/index.ts");
    /* harmony import */


    var js_base64__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! js-base64 */
    "./node_modules/js-base64/base64.js");
    /* harmony import */


    var js_base64__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(js_base64__WEBPACK_IMPORTED_MODULE_6__);
    /* harmony import */


    var _modal_goods_select_goods_select_page__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
    /*! ../modal/goods-select/goods-select.page */
    "./src/app/pages/modal/goods-select/goods-select.page.ts");
    /* harmony import */


    var _modal_swap_track_goods_swap_track_goods_page__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(
    /*! ../modal/swap-track-goods/swap-track-goods.page */
    "./src/app/pages/modal/swap-track-goods/swap-track-goods.page.ts");
    /* harmony import */


    var _service_mat_cab_service__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(
    /*! ../../service/mat.cab.service */
    "./src/app/service/mat.cab.service.ts");

    var MatTrackPage = /*#__PURE__*/function () {
      function MatTrackPage(activeRoute, commonUtils, storageUtils, matService, matTrackService, meituanService, router, alertCtrl, modalCtrl, matCabService, actionSheetCtrl) {
        var _this = this;

        _classCallCheck(this, MatTrackPage);

        this.activeRoute = activeRoute;
        this.commonUtils = commonUtils;
        this.storageUtils = storageUtils;
        this.matService = matService;
        this.matTrackService = matTrackService;
        this.meituanService = meituanService;
        this.router = router;
        this.alertCtrl = alertCtrl;
        this.modalCtrl = modalCtrl;
        this.matCabService = matCabService;
        this.actionSheetCtrl = actionSheetCtrl;
        this.storageAlert = 0;
        this.queryString = '';
        this.matTrackList = [];
        this.loading = true;
        this.canModityQuantity = true;
        this.canViewMore = true;
        var alertSettings = this.storageUtils.get(_components_index__WEBPACK_IMPORTED_MODULE_4__["ProjectConstant"].STORAGE_KEY_ALERT_SETTINGS);
        this.storageAlert = alertSettings.storage;
        this.activeRoute.queryParams.subscribe(function (params) {
          _this.matName = js_base64__WEBPACK_IMPORTED_MODULE_6__["Base64"].decode(params.matName);
          _this.matId = params.matId;
          _this.matNo = params.matNo;
          _this.hideActions = parseInt(params.hideAction, 10);
          _this.enableMeituan = parseInt(params.enableMeituan, 10);

          if (!commonUtils.isNullOrEmptyString(params.query)) {
            _this.queryString = params.query;
          } // 处理子页面返回刷新当前页面


          var refresh = _this.storageUtils.get(_components_index__WEBPACK_IMPORTED_MODULE_4__["ProjectConstant"].STORAGE_KEY_REFRESH);

          if (refresh) {
            setTimeout(function () {
              return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](_this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
                return regeneratorRuntime.wrap(function _callee$(_context) {
                  while (1) {
                    switch (_context.prev = _context.next) {
                      case 0:
                        _context.next = 2;
                        return this.loadMatTrackGoodsList();

                      case 2:
                        this.matTrackList = _context.sent;
                        this.storageUtils.remove(_components_index__WEBPACK_IMPORTED_MODULE_4__["ProjectConstant"].STORAGE_KEY_REFRESH);

                      case 4:
                      case "end":
                        return _context.stop();
                    }
                  }
                }, _callee, this);
              }));
            }, 555);
          }
        });
        this.userInfo = this.storageUtils.get(_components_index__WEBPACK_IMPORTED_MODULE_4__["ProjectConstant"].STORAGE_KEY_USERINFO);

        if (this.userInfo.role === 'Service' && (this.userInfo.type === _components_index__WEBPACK_IMPORTED_MODULE_4__["ProjectConstant"].AGENT_STORE || this.userInfo.type === _components_index__WEBPACK_IMPORTED_MODULE_4__["ProjectConstant"].AGENT_STORE_HEADER)) {
          this.canViewMore = false;
          this.canModityQuantity = false;
        }
      }

      _createClass(MatTrackPage, [{
        key: "ngOnInit",
        value: function ngOnInit() {
          return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee2() {
            return regeneratorRuntime.wrap(function _callee2$(_context2) {
              while (1) {
                switch (_context2.prev = _context2.next) {
                  case 0:
                    _context2.next = 2;
                    return this.loadMatTrackGoodsList();

                  case 2:
                    this.matTrackList = _context2.sent;
                    this.loading = false;

                  case 4:
                  case "end":
                    return _context2.stop();
                }
              }
            }, _callee2, this);
          }));
        }
      }, {
        key: "loadMatTrackGoodsList",
        value: function loadMatTrackGoodsList() {
          return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee3() {
            var data;
            return regeneratorRuntime.wrap(function _callee3$(_context3) {
              while (1) {
                switch (_context3.prev = _context3.next) {
                  case 0:
                    if (!this.commonUtils.isNull(this.matId)) {
                      _context3.next = 3;
                      break;
                    }

                    this.commonUtils.showToast('售药机Id丢失！');
                    return _context3.abrupt("return");

                  case 3:
                    _context3.next = 5;
                    return this.matService.getMatTrackGoodsList(this.matId, this.queryString);

                  case 5:
                    data = _context3.sent;
                    return _context3.abrupt("return", data);

                  case 7:
                  case "end":
                    return _context3.stop();
                }
              }
            }, _callee3, this);
          }));
        }
      }, {
        key: "onSearch",
        value: function onSearch(event) {
          var _this2 = this;

          if (this.timer) {
            clearTimeout(this.timer);
          }

          this.timer = setTimeout(function () {
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](_this2, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee4() {
              return regeneratorRuntime.wrap(function _callee4$(_context4) {
                while (1) {
                  switch (_context4.prev = _context4.next) {
                    case 0:
                      _context4.next = 2;
                      return this.loadMatTrackGoodsList();

                    case 2:
                      this.matTrackList = _context4.sent;

                    case 3:
                    case "end":
                      return _context4.stop();
                  }
                }
              }, _callee4, this);
            }));
          }, 2000);
        }
      }, {
        key: "doRefresh",
        value: function doRefresh(event) {
          return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee5() {
            return regeneratorRuntime.wrap(function _callee5$(_context5) {
              while (1) {
                switch (_context5.prev = _context5.next) {
                  case 0:
                    _context5.next = 2;
                    return this.loadMatTrackGoodsList();

                  case 2:
                    this.matTrackList = _context5.sent;
                    event.target.complete();

                  case 4:
                  case "end":
                    return _context5.stop();
                }
              }
            }, _callee5, this);
          }));
        }
      }, {
        key: "supplyGoods",
        value: function supplyGoods(matTrack) {
          if (matTrack.enableErp === _components_index__WEBPACK_IMPORTED_MODULE_4__["ProjectConstant"].ENABLE_ERP) {
            this.commonUtils.showToast('开启ERP对接的售药机只能在Web端修改库存！');
            return;
          }

          if (!matTrack.goodsId || !matTrack.goodsName) {
            this.commonUtils.showToast('该货道暂未绑定商品！');
            return;
          }

          this.router.navigate(['../supply'], {
            relativeTo: this.activeRoute,
            queryParams: {
              matTrack: js_base64__WEBPACK_IMPORTED_MODULE_6__["Base64"].encode(JSON.stringify(matTrack)),
              matName: js_base64__WEBPACK_IMPORTED_MODULE_6__["Base64"].encode(this.matName)
            }
          });
        }
      }, {
        key: "bindGoods",
        value: function bindGoods(matTrack) {
          return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee6() {
            var openModal, modal, _ref, data;

            return regeneratorRuntime.wrap(function _callee6$(_context6) {
              while (1) {
                switch (_context6.prev = _context6.next) {
                  case 0:
                    openModal = false;

                    if (!(this.commonUtils.isNullOrEmptyString(matTrack.goodsId) || this.commonUtils.isNullOrEmptyString(matTrack.goodsName))) {
                      _context6.next = 5;
                      break;
                    }

                    openModal = true;
                    _context6.next = 13;
                    break;

                  case 5:
                    if (!(matTrack.goodsNumber <= 0)) {
                      _context6.next = 11;
                      break;
                    }

                    _context6.next = 8;
                    return this.commonUtils.showConfirm('确认', '该货道上已绑定商品，是否要更换商品！');

                  case 8:
                    openModal = _context6.sent;
                    _context6.next = 13;
                    break;

                  case 11:
                    this.commonUtils.showToast('该货道上已绑定商品，要更换商品，请先清空库存！');
                    return _context6.abrupt("return");

                  case 13:
                    if (!openModal) {
                      _context6.next = 26;
                      break;
                    }

                    _context6.next = 16;
                    return this.modalCtrl.create({
                      component: _modal_goods_select_goods_select_page__WEBPACK_IMPORTED_MODULE_7__["GoodsSelectPage"],
                      componentProps: {
                        matId: matTrack.matId
                      },
                      cssClass: 'ysw-common-modal-vertical',
                      swipeToClose: true
                    });

                  case 16:
                    modal = _context6.sent;
                    _context6.next = 19;
                    return modal.present();

                  case 19:
                    _context6.next = 21;
                    return modal.onWillDismiss();

                  case 21:
                    _ref = _context6.sent;
                    data = _ref.data;

                    if (this.commonUtils.isNull(data)) {
                      _context6.next = 26;
                      break;
                    }

                    _context6.next = 26;
                    return this.bindGoodsToTrack(data, matTrack);

                  case 26:
                  case "end":
                    return _context6.stop();
                }
              }
            }, _callee6, this);
          }));
        }
      }, {
        key: "bindGoodsToTrack",
        value: function bindGoodsToTrack(goods, matTrack) {
          return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee7() {
            var loading;
            return regeneratorRuntime.wrap(function _callee7$(_context7) {
              while (1) {
                switch (_context7.prev = _context7.next) {
                  case 0:
                    loading = this.commonUtils.showLoading('正在绑定...');
                    _context7.next = 3;
                    return this.matTrackService.changeMatTrackGoods(matTrack.matId, matTrack.id, goods);

                  case 3:
                    this.commonUtils.hideLoadingSync(loading);
                    this.commonUtils.showToast('绑定成功!');
                    this.syncChangeGoodsToMeituan(matTrack, goods); // 刷新页面

                    _context7.next = 8;
                    return this.loadMatTrackGoodsList();

                  case 8:
                    this.matTrackList = _context7.sent;
                    this.commonUtils.showToast('新商品价格为建议价格，请尽快调整为正常售卖价格！', 'middle', 5000);

                  case 10:
                  case "end":
                    return _context7.stop();
                }
              }
            }, _callee7, this);
          }));
        }
      }, {
        key: "syncChangeGoodsToMeituan",
        value: function syncChangeGoodsToMeituan(matTrack, goods) {
          if (this.enableMeituan === 1) {
            var syncPayload = {
              matId: this.matId,
              goodsId: matTrack.goodsId,
              type: 5,
              newGoodsId: goods.goodsId
            };
            this.meituanService.updateMatGoodsToMeituan(syncPayload);
          }
        }
      }, {
        key: "changeMaxNumber",
        value: function changeMaxNumber(matTrack) {
          return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee9() {
            var _this3 = this;

            var alert;
            return regeneratorRuntime.wrap(function _callee9$(_context9) {
              while (1) {
                switch (_context9.prev = _context9.next) {
                  case 0:
                    _context9.next = 2;
                    return this.alertCtrl.create({
                      header: matTrack.goodsTrack,
                      message: '调整轨道核定数',
                      inputs: [{
                        name: 'maxNumber',
                        type: 'number',
                        placeholder: '请输入轨道核定数'
                      }],
                      buttons: [{
                        text: '取消',
                        role: 'cancel',
                        cssClass: 'secondary',
                        handler: function handler() {}
                      }, {
                        text: '确认',
                        handler: function handler(data) {
                          return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](_this3, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee8() {
                            return regeneratorRuntime.wrap(function _callee8$(_context8) {
                              while (1) {
                                switch (_context8.prev = _context8.next) {
                                  case 0:
                                    if (!(!this.commonUtils.isNullOrEmptyString(data) && !this.commonUtils.isNullOrEmptyString(data.maxNumber))) {
                                      _context8.next = 11;
                                      break;
                                    }

                                    if (!(data.maxNumber < matTrack.goodsNumber)) {
                                      _context8.next = 4;
                                      break;
                                    }

                                    this.commonUtils.showToast('修改后的轨道核定数不能少于库存数！');
                                    return _context8.abrupt("return");

                                  case 4:
                                    _context8.next = 6;
                                    return this.matTrackService.changeMatTrackGoodsMaxNumber(matTrack.matId, matTrack.id, data.maxNumber);

                                  case 6:
                                    _context8.next = 8;
                                    return this.loadMatTrackGoodsList();

                                  case 8:
                                    this.matTrackList = _context8.sent;
                                    _context8.next = 12;
                                    break;

                                  case 11:
                                    this.commonUtils.showToast('请输入轨道核定数！');

                                  case 12:
                                  case "end":
                                    return _context8.stop();
                                }
                              }
                            }, _callee8, this);
                          }));
                        }
                      }],
                      backdropDismiss: false
                    });

                  case 2:
                    alert = _context9.sent;
                    _context9.next = 5;
                    return alert.present();

                  case 5:
                  case "end":
                    return _context9.stop();
                }
              }
            }, _callee9, this);
          }));
        }
      }, {
        key: "showMoreActions",
        value: function showMoreActions(matTrack) {
          return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee10() {
            var _this4 = this;

            var buttons, actionSheet;
            return regeneratorRuntime.wrap(function _callee10$(_context10) {
              while (1) {
                switch (_context10.prev = _context10.next) {
                  case 0:
                    buttons = [{
                      text: matTrack.isPublish ? '锁定货道' : '解锁货道',
                      cssClass: 'ysw-action-sheet',
                      handler: function handler() {
                        _this4.changeLock(matTrack);
                      }
                    }, {
                      text: '调整核定数',
                      cssClass: 'ysw-action-sheet',
                      handler: function handler() {
                        _this4.changeMaxNumber(matTrack);
                      }
                    }, {
                      text: '货道互换',
                      cssClass: 'ysw-action-sheet',
                      handler: function handler() {
                        _this4.swapMatTrackGoods(matTrack);
                      }
                    }, {
                      text: '清空货道',
                      role: 'destructive',
                      cssClass: 'ysw-action-sheet',
                      handler: function handler() {
                        _this4.deleteMatTrackGoods(matTrack);
                      }
                    }, {
                      text: '取消',
                      cssClass: 'ysw-action-sheet',
                      role: 'cancel',
                      handler: function handler() {}
                    }];
                    _context10.next = 3;
                    return this.actionSheetCtrl.create({
                      header: matTrack.goodsTrack,
                      buttons: buttons
                    });

                  case 3:
                    actionSheet = _context10.sent;
                    _context10.next = 6;
                    return actionSheet.present();

                  case 6:
                  case "end":
                    return _context10.stop();
                }
              }
            }, _callee10, this);
          }));
        }
      }, {
        key: "changeLock",
        value: function changeLock(matTrack) {
          return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee11() {
            var _this5 = this;

            var res;
            return regeneratorRuntime.wrap(function _callee11$(_context11) {
              while (1) {
                switch (_context11.prev = _context11.next) {
                  case 0:
                    _context11.next = 2;
                    return this.commonUtils.showConfirm('确认', "\u786E\u5B9A".concat(matTrack.isPublish ? '锁定' : '解锁', "\u8BE5\u8D27\u9053\uFF1F"));

                  case 2:
                    res = _context11.sent;

                    if (res) {
                      this.matTrackService.toggleMatTrackLock(this.matId, matTrack.id).then(function () {
                        matTrack.isPublish = !matTrack.isPublish;

                        _this5.syncTrackLockToMeituan(matTrack);
                      });
                    }

                  case 4:
                  case "end":
                    return _context11.stop();
                }
              }
            }, _callee11, this);
          }));
        }
      }, {
        key: "syncTrackLockToMeituan",
        value: function syncTrackLockToMeituan(matTrack) {
          if (this.enableMeituan === 1) {
            var syncPayload = {
              matId: this.matId,
              goodsId: matTrack.goodsId,
              type: 3,
              soldOut: matTrack.isPublish ? 1 : 0
            };
            this.meituanService.updateMatGoodsToMeituan(syncPayload);
          }
        }
      }, {
        key: "changeGoodsPrice",
        value: function changeGoodsPrice(matTrack) {
          return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee13() {
            var _this6 = this;

            var alert;
            return regeneratorRuntime.wrap(function _callee13$(_context13) {
              while (1) {
                switch (_context13.prev = _context13.next) {
                  case 0:
                    if (!(!matTrack.goodsId || !matTrack.goodsName)) {
                      _context13.next = 3;
                      break;
                    }

                    this.commonUtils.showToast('该货道暂未绑定商品！');
                    return _context13.abrupt("return");

                  case 3:
                    _context13.next = 5;
                    return this.alertCtrl.create({
                      header: matTrack.goodsTrack,
                      message: '调整轨道商品价格',
                      inputs: [{
                        name: 'price',
                        type: 'number',
                        placeholder: '请输入商品新价格'
                      }],
                      buttons: [{
                        text: '取消',
                        role: 'cancel',
                        cssClass: 'secondary',
                        handler: function handler() {}
                      }, {
                        text: '确认',
                        handler: function handler(data) {
                          return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](_this6, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee12() {
                            var loading;
                            return regeneratorRuntime.wrap(function _callee12$(_context12) {
                              while (1) {
                                switch (_context12.prev = _context12.next) {
                                  case 0:
                                    if (!(!this.commonUtils.isNullOrEmptyString(data) && !this.commonUtils.isNullOrEmptyString(data.price))) {
                                      _context12.next = 15;
                                      break;
                                    }

                                    if (!(data.price < 0)) {
                                      _context12.next = 4;
                                      break;
                                    }

                                    this.commonUtils.showToast('商品价格不能小于零！');
                                    return _context12.abrupt("return");

                                  case 4:
                                    _context12.next = 6;
                                    return this.matTrackService.changeMatTrackGoodsPrice(matTrack.matId, matTrack.id, data.price);

                                  case 6:
                                    this.syncPriceToMeituan(matTrack, data.price); // 刷新页面

                                    loading = this.commonUtils.showLoading('正在修改价格...');
                                    _context12.next = 10;
                                    return this.loadMatTrackGoodsList();

                                  case 10:
                                    this.matTrackList = _context12.sent;
                                    this.commonUtils.hideLoadingSync(loading);
                                    this.commonUtils.showToast('修改成功!');
                                    _context12.next = 16;
                                    break;

                                  case 15:
                                    this.commonUtils.showToast('请输入商品新价格！');

                                  case 16:
                                  case "end":
                                    return _context12.stop();
                                }
                              }
                            }, _callee12, this);
                          }));
                        }
                      }],
                      backdropDismiss: false
                    });

                  case 5:
                    alert = _context13.sent;
                    _context13.next = 8;
                    return alert.present();

                  case 8:
                  case "end":
                    return _context13.stop();
                }
              }
            }, _callee13, this);
          }));
        }
      }, {
        key: "syncPriceToMeituan",
        value: function syncPriceToMeituan(matTrack, price) {
          if (this.enableMeituan === 1) {
            var syncPayload = {
              matId: this.matId,
              goodsId: matTrack.goodsId,
              type: 1,
              price: price
            };
            this.meituanService.updateMatGoodsToMeituan(syncPayload);
          }
        }
      }, {
        key: "swapMatTrackGoods",
        value: function swapMatTrackGoods(matTrack) {
          return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee14() {
            var modal, _ref2, data, loading;

            return regeneratorRuntime.wrap(function _callee14$(_context14) {
              while (1) {
                switch (_context14.prev = _context14.next) {
                  case 0:
                    _context14.next = 2;
                    return this.modalCtrl.create({
                      component: _modal_swap_track_goods_swap_track_goods_page__WEBPACK_IMPORTED_MODULE_8__["SwapTrackGoodsPage"],
                      componentProps: {
                        sourceTrack: matTrack
                      },
                      swipeToClose: true
                    });

                  case 2:
                    modal = _context14.sent;
                    this.storageUtils.set(_components_index__WEBPACK_IMPORTED_MODULE_4__["ProjectConstant"].STORAGE_KEY_MAT_TRACK_LIST, this.matTrackList);
                    _context14.next = 6;
                    return modal.present();

                  case 6:
                    _context14.next = 8;
                    return modal.onWillDismiss();

                  case 8:
                    _ref2 = _context14.sent;
                    data = _ref2.data;

                    if (!(!this.commonUtils.isNull(data) && !this.commonUtils.isNull(data.sourceId) && !this.commonUtils.isNull(data.targetId))) {
                      _context14.next = 19;
                      break;
                    }

                    loading = this.commonUtils.showLoading('正在交轨道到商品...');
                    _context14.next = 14;
                    return this.matTrackService.swapMatTrackGoods(matTrack.matId, data.sourceId, data.targetId);

                  case 14:
                    this.commonUtils.hideLoadingSync(loading);
                    this.commonUtils.showToast('操作成功！'); // 刷新页面

                    _context14.next = 18;
                    return this.loadMatTrackGoodsList();

                  case 18:
                    this.matTrackList = _context14.sent;

                  case 19:
                  case "end":
                    return _context14.stop();
                }
              }
            }, _callee14, this);
          }));
        }
      }, {
        key: "deleteMatTrackGoods",
        value: function deleteMatTrackGoods(matTrack) {
          return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee16() {
            var _this7 = this;

            var alert;
            return regeneratorRuntime.wrap(function _callee16$(_context16) {
              while (1) {
                switch (_context16.prev = _context16.next) {
                  case 0:
                    if (!(matTrack.goodsName > 0)) {
                      _context16.next = 3;
                      break;
                    }

                    this.commonUtils.showToast('清空轨道商品前请先清空库存！');
                    return _context16.abrupt("return");

                  case 3:
                    _context16.next = 5;
                    return this.alertCtrl.create({
                      header: '确认',
                      message: "\u662F\u5426\u6E05\u7A7A\u8F68\u9053".concat(matTrack.goodsTrack, "\u4E0A\u7684\u5546\u54C1\uFF1F"),
                      buttons: [{
                        text: '取消',
                        role: 'cancel',
                        cssClass: 'secondary',
                        handler: function handler() {}
                      }, {
                        text: '确认',
                        handler: function handler() {
                          return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](_this7, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee15() {
                            return regeneratorRuntime.wrap(function _callee15$(_context15) {
                              while (1) {
                                switch (_context15.prev = _context15.next) {
                                  case 0:
                                    _context15.next = 2;
                                    return this.matTrackService.deleteMatTrackGoods(matTrack.matId, matTrack.id);

                                  case 2:
                                    _context15.next = 4;
                                    return this.loadMatTrackGoodsList();

                                  case 4:
                                    this.matTrackList = _context15.sent;

                                  case 5:
                                  case "end":
                                    return _context15.stop();
                                }
                              }
                            }, _callee15, this);
                          }));
                        }
                      }],
                      backdropDismiss: false
                    });

                  case 5:
                    alert = _context16.sent;
                    _context16.next = 8;
                    return alert.present();

                  case 8:
                  case "end":
                    return _context16.stop();
                }
              }
            }, _callee16, this);
          }));
        }
      }, {
        key: "imageError",
        value: function imageError(event) {
          event.target.src = 'assets/imgs/mat/goods-no-image.svg';
        }
      }, {
        key: "openMatTrack",
        value: function openMatTrack(matTrack) {
          return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee17() {
            var data;
            return regeneratorRuntime.wrap(function _callee17$(_context17) {
              while (1) {
                switch (_context17.prev = _context17.next) {
                  case 0:
                    _context17.next = 2;
                    return this.commonUtils.showConfirm('温馨提示', '确定要打开：' + matTrack.goodsTrack + '号格子？');

                  case 2:
                    if (!_context17.sent) {
                      _context17.next = 7;
                      break;
                    }

                    _context17.next = 5;
                    return this.matCabService.openMatTrack(this.matId, matTrack.trackCode);

                  case 5:
                    data = _context17.sent;

                    if (data.success) {
                      this.commonUtils.showToast('打开成功！');
                    } else {
                      this.commonUtils.showToast(data.message);
                    }

                  case 7:
                  case "end":
                    return _context17.stop();
                }
              }
            }, _callee17, this);
          }));
        }
      }]);

      return MatTrackPage;
    }();

    MatTrackPage.ctorParameters = function () {
      return [{
        type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"]
      }, {
        type: _components_index__WEBPACK_IMPORTED_MODULE_4__["CommonUtils"]
      }, {
        type: _components_index__WEBPACK_IMPORTED_MODULE_4__["StorageUtils"]
      }, {
        type: _service_index__WEBPACK_IMPORTED_MODULE_5__["MatService"]
      }, {
        type: _service_index__WEBPACK_IMPORTED_MODULE_5__["MatTrackService"]
      }, {
        type: _service_index__WEBPACK_IMPORTED_MODULE_5__["MeituanService"]
      }, {
        type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["AlertController"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["ModalController"]
      }, {
        type: _service_mat_cab_service__WEBPACK_IMPORTED_MODULE_9__["MatCabService"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["ActionSheetController"]
      }];
    };

    MatTrackPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-mat-track',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./mat-track.page.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/mat-track/mat-track.page.html")).default,
      providers: [_service_index__WEBPACK_IMPORTED_MODULE_5__["MatService"], _service_index__WEBPACK_IMPORTED_MODULE_5__["MatTrackService"], _service_index__WEBPACK_IMPORTED_MODULE_5__["MeituanService"], _service_mat_cab_service__WEBPACK_IMPORTED_MODULE_9__["MatCabService"]],
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./mat-track.page.scss */
      "./src/app/pages/mat-track/mat-track.page.scss")).default]
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"], _components_index__WEBPACK_IMPORTED_MODULE_4__["CommonUtils"], _components_index__WEBPACK_IMPORTED_MODULE_4__["StorageUtils"], _service_index__WEBPACK_IMPORTED_MODULE_5__["MatService"], _service_index__WEBPACK_IMPORTED_MODULE_5__["MatTrackService"], _service_index__WEBPACK_IMPORTED_MODULE_5__["MeituanService"], _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"], _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["AlertController"], _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["ModalController"], _service_mat_cab_service__WEBPACK_IMPORTED_MODULE_9__["MatCabService"], _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["ActionSheetController"]])], MatTrackPage);
    /***/
  }
}]);
//# sourceMappingURL=mat-track-mat-track-module-es5.js.map