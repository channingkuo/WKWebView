function _toConsumableArray(arr) { return _arrayWithoutHoles(arr) || _iterableToArray(arr) || _nonIterableSpread(); }

function _nonIterableSpread() { throw new TypeError("Invalid attempt to spread non-iterable instance"); }

function _iterableToArray(iter) { if (Symbol.iterator in Object(iter) || Object.prototype.toString.call(iter) === "[object Arguments]") return Array.from(iter); }

function _arrayWithoutHoles(arr) { if (Array.isArray(arr)) { for (var i = 0, arr2 = new Array(arr.length); i < arr.length; i++) { arr2[i] = arr[i]; } return arr2; } }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["default~order-detail-order-detail-module~order-list-order-list-module"], {
  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/order-list/order-list.page.html":
  /*!*********************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/order-list/order-list.page.html ***!
    \*********************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppPagesOrderListOrderListPageHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-header>\n  <ion-toolbar color=\"ysw\">\n    <ion-buttons slot=\"start\">\n      <ion-back-button></ion-back-button>\n    </ion-buttons>\n    <ion-title>订 单</ion-title>\n    <ion-buttons collapse=\"true\" slot=\"end\">\n      <ion-button (click)=\"onFilter()\">\n        <ion-label class=\"icon-text-small\">筛选</ion-label>\n      </ion-button>\n    </ion-buttons>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <ion-refresher slot=\"fixed\" (ionRefresh)=\"doRefresh($event)\" pullMax=\"2000\">\n    <ion-refresher-content></ion-refresher-content>\n  </ion-refresher>\n\n  <ion-header collapse=\"condense\">\n    <ion-toolbar color=\"ysw\">\n      <ion-title size=\"large\">订 单</ion-title>\n      <ion-buttons collapse=\"true\" slot=\"end\">\n        <ion-button (click)=\"onFilter()\">\n          <ion-label class=\"icon-text-small\">筛选</ion-label>\n        </ion-button>\n      </ion-buttons>\n    </ion-toolbar>\n\n    <ion-toolbar color=\"ysw\">\n      <ion-searchbar color=\"light\" placeholder=\"订单号、售药机\" showCancelButton=\"focus\" cancelButtonText=\"取消\"\n        inputmode=\"search\" [(ngModel)]=\"queryString\" [debounce]=\"2000\" (ionInput)=\"onSearch($event)\"></ion-searchbar>\n    </ion-toolbar>\n  </ion-header>\n\n  <skeleton [loading]=\"loading\">\n    <ion-list>\n      <ng-container *ngFor=\"let order of orderList\">\n        <ion-card (click)=\"viewOrderDetail(order)\">\n          <ion-card-header>\n            <ion-card-title class=\"flex ion-justify-content-between ion-align-items-center\">\n              <ion-label>\n                <ion-text *ngIf=\"!order.outOrderId\">{{order.ipOrderNo}}</ion-text>\n                <ion-text *ngIf=\"order.outOrderId\">{{order.outOrderId | stringSecurity}}</ion-text>\n                <ion-icon class=\"m-l-5\" src=\"assets/imgs/mat/mat-meituan.svg\" *ngIf=\"order.orderRefer===4\"></ion-icon>\n              </ion-label>\n              <ion-badge [color]=\"genStatusColor(order.orderStatusCode)\" style=\"flex-shrink: 0;\">\n                {{order.orderStatusName}}</ion-badge>\n            </ion-card-title>\n            <ion-card-subtitle>\n              <div class=\"flex ion-justify-content-between ion-align-items-center\">\n                <ion-label>\n                  {{order.matInfo.matName}} <small>{{order.matInfo.matSerial}}</small>\n                </ion-label>\n                <ion-label *ngIf=\"order.outOrderSeq\">\n                  <ion-text color=\"ysw\">{{order.outOrderSeq}}号单</ion-text>\n                  <ion-text *ngIf=\"order.serviceData\" color=\"danger\" style=\"font-size: 11px;\">已拨打</ion-text>\n                </ion-label>\n              </div>\n              <div *ngIf=\"order.serviceData\" style=\"color: var(--ion-color-secondary, #3dc2ff);\">\n                {{order.serviceDataContent}}</div>\n            </ion-card-subtitle>\n          </ion-card-header>\n          <ion-card-content>\n            <div class=\"flex ion-justify-content-start ion-align-items-center\">\n              <ng-container *ngFor=\"let goods of order.goodsInfo;last as isLastItem\">\n                <ion-img (ionError)=\"imageError($event)\"\n                  [src]=\"goods.goodsThumb || 'assets/imgs/mat/goods-no-image.svg'\" [alt]=\"goods.goodsName\"></ion-img>\n              </ng-container>\n            </div>\n\n            <div class=\"flex ion-justify-content-between ion-align-items-center\">\n              <ion-label class=\"order-date ion-align-self-end\">{{order.orderDate | date: 'yyyy-MM-dd HH:mm:ss'}}\n              </ion-label>\n              <ion-label class=\"order-overview-price ion-align-self-end\">\n                <ion-label>共<ion-label color=\"dark\">{{' ' + order.goodsInfo.length + ' '}}</ion-label>件商品{{' '}}\n                </ion-label>\n                <ion-label color=\"dark\">合计: </ion-label>\n                <ion-label color=\"danger\">{{order.actualTotalAmount| currency: '￥'}}</ion-label>\n              </ion-label>\n            </div>\n          </ion-card-content>\n        </ion-card>\n      </ng-container>\n    </ion-list>\n\n    <empty-view [data]=\"orderList\" message=\"暂无订单数据~\">\n      <empty-content></empty-content>\n    </empty-view>\n\n    <ion-infinite-scroll threshold=\"100px\" (ionInfinite)=\"onInfinite($event)\">\n      <ion-infinite-scroll-content loadingSpinner=\"bubbles\" loadingText=\"加载更多...\">\n      </ion-infinite-scroll-content>\n    </ion-infinite-scroll>\n  </skeleton>\n</ion-content>\n\n<ng-container *ngIf=\"orderList.length>0\">\n  <ion-badge class=\"pager\">{{pageIndex}}/{{pageTotal}}</ion-badge>\n</ng-container>";
    /***/
  },

  /***/
  "./src/app/modal-transitions.ts":
  /*!**************************************!*\
    !*** ./src/app/modal-transitions.ts ***!
    \**************************************/

  /*! exports provided: RightLeaveAnimation, RightEnterAnimation */

  /***/
  function srcAppModalTransitionsTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "RightLeaveAnimation", function () {
      return RightLeaveAnimation;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "RightEnterAnimation", function () {
      return RightEnterAnimation;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _ionic_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @ionic/core */
    "./node_modules/@ionic/core/dist/esm/index.mjs");

    var RightLeaveAnimation = function RightLeaveAnimation(baseEl, presentingEl) {
      var duration = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : 700;
      var backdropAnimation = Object(_ionic_core__WEBPACK_IMPORTED_MODULE_1__["createAnimation"])() // tslint:disable-next-line:no-non-null-assertion
      .addElement(baseEl.querySelector('ion-backdrop')).fromTo('opacity', 'var(--backdrop-opacity)', 0.0);
      var wrapperAnimation = Object(_ionic_core__WEBPACK_IMPORTED_MODULE_1__["createAnimation"])() // tslint:disable-next-line:no-non-null-assertion
      .addElement(baseEl.querySelector('.modal-wrapper')).beforeStyles({
        opacity: 1
      }).fromTo('transform', 'translateX(0vh)', 'translateX(100vh)');
      var baseAnimation = Object(_ionic_core__WEBPACK_IMPORTED_MODULE_1__["createAnimation"])().addElement(baseEl).easing('cubic-bezier(0.32,0.72,0,1)').duration(duration).addAnimation([backdropAnimation, wrapperAnimation]);

      if (presentingEl) {
        var transformOffset = !CSS.supports('width', 'max(0px, 1px)') ? '30px' : 'max(30px, var(--ion-safe-area-top, 0px))';
        var modalTransform = presentingEl.tagName === 'ION-MODAL' && presentingEl.presentingElement !== undefined ? '-10px' : transformOffset;
        var bodyEl = document.body;
        var presentingAnimation = Object(_ionic_core__WEBPACK_IMPORTED_MODULE_1__["createAnimation"])().addElement(presentingEl).beforeClearStyles(['transform']).afterClearStyles(['transform']).onFinish(function (currentStep) {
          // only reset background color if this is the last card-style modal
          if (currentStep !== 1) {
            return;
          }

          presentingEl.style.setProperty('overflow', '');
          var numModals = Array.from(bodyEl.querySelectorAll('ion-modal')).filter(function (m) {
            return m.presentingElement !== undefined;
          }).length;

          if (numModals <= 1) {
            bodyEl.style.setProperty('background-color', '');
          }
        }).keyframes([{
          offset: 0,
          filter: 'contrast(0.85)',
          transform: "translateX(".concat(modalTransform, ")"),
          borderRadius: '10px 10px 0 0'
        }, {
          offset: 1,
          filter: 'contrast(1)',
          transform: 'translateX(0px) scale(1)',
          borderRadius: '0px'
        }]);
        baseAnimation.addAnimation(presentingAnimation);
      }

      return baseAnimation;
    };

    var RightEnterAnimation = function RightEnterAnimation(baseEl, presentingEl) {
      var duration = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : 700;
      var backdropAnimation = Object(_ionic_core__WEBPACK_IMPORTED_MODULE_1__["createAnimation"])() // tslint:disable-next-line:no-non-null-assertion
      .addElement(baseEl.querySelector('ion-backdrop')).fromTo('opacity', 0.01, 'var(--backdrop-opacity)').beforeStyles({
        'pointer-events': 'none'
      }).afterClearStyles(['pointer-events']);
      var wrapperAnimation = Object(_ionic_core__WEBPACK_IMPORTED_MODULE_1__["createAnimation"])() // tslint:disable-next-line:no-non-null-assertion
      .addElement(baseEl.querySelector('.modal-wrapper')).beforeStyles({
        opacity: 1
      }).fromTo('transform', 'translateX(100vh)', 'translateX(0vh)');
      var baseAnimation = Object(_ionic_core__WEBPACK_IMPORTED_MODULE_1__["createAnimation"])().addElement(baseEl).easing('cubic-bezier(0.32,0.72,0,1)').duration(500).beforeAddClass('show-modal').addAnimation([backdropAnimation, wrapperAnimation]);

      if (presentingEl) {
        /**
         * Fallback for browsers that does not support `max()` (ex: Firefox)
         * No need to wrry about statusbar padding since engines like Gecko
         * are not used as the engine for standlone Cordova/Capacitor apps
         */
        var transformOffset = !CSS.supports('width', 'max(0px, 1px)') ? '30px' : 'max(30px, var(--ion-safe-area-top, 0px))';
        var modalTransform = presentingEl.tagName === 'ION-MODAL' && presentingEl.presentingElement !== undefined ? '-10px' : transformOffset;
        var bodyEl = document.body;
        var finalTransform = "translateX(".concat(modalTransform, ")");
        var presentingAnimation = Object(_ionic_core__WEBPACK_IMPORTED_MODULE_1__["createAnimation"])().beforeStyles({
          transform: 'translateX(0)',
          'transform-origin': 'top center',
          overflow: 'hidden'
        }).afterStyles({
          transform: finalTransform
        }).beforeAddWrite(function () {
          return bodyEl.style.setProperty('background-color', 'black');
        }).addElement(presentingEl).keyframes([{
          offset: 0,
          filter: 'contrast(1)',
          transform: 'translateX(0px) scale(1)',
          borderRadius: '0px'
        }, {
          offset: 1,
          filter: 'contrast(0.85)',
          transform: finalTransform,
          borderRadius: '10px 10px 0 0'
        }]);
        baseAnimation.addAnimation(presentingAnimation);
      }

      return baseAnimation;
    };
    /***/

  },

  /***/
  "./src/app/pages/order-list/order-list.page.scss":
  /*!*******************************************************!*\
    !*** ./src/app/pages/order-list/order-list.page.scss ***!
    \*******************************************************/

  /*! exports provided: default */

  /***/
  function srcAppPagesOrderListOrderListPageScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "ion-img {\n  max-width: 90px;\n  width: 90px;\n  height: 90px;\n}\n\nion-img + div,\n.track-no-goods + div {\n  width: calc(100% - 100px);\n  margin-left: 10px;\n  font-size: 0.95em;\n}\n\n.order-overview-price {\n  margin-top: 6px;\n  font-size: 0.9em;\n  color: var(--ion-color-dark);\n}\n\n.order-date {\n  margin-top: 10px;\n  font-size: 0.9em;\n  color: var(--ion-color-dark);\n}\n\n.pager {\n  position: absolute;\n  bottom: 0;\n  margin-left: calc(50% - 20px);\n  background: rgba(0, 0, 0, 0.3);\n  font-size: 11px;\n  font-weight: normal;\n  width: 50px;\n  margin-bottom: 5px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Vc2Vycy9jaGFubmluZy9EZXNrdG9wL3lzdy1hcHAtc2VydmljZTQvc3JjL2FwcC9wYWdlcy9vcmRlci1saXN0L29yZGVyLWxpc3QucGFnZS5zY3NzIiwic3JjL2FwcC9wYWdlcy9vcmRlci1saXN0L29yZGVyLWxpc3QucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0UsZUFBQTtFQUNBLFdBQUE7RUFDQSxZQUFBO0FDQ0Y7O0FEQ0E7O0VBRUUseUJBQUE7RUFDQSxpQkFBQTtFQUNBLGlCQUFBO0FDRUY7O0FEQUE7RUFDRSxlQUFBO0VBQ0EsZ0JBQUE7RUFDQSw0QkFBQTtBQ0dGOztBRERBO0VBQ0UsZ0JBQUE7RUFDQSxnQkFBQTtFQUNBLDRCQUFBO0FDSUY7O0FEREE7RUFDRSxrQkFBQTtFQUNBLFNBQUE7RUFDQSw2QkFBQTtFQUNBLDhCQUFBO0VBQ0EsZUFBQTtFQUNBLG1CQUFBO0VBQ0EsV0FBQTtFQUNBLGtCQUFBO0FDSUYiLCJmaWxlIjoic3JjL2FwcC9wYWdlcy9vcmRlci1saXN0L29yZGVyLWxpc3QucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiaW9uLWltZyB7XG4gIG1heC13aWR0aDogOTBweDtcbiAgd2lkdGg6IDkwcHg7XG4gIGhlaWdodDogOTBweDtcbn1cbmlvbi1pbWcgKyBkaXYsXG4udHJhY2stbm8tZ29vZHMgKyBkaXYge1xuICB3aWR0aDogY2FsYygxMDAlIC0gMTAwcHgpO1xuICBtYXJnaW4tbGVmdDogMTBweDtcbiAgZm9udC1zaXplOiAwLjk1ZW07XG59XG4ub3JkZXItb3ZlcnZpZXctcHJpY2Uge1xuICBtYXJnaW4tdG9wOiA2cHg7XG4gIGZvbnQtc2l6ZTogMC45ZW07XG4gIGNvbG9yOiB2YXIoLS1pb24tY29sb3ItZGFyayk7XG59XG4ub3JkZXItZGF0ZSB7XG4gIG1hcmdpbi10b3A6IDEwcHg7XG4gIGZvbnQtc2l6ZTogMC45ZW07XG4gIGNvbG9yOiB2YXIoLS1pb24tY29sb3ItZGFyayk7XG59XG5cbi5wYWdlciB7XG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgYm90dG9tOiAwO1xuICBtYXJnaW4tbGVmdDogY2FsYyg1MCUgLSAyMHB4KTtcbiAgYmFja2dyb3VuZDogcmdiYSgwLCAwLCAwLCAwLjMpO1xuICBmb250LXNpemU6IDExcHg7XG4gIGZvbnQtd2VpZ2h0OiBub3JtYWw7XG4gIHdpZHRoOiA1MHB4O1xuICBtYXJnaW4tYm90dG9tOiA1cHg7XG59IiwiaW9uLWltZyB7XG4gIG1heC13aWR0aDogOTBweDtcbiAgd2lkdGg6IDkwcHg7XG4gIGhlaWdodDogOTBweDtcbn1cblxuaW9uLWltZyArIGRpdixcbi50cmFjay1uby1nb29kcyArIGRpdiB7XG4gIHdpZHRoOiBjYWxjKDEwMCUgLSAxMDBweCk7XG4gIG1hcmdpbi1sZWZ0OiAxMHB4O1xuICBmb250LXNpemU6IDAuOTVlbTtcbn1cblxuLm9yZGVyLW92ZXJ2aWV3LXByaWNlIHtcbiAgbWFyZ2luLXRvcDogNnB4O1xuICBmb250LXNpemU6IDAuOWVtO1xuICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLWRhcmspO1xufVxuXG4ub3JkZXItZGF0ZSB7XG4gIG1hcmdpbi10b3A6IDEwcHg7XG4gIGZvbnQtc2l6ZTogMC45ZW07XG4gIGNvbG9yOiB2YXIoLS1pb24tY29sb3ItZGFyayk7XG59XG5cbi5wYWdlciB7XG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgYm90dG9tOiAwO1xuICBtYXJnaW4tbGVmdDogY2FsYyg1MCUgLSAyMHB4KTtcbiAgYmFja2dyb3VuZDogcmdiYSgwLCAwLCAwLCAwLjMpO1xuICBmb250LXNpemU6IDExcHg7XG4gIGZvbnQtd2VpZ2h0OiBub3JtYWw7XG4gIHdpZHRoOiA1MHB4O1xuICBtYXJnaW4tYm90dG9tOiA1cHg7XG59Il19 */";
    /***/
  },

  /***/
  "./src/app/pages/order-list/order-list.page.ts":
  /*!*****************************************************!*\
    !*** ./src/app/pages/order-list/order-list.page.ts ***!
    \*****************************************************/

  /*! exports provided: OrderListPage */

  /***/
  function srcAppPagesOrderListOrderListPageTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "OrderListPage", function () {
      return OrderListPage;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");
    /* harmony import */


    var _components_index__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! ../../components/index */
    "./src/app/components/index.ts");
    /* harmony import */


    var _service_index__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ../../service/index */
    "./src/app/service/index.ts");
    /* harmony import */


    var js_base64__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! js-base64 */
    "./node_modules/js-base64/base64.js");
    /* harmony import */


    var js_base64__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(js_base64__WEBPACK_IMPORTED_MODULE_6__);
    /* harmony import */


    var _environments_environment__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
    /*! ../../../environments/environment */
    "./src/environments/environment.ts");
    /* harmony import */


    var moment__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(
    /*! moment */
    "./node_modules/moment/moment.js");
    /* harmony import */


    var moment__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(moment__WEBPACK_IMPORTED_MODULE_8__);
    /* harmony import */


    var _modal_transitions__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(
    /*! ../../modal-transitions */
    "./src/app/modal-transitions.ts");
    /* harmony import */


    var _modal_filter_filter_page__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(
    /*! ../modal/filter/filter.page */
    "./src/app/pages/modal/filter/filter.page.ts");

    var OrderListPage = /*#__PURE__*/function () {
      function OrderListPage(activeRoute, orderService, modalCtrl, commonUtils, router) {
        var _this = this;

        _classCallCheck(this, OrderListPage);

        this.activeRoute = activeRoute;
        this.orderService = orderService;
        this.modalCtrl = modalCtrl;
        this.commonUtils = commonUtils;
        this.router = router;
        this.selectedCity = '0';
        this.selectedArea = '0';
        this.selectedCityName = '全部';
        this.selectedAreaName = '全部';
        this.orderStatus = '999';
        this.platform = 'ALL';
        this.selectedDateValue = 'TODAY';
        this.dateFrom = moment__WEBPACK_IMPORTED_MODULE_8__().clone().set({
          hour: 0,
          minute: 0,
          second: 0
        }).format('YYYY-MM-DD HH:mm:ss');
        this.dateTo = moment__WEBPACK_IMPORTED_MODULE_8__().clone().set({
          hour: 23,
          minute: 59,
          second: 59
        }).format('YYYY-MM-DD HH:mm:ss');
        this.showMore = true;
        this.pageTotal = 0;
        this.pageIndex = _environments_environment__WEBPACK_IMPORTED_MODULE_7__["environment"].pageIndex;
        this.pageSize = _environments_environment__WEBPACK_IMPORTED_MODULE_7__["environment"].pageSize;
        this.queryString = '';
        this.orderList = [];
        this.loading = true;
        this.activeRoute.queryParams.subscribe(function (params) {
          if (!_this.commonUtils.isNullOrEmptyString(params.dateValue)) {
            _this.selectedDateValue = params.dateValue;
            _this.dateFrom = _this.commonUtils.generateFormatDate(_this.selectedDateValue).dateFrom;
            _this.dateTo = _this.commonUtils.generateFormatDate(_this.selectedDateValue).dateTo;
          }

          if (!_this.commonUtils.isNullOrEmptyString(params.status)) {
            _this.orderStatus = params.status;
          }
        });
      }

      _createClass(OrderListPage, [{
        key: "ngOnInit",
        value: function ngOnInit() {
          return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
            return regeneratorRuntime.wrap(function _callee$(_context) {
              while (1) {
                switch (_context.prev = _context.next) {
                  case 0:
                    _context.next = 2;
                    return this.loadOrderList(false);

                  case 2:
                    this.orderList = _context.sent;
                    this.loading = false;

                  case 4:
                  case "end":
                    return _context.stop();
                }
              }
            }, _callee, this);
          }));
        }
      }, {
        key: "loadOrderList",
        value: function loadOrderList() {
          var showLoading = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : true;
          return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee2() {
            var loading, payload, data, i, order, serviceData;
            return regeneratorRuntime.wrap(function _callee2$(_context2) {
              while (1) {
                switch (_context2.prev = _context2.next) {
                  case 0:
                    if (showLoading) {
                      loading = this.commonUtils.showLoading('正在加载...');
                    }

                    payload = {
                      pageIndex: this.pageIndex,
                      pageSize: this.pageSize,
                      name: this.queryString,
                      dateFrom: this.dateFrom,
                      dateTo: this.dateTo,
                      location: this.selectedCity === '0' ? '' : this.selectedCityName,
                      area: this.selectedArea === '0' ? '' : this.selectedAreaName,
                      orderStatus: this.orderStatus === '999' ? '' : this.orderStatus,
                      platform: this.platform === 'ALL' ? '' : this.platform
                    };
                    _context2.next = 4;
                    return this.orderService.getOrderList(payload);

                  case 4:
                    data = _context2.sent;

                    if (showLoading) {
                      this.commonUtils.hideLoadingSync(loading);
                    }

                    for (i = 0; i < data.list.length; i++) {
                      order = data.list[i];

                      if (order && order.serviceData) {
                        serviceData = JSON.parse(order.serviceData);
                        console.log(serviceData);
                        order.serviceDataContent = serviceData.content;
                      }
                    }

                    console.log(data);
                    this.showMore = data.list.length >= this.pageSize;
                    this.infiniteScroll.disabled = !this.showMore;
                    this.pageTotal = Math.ceil(data.count / this.pageSize);
                    return _context2.abrupt("return", data.list);

                  case 12:
                  case "end":
                    return _context2.stop();
                }
              }
            }, _callee2, this);
          }));
        }
      }, {
        key: "doRefresh",
        value: function doRefresh(event) {
          return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee3() {
            return regeneratorRuntime.wrap(function _callee3$(_context3) {
              while (1) {
                switch (_context3.prev = _context3.next) {
                  case 0:
                    this.pageIndex = 1;
                    _context3.next = 3;
                    return this.loadOrderList();

                  case 3:
                    this.orderList = _context3.sent;
                    event.target.complete();

                  case 5:
                  case "end":
                    return _context3.stop();
                }
              }
            }, _callee3, this);
          }));
        }
      }, {
        key: "onInfinite",
        value: function onInfinite(event) {
          return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee4() {
            var data;
            return regeneratorRuntime.wrap(function _callee4$(_context4) {
              while (1) {
                switch (_context4.prev = _context4.next) {
                  case 0:
                    this.pageIndex += 1;
                    _context4.next = 3;
                    return this.loadOrderList();

                  case 3:
                    data = _context4.sent;
                    this.orderList = [].concat(_toConsumableArray(this.orderList), _toConsumableArray(data));
                    event.target.complete();

                  case 6:
                  case "end":
                    return _context4.stop();
                }
              }
            }, _callee4, this);
          }));
        }
      }, {
        key: "onSearch",
        value: function onSearch(event) {
          var _this2 = this;

          if (this.timer) {
            clearTimeout(this.timer);
          }

          this.timer = setTimeout(function () {
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](_this2, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee5() {
              return regeneratorRuntime.wrap(function _callee5$(_context5) {
                while (1) {
                  switch (_context5.prev = _context5.next) {
                    case 0:
                      this.pageIndex = 1;
                      _context5.next = 3;
                      return this.loadOrderList();

                    case 3:
                      this.orderList = _context5.sent;

                    case 4:
                    case "end":
                      return _context5.stop();
                  }
                }
              }, _callee5, this);
            }));
          }, 2000);
        }
      }, {
        key: "onFilter",
        value: function onFilter() {
          return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee6() {
            var modal, _ref, data;

            return regeneratorRuntime.wrap(function _callee6$(_context6) {
              while (1) {
                switch (_context6.prev = _context6.next) {
                  case 0:
                    _context6.next = 2;
                    return this.modalCtrl.create({
                      component: _modal_filter_filter_page__WEBPACK_IMPORTED_MODULE_10__["FilterPage"],
                      componentProps: {
                        selectedDate: this.selectedDateValue,
                        selectedType: this.orderStatus,
                        selectedPlatform: this.platform,
                        selectedCity: this.selectedCity,
                        selectedArea: this.selectedArea,
                        selectedCityName: this.selectedCityName,
                        selectedAreaName: this.selectedAreaName
                      },
                      enterAnimation: _modal_transitions__WEBPACK_IMPORTED_MODULE_9__["RightEnterAnimation"],
                      leaveAnimation: _modal_transitions__WEBPACK_IMPORTED_MODULE_9__["RightLeaveAnimation"],
                      backdropDismiss: true,
                      cssClass: 'ysw-filter-modal-horizontal'
                    });

                  case 2:
                    modal = _context6.sent;
                    _context6.next = 5;
                    return modal.present();

                  case 5:
                    _context6.next = 7;
                    return modal.onWillDismiss();

                  case 7:
                    _ref = _context6.sent;
                    data = _ref.data;

                    if (this.commonUtils.isNull(data)) {
                      _context6.next = 23;
                      break;
                    }

                    this.pageIndex = 1;
                    this.selectedDateValue = data.dateValue;
                    this.dateFrom = data.dateFrom;
                    this.dateTo = data.dateTo;
                    this.selectedCity = data.selectedCity;
                    this.selectedArea = data.selectedArea;
                    this.selectedCityName = data.selectedCityName;
                    this.selectedAreaName = data.selectedAreaName;
                    this.orderStatus = data.selectedType;
                    this.platform = data.selectedPlatform;
                    _context6.next = 22;
                    return this.loadOrderList();

                  case 22:
                    this.orderList = _context6.sent;

                  case 23:
                  case "end":
                    return _context6.stop();
                }
              }
            }, _callee6, this);
          }));
        }
      }, {
        key: "imageError",
        value: function imageError(event) {
          event.target.src = 'assets/imgs/mat/goods-no-image.svg';
        }
      }, {
        key: "viewOrderDetail",
        value: function viewOrderDetail(order) {
          this.router.navigate(['../detail'], {
            relativeTo: this.activeRoute,
            queryParams: {
              orderId: js_base64__WEBPACK_IMPORTED_MODULE_6__["Base64"].encode(JSON.stringify(order.orderId))
            }
          });
        }
      }, {
        key: "genStatusColor",
        value: function genStatusColor(status) {
          var statusColor = '';

          switch (status) {
            case 52:
            case 55:
            case 54:
              statusColor = 'success';
              break;

            case 30:
            case 40:
            case 42:
              statusColor = 'primary';
              break;

            case 41:
            case -19:
            case -21:
              statusColor = 'warning';
              break;

            case -23:
              statusColor = 'info';
              break;

            case -22:
            case -12:
              statusColor = 'danger';
              break;

            case -10:
            case -11:
            case -13:
              statusColor = 'dark';
              break;

            default:
              return '';
          }

          return statusColor;
        }
      }]);

      return OrderListPage;
    }();

    OrderListPage.ctorParameters = function () {
      return [{
        type: _angular_router__WEBPACK_IMPORTED_MODULE_3__["ActivatedRoute"]
      }, {
        type: _service_index__WEBPACK_IMPORTED_MODULE_5__["OrderService"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ModalController"]
      }, {
        type: _components_index__WEBPACK_IMPORTED_MODULE_4__["CommonUtils"]
      }, {
        type: _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"]
      }];
    };

    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"])(_ionic_angular__WEBPACK_IMPORTED_MODULE_2__["IonInfiniteScroll"], {
      static: true
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["IonInfiniteScroll"])], OrderListPage.prototype, "infiniteScroll", void 0);
    OrderListPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-order-list',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./order-list.page.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/order-list/order-list.page.html")).default,
      providers: [_service_index__WEBPACK_IMPORTED_MODULE_5__["OrderService"]],
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./order-list.page.scss */
      "./src/app/pages/order-list/order-list.page.scss")).default]
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_3__["ActivatedRoute"], _service_index__WEBPACK_IMPORTED_MODULE_5__["OrderService"], _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ModalController"], _components_index__WEBPACK_IMPORTED_MODULE_4__["CommonUtils"], _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"]])], OrderListPage);
    /***/
  }
}]);
//# sourceMappingURL=default~order-detail-order-detail-module~order-list-order-list-module-es5.js.map