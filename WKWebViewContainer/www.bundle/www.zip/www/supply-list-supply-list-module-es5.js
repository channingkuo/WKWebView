function _toConsumableArray(arr) { return _arrayWithoutHoles(arr) || _iterableToArray(arr) || _nonIterableSpread(); }

function _nonIterableSpread() { throw new TypeError("Invalid attempt to spread non-iterable instance"); }

function _iterableToArray(iter) { if (Symbol.iterator in Object(iter) || Object.prototype.toString.call(iter) === "[object Arguments]") return Array.from(iter); }

function _arrayWithoutHoles(arr) { if (Array.isArray(arr)) { for (var i = 0, arr2 = new Array(arr.length); i < arr.length; i++) { arr2[i] = arr[i]; } return arr2; } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["supply-list-supply-list-module"], {
  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/supply-list/supply-list.page.html":
  /*!***********************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/supply-list/supply-list.page.html ***!
    \***********************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppPagesSupplyListSupplyListPageHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-header>\n  <ion-toolbar color=\"ysw\">\n    <ion-buttons slot=\"start\">\n      <ion-back-button></ion-back-button>\n    </ion-buttons>\n\n    <ion-title>\n      <ion-segment (ionChange)=\"segmentChanged($event)\" [value]=\"viewMode\">\n        <ion-segment-button value=\"supply-plan-list\">\n          <ion-label>补货计划</ion-label>\n        </ion-segment-button>\n        <ion-segment-button value=\"supply-storage-list\">\n          <ion-label>补货单</ion-label>\n        </ion-segment-button>\n      </ion-segment>\n    </ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <ion-refresher slot=\"fixed\" (ionRefresh)=\"doRefresh($event)\" pullMax=\"2000\">\n    <ion-refresher-content></ion-refresher-content>\n  </ion-refresher>\n\n  <ion-header>\n    <ion-toolbar color=\"ysw\">\n      <ion-title size=\"large\">{{viewMode === 'supply-plan-list' ? '补货计划' : '补货单'}}</ion-title>\n      <ion-buttons *ngIf=\"viewMode === 'supply-plan-list'\" slot=\"end\">\n        <ion-button (click)=\"onChooseStatus()\">\n          <ion-label class=\"icon-text-small\">筛选</ion-label>\n        </ion-button>\n      </ion-buttons>\n    </ion-toolbar>\n\n    <ion-toolbar color=\"ysw\">\n      <ion-searchbar color=\"light\" placeholder=\"售药机、单号、商品\" showCancelButton=\"focus\" cancelButtonText=\"取消\"\n        inputmode=\"search\" [(ngModel)]=\"queryString\" [debounce]=\"2000\" (ionInput)=\"onSearch($event)\"></ion-searchbar>\n    </ion-toolbar>\n  </ion-header>\n\n  <skeleton [loading]=\"loading\">\n    <ng-container [ngSwitch]=\"viewMode\">\n      <ion-list *ngSwitchCase=\"'supply-plan-list'\">\n        <ng-container *ngFor=\"let matSupplyPlan of matSupplyPlanList\">\n          <ion-card (click)=\"viewMatSupplyPlanDetails(matSupplyPlan)\">\n            <ion-card-header>\n              <ion-card-title class=\"flex ion-justify-content-between ion-align-items-center\">\n                <ion-label>\n                  {{matSupplyPlan.planNo | stringSecurity}}\n                  <ion-icon (yswClickStop)=\"copyMatSupplyPlanNumber(matSupplyPlan.planNo)\"\n                    style=\"font-size: 0.7em;margin-left: 2px;\" name=\"copy-outline\">\n                  </ion-icon>\n                </ion-label>\n                <ion-badge [color]=\"genLabelColor(matSupplyPlan.status)\">\n                  {{genLabelName(matSupplyPlan.status)}}\n                </ion-badge>\n              </ion-card-title>\n              <ion-card-subtitle class=\"flex ion-justify-content-between ion-align-items-center\">\n                <ion-label class=\"ion-text-wrap\">\n                  {{matSupplyPlan.matName}} <small>{{matSupplyPlan.matSerial}}</small>\n                </ion-label>\n              </ion-card-subtitle>\n            </ion-card-header>\n            <ion-card-content>\n              <div class=\"flex ion-justify-content-between ion-align-items-center content-line\">\n                <ion-label>计划类型：</ion-label>\n                <ion-text [color]=\"matSupplyPlan.type === 0 ? 'ysw' : 'danger'\" class=\"ion-float-right\">\n                  {{matSupplyPlan.type === 0 ? '补货' : '商品撤回'}}\n                </ion-text>\n              </div>\n              <div class=\"flex ion-justify-content-between ion-align-items-center content-line\">\n                <ion-label>创建人员：</ion-label>\n                <ion-label>{{matSupplyPlan.createdBy}}</ion-label>\n              </div>\n              <div class=\"flex ion-justify-content-between ion-align-items-center content-line\">\n                <ion-label>创建时间：</ion-label>\n                <ion-label>{{matSupplyPlan.createdDate| date: 'yyyy-MM-dd HH:mm:ss'}}</ion-label>\n              </div>\n              <div class=\"flex ion-justify-content-between ion-align-items-center content-line\">\n                <ion-label>最近修改：</ion-label>\n                <ion-label>{{matSupplyPlan.updatedDate| date: 'yyyy-MM-dd HH:mm:ss'}}</ion-label>\n              </div>\n            </ion-card-content>\n          </ion-card>\n        </ng-container>\n      </ion-list>\n      <ion-list *ngSwitchCase=\"'supply-storage-list'\">\n        <ng-container *ngFor=\"let matSupply of matSupplyList\">\n          <ion-card (click)=\"viewMatSupplyDetails(matSupply)\">\n            <ion-card-header>\n              <ion-card-title class=\"flex ion-justify-content-between ion-align-items-center\">\n                <ion-label>\n                  {{matSupply.supplyNo}}\n                  <ion-icon (yswClickStop)=\"copyMatSupplyPlanNumber(matSupply.supplyNo)\"\n                    style=\"font-size: 0.7em;margin-left: 2px;\" name=\"copy-outline\">\n                  </ion-icon>\n                </ion-label>\n              </ion-card-title>\n              <ion-card-subtitle>\n                <ion-label class=\"ion-text-wrap\">\n                  {{matSupply.matName}} <small>{{matSupply.matSerial}}</small>\n                </ion-label>\n              </ion-card-subtitle>\n            </ion-card-header>\n            <ion-card-content>\n              <div class=\"flex ion-justify-content-between ion-align-items-center content-line\">\n                <ion-label color=\"dark\">补货计划：</ion-label>\n                <ion-label>{{matSupply.planNo}}</ion-label>\n              </div>\n              <div class=\"flex ion-justify-content-between ion-align-items-center content-line\">\n                <ion-label color=\"dark\">创建人员：</ion-label>\n                <ion-label>{{matSupply.createdBy}}</ion-label>\n              </div>\n              <div class=\"flex ion-justify-content-between ion-align-items-center content-line\">\n                <ion-label color=\"dark\">创建时间：</ion-label>\n                <ion-label>{{matSupply.createdDate| date: 'yyyy-MM-dd HH:mm:ss'}}</ion-label>\n              </div>\n            </ion-card-content>\n          </ion-card>\n        </ng-container>\n      </ion-list>\n    </ng-container>\n\n    <empty-view [data]=\"viewMode === 'supply-plan-list' ? matSupplyPlanList : matSupplyList\" message=\"暂无数据~\">\n      <empty-content></empty-content>\n    </empty-view>\n\n    <ion-infinite-scroll threshold=\"100px\" (ionInfinite)=\"onInfinite($event)\">\n      <ion-infinite-scroll-content loadingSpinner=\"bubbles\" loadingText=\"加载更多...\">\n      </ion-infinite-scroll-content>\n    </ion-infinite-scroll>\n  </skeleton>\n</ion-content>";
    /***/
  },

  /***/
  "./src/app/pages/supply-list/supply-list.module.ts":
  /*!*********************************************************!*\
    !*** ./src/app/pages/supply-list/supply-list.module.ts ***!
    \*********************************************************/

  /*! exports provided: SupplyListPageModule */

  /***/
  function srcAppPagesSupplyListSupplyListModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "SupplyListPageModule", function () {
      return SupplyListPageModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/fesm2015/common.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/fesm2015/forms.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
    /* harmony import */


    var _supply_list_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ./supply-list.page */
    "./src/app/pages/supply-list/supply-list.page.ts");
    /* harmony import */


    var _module_index__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
    /*! ../module/index */
    "./src/app/pages/module/index.ts");

    var SupplyListPageModule = function SupplyListPageModule() {
      _classCallCheck(this, SupplyListPageModule);
    };

    SupplyListPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"], _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild([{
        path: 'list',
        component: _supply_list_page__WEBPACK_IMPORTED_MODULE_6__["SupplyListPage"]
      }, {
        path: 'detail',
        loadChildren: function loadChildren() {
          return __webpack_require__.e(
          /*! import() | supply-detail-supply-detail-module */
          "supply-detail-supply-detail-module").then(__webpack_require__.bind(null,
          /*! ../supply-detail/supply-detail.module */
          "./src/app/pages/supply-detail/supply-detail.module.ts")).then(function (m) {
            return m.SupplyDetailPageModule;
          });
        }
      }, {
        path: 'plan/detail',
        loadChildren: function loadChildren() {
          return Promise.all(
          /*! import() | supply-plan-detail-supply-plan-detail-module */
          [__webpack_require__.e("common"), __webpack_require__.e("supply-plan-detail-supply-plan-detail-module")]).then(__webpack_require__.bind(null,
          /*! ../supply-plan-detail/supply-plan-detail.module */
          "./src/app/pages/supply-plan-detail/supply-plan-detail.module.ts")).then(function (m) {
            return m.SupplyPlanDetailPageModule;
          });
        }
      }]), _module_index__WEBPACK_IMPORTED_MODULE_7__["EmptyModule"], _module_index__WEBPACK_IMPORTED_MODULE_7__["StringSecurityModule"], _module_index__WEBPACK_IMPORTED_MODULE_7__["StopPropagationModule"], _module_index__WEBPACK_IMPORTED_MODULE_7__["SkeletonModule"]],
      declarations: [_supply_list_page__WEBPACK_IMPORTED_MODULE_6__["SupplyListPage"]]
    })], SupplyListPageModule);
    /***/
  },

  /***/
  "./src/app/pages/supply-list/supply-list.page.scss":
  /*!*********************************************************!*\
    !*** ./src/app/pages/supply-list/supply-list.page.scss ***!
    \*********************************************************/

  /*! exports provided: default */

  /***/
  function srcAppPagesSupplyListSupplyListPageScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "ion-card-content {\n  padding: 0 15px 15px 15px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Vc2Vycy9jaGFubmluZy9EZXNrdG9wL3lzdy1hcHAtc2VydmljZTQvc3JjL2FwcC9wYWdlcy9zdXBwbHktbGlzdC9zdXBwbHktbGlzdC5wYWdlLnNjc3MiLCJzcmMvYXBwL3BhZ2VzL3N1cHBseS1saXN0L3N1cHBseS1saXN0LnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLHlCQUFBO0FDQ0YiLCJmaWxlIjoic3JjL2FwcC9wYWdlcy9zdXBwbHktbGlzdC9zdXBwbHktbGlzdC5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJpb24tY2FyZC1jb250ZW50IHtcbiAgcGFkZGluZzogMCAxNXB4IDE1cHggMTVweDtcbn0iLCJpb24tY2FyZC1jb250ZW50IHtcbiAgcGFkZGluZzogMCAxNXB4IDE1cHggMTVweDtcbn0iXX0= */";
    /***/
  },

  /***/
  "./src/app/pages/supply-list/supply-list.page.ts":
  /*!*******************************************************!*\
    !*** ./src/app/pages/supply-list/supply-list.page.ts ***!
    \*******************************************************/

  /*! exports provided: SupplyListPage */

  /***/
  function srcAppPagesSupplyListSupplyListPageTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "SupplyListPage", function () {
      return SupplyListPage;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");
    /* harmony import */


    var _components_index__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! ../../components/index */
    "./src/app/components/index.ts");
    /* harmony import */


    var _service_index__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ../../service/index */
    "./src/app/service/index.ts");
    /* harmony import */


    var _environments_environment__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ../../../environments/environment */
    "./src/environments/environment.ts");

    var SupplyListPage = /*#__PURE__*/function () {
      function SupplyListPage(activeRoute, router, pickerCtrl, commonUtils, nativeUtils, matService) {
        var _this = this;

        _classCallCheck(this, SupplyListPage);

        this.activeRoute = activeRoute;
        this.router = router;
        this.pickerCtrl = pickerCtrl;
        this.commonUtils = commonUtils;
        this.nativeUtils = nativeUtils;
        this.matService = matService;
        this.viewMode = _components_index__WEBPACK_IMPORTED_MODULE_4__["ProjectConstant"].VIEW_MODE_PLAN;
        this.queryString = '';
        this.status = null;
        this.showMore = true;
        this.pageSupplyPlanIndex = _environments_environment__WEBPACK_IMPORTED_MODULE_6__["environment"].pageIndex;
        this.pageSupplyIndex = _environments_environment__WEBPACK_IMPORTED_MODULE_6__["environment"].pageIndex;
        this.pageSize = _environments_environment__WEBPACK_IMPORTED_MODULE_6__["environment"].pageSize;
        this.matSupplyPlanList = [];
        this.matSupplyList = [];
        this.loading = true;
        this.activeRoute.queryParams.subscribe(function (params) {
          if (!_this.commonUtils.isNullOrEmptyString(params.viewMode)) {
            _this.viewMode = params.viewMode;
          }

          if (!_this.commonUtils.isNull(params.status)) {
            _this.status = parseInt(params.status, 10);
          }
        });
      }

      _createClass(SupplyListPage, [{
        key: "ngOnInit",
        value: function ngOnInit() {
          return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
            return regeneratorRuntime.wrap(function _callee$(_context) {
              while (1) {
                switch (_context.prev = _context.next) {
                  case 0:
                    if (!(this.viewMode === _components_index__WEBPACK_IMPORTED_MODULE_4__["ProjectConstant"].VIEW_MODE_PLAN)) {
                      _context.next = 6;
                      break;
                    }

                    _context.next = 3;
                    return this.loadMatSupplyPlanList(false);

                  case 3:
                    this.matSupplyPlanList = _context.sent;
                    _context.next = 10;
                    break;

                  case 6:
                    if (!(this.viewMode === _components_index__WEBPACK_IMPORTED_MODULE_4__["ProjectConstant"].VIEW_MODE_STORAGE)) {
                      _context.next = 10;
                      break;
                    }

                    _context.next = 9;
                    return this.loadMatSupplyList(false);

                  case 9:
                    this.matSupplyList = _context.sent;

                  case 10:
                    this.loading = false;

                  case 11:
                  case "end":
                    return _context.stop();
                }
              }
            }, _callee, this);
          }));
        }
      }, {
        key: "loadMatSupplyPlanList",
        value: function loadMatSupplyPlanList() {
          var showLoading = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : true;
          return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee2() {
            var loading, data;
            return regeneratorRuntime.wrap(function _callee2$(_context2) {
              while (1) {
                switch (_context2.prev = _context2.next) {
                  case 0:
                    if (showLoading) {
                      loading = this.commonUtils.showLoading('正在加载...');
                    }

                    _context2.next = 3;
                    return this.matService.getMatSupplyPlanList(this.queryString, this.pageSupplyPlanIndex, this.pageSize, this.status);

                  case 3:
                    data = _context2.sent;

                    if (showLoading) {
                      this.commonUtils.hideLoadingSync(loading);
                    }

                    this.showMore = data.list.length >= this.pageSize;
                    this.infiniteScroll.disabled = !this.showMore;
                    return _context2.abrupt("return", data.list);

                  case 8:
                  case "end":
                    return _context2.stop();
                }
              }
            }, _callee2, this);
          }));
        }
      }, {
        key: "loadMatSupplyList",
        value: function loadMatSupplyList() {
          var showLoading = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : true;
          return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee3() {
            var loading, data;
            return regeneratorRuntime.wrap(function _callee3$(_context3) {
              while (1) {
                switch (_context3.prev = _context3.next) {
                  case 0:
                    if (showLoading) {
                      loading = this.commonUtils.showLoading('正在加载...');
                    }

                    _context3.next = 3;
                    return this.matService.getMatSupplyList(this.queryString, this.pageSupplyIndex, this.pageSize);

                  case 3:
                    data = _context3.sent;

                    if (showLoading) {
                      this.commonUtils.hideLoadingSync(loading);
                    }

                    this.showMore = data.list.length >= this.pageSize;
                    this.infiniteScroll.disabled = !this.showMore;
                    return _context3.abrupt("return", data.list);

                  case 8:
                  case "end":
                    return _context3.stop();
                }
              }
            }, _callee3, this);
          }));
        }
      }, {
        key: "doRefresh",
        value: function doRefresh(event) {
          return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee4() {
            return regeneratorRuntime.wrap(function _callee4$(_context4) {
              while (1) {
                switch (_context4.prev = _context4.next) {
                  case 0:
                    if (!(this.viewMode === _components_index__WEBPACK_IMPORTED_MODULE_4__["ProjectConstant"].VIEW_MODE_PLAN)) {
                      _context4.next = 7;
                      break;
                    }

                    this.pageSupplyPlanIndex = 1;
                    _context4.next = 4;
                    return this.loadMatSupplyPlanList();

                  case 4:
                    this.matSupplyPlanList = _context4.sent;
                    _context4.next = 12;
                    break;

                  case 7:
                    if (!(this.viewMode === _components_index__WEBPACK_IMPORTED_MODULE_4__["ProjectConstant"].VIEW_MODE_STORAGE)) {
                      _context4.next = 12;
                      break;
                    }

                    this.pageSupplyIndex = 1;
                    _context4.next = 11;
                    return this.loadMatSupplyList();

                  case 11:
                    this.matSupplyList = _context4.sent;

                  case 12:
                    event.target.complete();

                  case 13:
                  case "end":
                    return _context4.stop();
                }
              }
            }, _callee4, this);
          }));
        }
      }, {
        key: "onInfinite",
        value: function onInfinite(event) {
          return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee5() {
            var data, _data;

            return regeneratorRuntime.wrap(function _callee5$(_context5) {
              while (1) {
                switch (_context5.prev = _context5.next) {
                  case 0:
                    if (!(this.viewMode === _components_index__WEBPACK_IMPORTED_MODULE_4__["ProjectConstant"].VIEW_MODE_PLAN)) {
                      _context5.next = 8;
                      break;
                    }

                    this.pageSupplyPlanIndex += 1;
                    _context5.next = 4;
                    return this.loadMatSupplyPlanList();

                  case 4:
                    data = _context5.sent;
                    this.matSupplyPlanList = [].concat(_toConsumableArray(this.matSupplyPlanList), _toConsumableArray(data));
                    _context5.next = 14;
                    break;

                  case 8:
                    if (!(this.viewMode === _components_index__WEBPACK_IMPORTED_MODULE_4__["ProjectConstant"].VIEW_MODE_STORAGE)) {
                      _context5.next = 14;
                      break;
                    }

                    this.pageSupplyIndex += 1;
                    _context5.next = 12;
                    return this.loadMatSupplyList();

                  case 12:
                    _data = _context5.sent;
                    this.matSupplyList = [].concat(_toConsumableArray(this.matSupplyList), _toConsumableArray(_data));

                  case 14:
                    event.target.complete();

                  case 15:
                  case "end":
                    return _context5.stop();
                }
              }
            }, _callee5, this);
          }));
        }
      }, {
        key: "onSearch",
        value: function onSearch(event) {
          var _this2 = this;

          if (this.timer) {
            clearTimeout(this.timer);
          }

          this.timer = setTimeout(function () {
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](_this2, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee6() {
              return regeneratorRuntime.wrap(function _callee6$(_context6) {
                while (1) {
                  switch (_context6.prev = _context6.next) {
                    case 0:
                      if (!(this.viewMode === _components_index__WEBPACK_IMPORTED_MODULE_4__["ProjectConstant"].VIEW_MODE_PLAN)) {
                        _context6.next = 7;
                        break;
                      }

                      this.pageSupplyPlanIndex = 1;
                      _context6.next = 4;
                      return this.loadMatSupplyPlanList();

                    case 4:
                      this.matSupplyPlanList = _context6.sent;
                      _context6.next = 12;
                      break;

                    case 7:
                      if (!(this.viewMode === _components_index__WEBPACK_IMPORTED_MODULE_4__["ProjectConstant"].VIEW_MODE_STORAGE)) {
                        _context6.next = 12;
                        break;
                      }

                      this.pageSupplyIndex = 1;
                      _context6.next = 11;
                      return this.loadMatSupplyList();

                    case 11:
                      this.matSupplyList = _context6.sent;

                    case 12:
                    case "end":
                      return _context6.stop();
                  }
                }
              }, _callee6, this);
            }));
          }, 2000);
        }
      }, {
        key: "onChooseStatus",
        value: function onChooseStatus() {
          return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee7() {
            var _this3 = this;

            var columnOptions, picker;
            return regeneratorRuntime.wrap(function _callee7$(_context7) {
              while (1) {
                switch (_context7.prev = _context7.next) {
                  case 0:
                    columnOptions = [{
                      text: '全部',
                      value: null,
                      duration: 250
                    }, {
                      text: '草稿',
                      value: -1,
                      duration: 250
                    }, {
                      text: '待验证',
                      value: 0,
                      duration: 250
                    }, {
                      text: '验证成功',
                      value: 1,
                      duration: 250
                    }, {
                      text: '验证失败',
                      value: 2,
                      duration: 250
                    }, {
                      text: '已完成',
                      value: 4,
                      duration: 250
                    }, {
                      text: '待核准',
                      value: 5,
                      duration: 250
                    }, {
                      text: '已核准',
                      value: 6,
                      duration: 250
                    }, {
                      text: '核准失败',
                      value: 7,
                      duration: 250
                    }];
                    _context7.next = 3;
                    return this.pickerCtrl.create({
                      columns: [{
                        name: 'status',
                        options: columnOptions,
                        selectedIndex: columnOptions.findIndex(function (option) {
                          return option.value === _this3.status;
                        })
                      }],
                      buttons: [{
                        text: '取消',
                        role: 'cancel'
                      }, {
                        text: '确认',
                        handler: function handler(value) {
                          _this3.status = value.status.value;
                          _this3.pageSupplyPlanIndex = 1;

                          _this3.loadMatSupplyPlanList().then(function (data) {
                            _this3.matSupplyPlanList = data;
                          });
                        }
                      }],
                      cssClass: 'ysw-picker'
                    });

                  case 3:
                    picker = _context7.sent;
                    _context7.next = 6;
                    return picker.present();

                  case 6:
                  case "end":
                    return _context7.stop();
                }
              }
            }, _callee7, this);
          }));
        }
      }, {
        key: "segmentChanged",
        value: function segmentChanged(event) {
          return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee8() {
            return regeneratorRuntime.wrap(function _callee8$(_context8) {
              while (1) {
                switch (_context8.prev = _context8.next) {
                  case 0:
                    this.viewMode = event.detail.value;
                    this.srcollToTop();

                    if (!(this.viewMode === _components_index__WEBPACK_IMPORTED_MODULE_4__["ProjectConstant"].VIEW_MODE_PLAN)) {
                      _context8.next = 11;
                      break;
                    }

                    if (!(this.matSupplyPlanList.length <= 0)) {
                      _context8.next = 8;
                      break;
                    }

                    this.pageSupplyPlanIndex = 1;
                    _context8.next = 7;
                    return this.loadMatSupplyPlanList();

                  case 7:
                    this.matSupplyPlanList = _context8.sent;

                  case 8:
                    this.showMore = this.matSupplyPlanList.length >= this.pageSize;
                    _context8.next = 18;
                    break;

                  case 11:
                    if (!(this.viewMode === _components_index__WEBPACK_IMPORTED_MODULE_4__["ProjectConstant"].VIEW_MODE_STORAGE)) {
                      _context8.next = 18;
                      break;
                    }

                    if (!(this.matSupplyList.length <= 0)) {
                      _context8.next = 17;
                      break;
                    }

                    this.pageSupplyIndex = 1;
                    _context8.next = 16;
                    return this.loadMatSupplyList();

                  case 16:
                    this.matSupplyList = _context8.sent;

                  case 17:
                    this.showMore = this.matSupplyList.length >= this.pageSize;

                  case 18:
                    this.infiniteScroll.disabled = !this.showMore;

                  case 19:
                  case "end":
                    return _context8.stop();
                }
              }
            }, _callee8, this);
          }));
        }
      }, {
        key: "viewMatSupplyPlanDetails",
        value: function viewMatSupplyPlanDetails(matSupplyPlan) {
          this.router.navigate(['../plan/detail'], {
            relativeTo: this.activeRoute,
            queryParams: {
              planId: matSupplyPlan.planId
            }
          });
        }
      }, {
        key: "viewMatSupplyDetails",
        value: function viewMatSupplyDetails(matSupply) {
          this.router.navigate(['../detail'], {
            relativeTo: this.activeRoute,
            queryParams: {
              supplyId: matSupply.supplyId
            }
          });
        }
      }, {
        key: "srcollToTop",
        value: function srcollToTop() {
          this.ionContent.scrollToTop(200);
        }
      }, {
        key: "copyMatSupplyPlanNumber",
        value: function copyMatSupplyPlanNumber(matSupplyPlanNumber) {
          this.nativeUtils.copyToClipboard(matSupplyPlanNumber);
        }
      }, {
        key: "genLabelColor",
        value: function genLabelColor(status) {
          switch (status) {
            case -1:
              return 'medium';

            case 0:
              return 'warning';

            case 1:
              return 'primary';

            case 2:
              return 'danger';

            case 3:
              return 'light';

            case 4:
              return 'success';

            case 5:
              return 'warning';

            case 6:
              return 'primary';

            case 7:
              return 'danger';

            default:
              return '';
          }
        }
      }, {
        key: "genLabelName",
        value: function genLabelName(status) {
          switch (status) {
            case -1:
              return '草稿';

            case 0:
              return '待验证';

            case 1:
              return '验证成功';

            case 2:
              return '验证失败';

            case 3:
              return '已作废';

            case 4:
              return '已完成';

            case 5:
              return '待核准';

            case 6:
              return '已核准';

            case 7:
              return '核准失败';

            default:
              return '--';
          }
        }
      }]);

      return SupplyListPage;
    }();

    SupplyListPage.ctorParameters = function () {
      return [{
        type: _angular_router__WEBPACK_IMPORTED_MODULE_3__["ActivatedRoute"]
      }, {
        type: _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["PickerController"]
      }, {
        type: _components_index__WEBPACK_IMPORTED_MODULE_4__["CommonUtils"]
      }, {
        type: _components_index__WEBPACK_IMPORTED_MODULE_4__["NativeUtils"]
      }, {
        type: _service_index__WEBPACK_IMPORTED_MODULE_5__["MatService"]
      }];
    };

    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"])(_ionic_angular__WEBPACK_IMPORTED_MODULE_2__["IonInfiniteScroll"], {
      static: true
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["IonInfiniteScroll"])], SupplyListPage.prototype, "infiniteScroll", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"])(_ionic_angular__WEBPACK_IMPORTED_MODULE_2__["IonContent"], {
      static: true
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["IonContent"])], SupplyListPage.prototype, "ionContent", void 0);
    SupplyListPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-supply-list',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./supply-list.page.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/supply-list/supply-list.page.html")).default,
      providers: [_service_index__WEBPACK_IMPORTED_MODULE_5__["MatService"]],
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./supply-list.page.scss */
      "./src/app/pages/supply-list/supply-list.page.scss")).default]
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_3__["ActivatedRoute"], _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"], _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["PickerController"], _components_index__WEBPACK_IMPORTED_MODULE_4__["CommonUtils"], _components_index__WEBPACK_IMPORTED_MODULE_4__["NativeUtils"], _service_index__WEBPACK_IMPORTED_MODULE_5__["MatService"]])], SupplyListPage);
    /***/
  }
}]);
//# sourceMappingURL=supply-list-supply-list-module-es5.js.map