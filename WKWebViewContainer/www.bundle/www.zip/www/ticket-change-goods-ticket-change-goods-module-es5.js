function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["ticket-change-goods-ticket-change-goods-module"], {
  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/ticket-change-goods/ticket-change-goods.page.html":
  /*!***************************************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/ticket-change-goods/ticket-change-goods.page.html ***!
    \***************************************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppPagesTicketChangeGoodsTicketChangeGoodsPageHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-header>\n  <ion-toolbar color=\"ysw\">\n    <ion-buttons slot=\"start\">\n      <ion-back-button></ion-back-button>\n    </ion-buttons>\n    <ion-title>替换商品列表</ion-title>\n    <ion-buttons collapse=\"true\" slot=\"end\" *ngIf=\"status === 0\">\n      <ion-button (click)=\"addChangeGoods()\">\n        <ion-icon name=\"add-outline\"></ion-icon>\n      </ion-button>\n    </ion-buttons>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <ion-header collapse=\"condense\">\n    <ion-toolbar color=\"ysw\">\n      <ion-title size=\"large\">替换商品列表</ion-title>\n      <ion-buttons collapse=\"true\" slot=\"end\" *ngIf=\"status === 0\">\n        <ion-button (click)=\"addChangeGoods()\">\n          <ion-icon name=\"add-outline\"></ion-icon>\n        </ion-button>\n      </ion-buttons>\n    </ion-toolbar>\n  </ion-header>\n\n  <ion-list>\n    <ng-container *ngFor=\"let goods of goodsList;index as i;\">\n      <ion-card>\n        <ion-card-content>\n          <ion-item-sliding>\n            <ion-item lines=\"none\">\n              <ion-label class=\"flex flex-column\" style=\"margin-right: 0;\">\n                <ion-label class=\"flex ion-justify-content-start ion-align-items-start goods-goods\">\n                  <ion-img (ionError)=\"imageError($event)\"\n                    [src]=\"goods.goods_thumb || 'assets/imgs/mat/goods-no-image.svg'\" [alt]=\"goods.goods_name\">\n                  </ion-img>\n                  <div class=\"flex ion-justify-content-center ion-align-items-start flex-column\">\n                    <ion-label class=\"flex ion-text-wrap goods-track\">\n                      货道：{{goods.goods_track}}\n                    </ion-label>\n                    <ion-label class=\"flex ion-text-wrap\">\n                      品牌：{{goods.brand_name}}\n                    </ion-label>\n                    <ion-label class=\"flex ion-text-wrap\">\n                      商品：{{goods.goods_name}}\n                    </ion-label>\n                    <ion-label class=\"flex ion-text-wrap\">\n                      规格：{{goods.goods_package}}\n                    </ion-label>\n                    <ion-label class=\"flex ion-text-wrap\">\n                      厂商：{{goods.mfr_name}}\n                    </ion-label>\n                  </div>\n                </ion-label>\n                <div class=\"flex ion-justify-content-center ion-align-items-center swap-icon\">\n                  <ion-icon name=\"swap-vertical-outline\"></ion-icon>\n                </div>\n                <ng-container *ngIf=\"goods.target_goods_id;else noTargetGoods\">\n                  <ion-label class=\"flex ion-justify-content-start ion-align-items-start goods-goods\">\n                    <ion-img (ionError)=\"imageError($event)\"\n                      [src]=\"goods.target_goods_thumb || 'assets/imgs/mat/goods-no-image.svg'\"\n                      [alt]=\"goods.target_goods_name\"></ion-img>\n                    <div class=\"flex ion-justify-content-center ion-align-items-start flex-column\">\n                      <ion-label class=\"flex ion-text-wrap\">\n                        品牌：{{goods.target_brand_name}}\n                      </ion-label>\n                      <ion-label class=\"flex ion-text-wrap\">\n                        商品：{{goods.target_goods_name}}\n                      </ion-label>\n                      <ion-label class=\"flex ion-text-wrap\">\n                        规格：{{goods.target_goods_package}}\n                      </ion-label>\n                      <ion-label class=\"flex ion-text-wrap\">\n                        厂商：{{goods.target_mfr_name}}\n                      </ion-label>\n                    </div>\n                  </ion-label>\n                </ng-container>\n                <ng-template #noTargetGoods>\n                  <ng-container *ngIf=\"goods.new_goods_name;else addGoods\">\n                    <ion-label class=\"flex flex-column ion-justify-content-center ion-align-items-start\">\n                      <ion-label class=\"flex ion-text-wrap\">\n                        商品名：{{goods.new_goods_brand + ' '}}{{goods.new_goods_name}}\n                      </ion-label>\n                      <ion-label class=\"flex ion-text-wrap\">\n                        规格：{{goods.new_goods_package}}\n                      </ion-label>\n                      <ion-label class=\"flex ion-text-wrap\">\n                        厂商：{{goods.new_goods_mfr}}\n                      </ion-label>\n                    </ion-label>\n                    <ion-label class=\"flex ion-text-wrap\">商品图片：</ion-label>\n                    <ion-label class=\"flex ion-justify-content-start ion-align-items-center ion-wrap\">\n                      <ng-container *ngFor=\"let image of ['', '1', '2']\">\n                        <ion-img class=\"new-goods-img\" (ionError)=\"imageError($event)\"\n                          [src]=\"goods['new_image' + image] || 'assets/imgs/mat/goods-no-image.svg'\"\n                          [alt]=\"goods.new_goods_name\">\n                        </ion-img>\n                      </ng-container>\n                    </ion-label>\n                    <ion-label class=\"comments-label\" *ngIf=\"goods.target_comments\">\n                      {{goods.target_comments}}\n                    </ion-label>\n                  </ng-container>\n                  <ng-template #addGoods>\n                    <div class=\"add-change-goods flex flex-column ion-justify-content-center ion-align-items-center\">\n                      <ion-label>未选择替换商品</ion-label>\n                    </div>\n                  </ng-template>\n                </ng-template>\n              </ion-label>\n            </ion-item>\n\n            <ion-item-options side=\"end\">\n              <ion-item-option color=\"primary\" (click)=\"onEdit(goods, i)\">修改</ion-item-option>\n              <ion-item-option color=\"danger\" (click)=\"onDelete(goods, i)\">删除</ion-item-option>\n            </ion-item-options>\n          </ion-item-sliding>\n        </ion-card-content>\n      </ion-card>\n    </ng-container>\n  </ion-list>\n</ion-content>";
    /***/
  },

  /***/
  "./src/app/pages/ticket-change-goods/ticket-change-goods.module.ts":
  /*!*************************************************************************!*\
    !*** ./src/app/pages/ticket-change-goods/ticket-change-goods.module.ts ***!
    \*************************************************************************/

  /*! exports provided: TicketChangeGoodsPageModule */

  /***/
  function srcAppPagesTicketChangeGoodsTicketChangeGoodsModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "TicketChangeGoodsPageModule", function () {
      return TicketChangeGoodsPageModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/fesm2015/common.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/fesm2015/forms.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
    /* harmony import */


    var _ticket_change_goods_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ./ticket-change-goods.page */
    "./src/app/pages/ticket-change-goods/ticket-change-goods.page.ts");
    /* harmony import */


    var _module_index__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
    /*! ../module/index */
    "./src/app/pages/module/index.ts");

    var TicketChangeGoodsPageModule = function TicketChangeGoodsPageModule() {
      _classCallCheck(this, TicketChangeGoodsPageModule);
    };

    TicketChangeGoodsPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"], _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild([{
        path: '',
        component: _ticket_change_goods_page__WEBPACK_IMPORTED_MODULE_6__["TicketChangeGoodsPage"]
      }]), _module_index__WEBPACK_IMPORTED_MODULE_7__["StopPropagationModule"]],
      declarations: [_ticket_change_goods_page__WEBPACK_IMPORTED_MODULE_6__["TicketChangeGoodsPage"]]
    })], TicketChangeGoodsPageModule);
    /***/
  },

  /***/
  "./src/app/pages/ticket-change-goods/ticket-change-goods.page.scss":
  /*!*************************************************************************!*\
    !*** ./src/app/pages/ticket-change-goods/ticket-change-goods.page.scss ***!
    \*************************************************************************/

  /*! exports provided: default */

  /***/
  function srcAppPagesTicketChangeGoodsTicketChangeGoodsPageScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "ion-item {\n  --padding-start: 0;\n  --inner-padding-end: 0;\n}\n\nion-item-options {\n  border-bottom-width: 0px !important;\n}\n\nion-img {\n  max-width: 100px;\n  width: 100px;\n  height: 100px;\n}\n\nion-img + div {\n  width: calc(100% - 110px);\n  margin-left: 10px;\n  font-size: 0.95em;\n}\n\n.goods-goods {\n  margin-right: 0px;\n}\n\n.swap-icon {\n  margin: 16px 0;\n}\n\n.swap-icon ion-icon {\n  font-size: 1.6em;\n}\n\n.goods-track {\n  font-size: 0.9em;\n  color: var(--ion-color-dark);\n}\n\n.system-no-goods {\n  text-align: center;\n  padding: 6px;\n  min-height: 60px;\n  line-height: 60px;\n  border: 0.55px dashed var(--ion-color-medium-tint);\n  border-radius: 10px;\n}\n\n.new-goods-img {\n  max-width: 60px;\n  width: 60px;\n  height: 60px;\n  margin-right: 10px;\n  margin-bottom: 10px;\n  flex-shrink: 0;\n  border: 0.55px solid var(--ion-color-light-shade);\n}\n\n.comments-label {\n  margin-top: 10px;\n  text-align: center;\n  padding: 6px;\n  min-height: 30px;\n  line-height: 30px;\n  border: 0.55px dashed var(--ion-color-medium-tint);\n  border-radius: 10px;\n  display: block;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Vc2Vycy9jaGFubmluZy9EZXNrdG9wL3lzdy1hcHAtc2VydmljZTQvc3JjL2FwcC9wYWdlcy90aWNrZXQtY2hhbmdlLWdvb2RzL3RpY2tldC1jaGFuZ2UtZ29vZHMucGFnZS5zY3NzIiwic3JjL2FwcC9wYWdlcy90aWNrZXQtY2hhbmdlLWdvb2RzL3RpY2tldC1jaGFuZ2UtZ29vZHMucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0Usa0JBQUE7RUFDQSxzQkFBQTtBQ0NGOztBRENBO0VBQ0UsbUNBQUE7QUNFRjs7QURBQTtFQUNFLGdCQUFBO0VBQ0EsWUFBQTtFQUNBLGFBQUE7QUNHRjs7QUREQTtFQUNFLHlCQUFBO0VBQ0EsaUJBQUE7RUFDQSxpQkFBQTtBQ0lGOztBREZBO0VBQ0UsaUJBQUE7QUNLRjs7QURIQTtFQUNFLGNBQUE7QUNNRjs7QURKRTtFQUNFLGdCQUFBO0FDTUo7O0FESEE7RUFDRSxnQkFBQTtFQUNBLDRCQUFBO0FDTUY7O0FESkE7RUFDRSxrQkFBQTtFQUNBLFlBQUE7RUFDQSxnQkFBQTtFQUNBLGlCQUFBO0VBQ0Esa0RBQUE7RUFDQSxtQkFBQTtBQ09GOztBRExBO0VBQ0UsZUFBQTtFQUNBLFdBQUE7RUFDQSxZQUFBO0VBQ0Esa0JBQUE7RUFDQSxtQkFBQTtFQUNBLGNBQUE7RUFDQSxpREFBQTtBQ1FGOztBRE5BO0VBQ0UsZ0JBQUE7RUFDQSxrQkFBQTtFQUNBLFlBQUE7RUFDQSxnQkFBQTtFQUNBLGlCQUFBO0VBQ0Esa0RBQUE7RUFDQSxtQkFBQTtFQUNBLGNBQUE7QUNTRiIsImZpbGUiOiJzcmMvYXBwL3BhZ2VzL3RpY2tldC1jaGFuZ2UtZ29vZHMvdGlja2V0LWNoYW5nZS1nb29kcy5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJpb24taXRlbSB7XG4gIC0tcGFkZGluZy1zdGFydDogMDtcbiAgLS1pbm5lci1wYWRkaW5nLWVuZDogMDtcbn1cbmlvbi1pdGVtLW9wdGlvbnMge1xuICBib3JkZXItYm90dG9tLXdpZHRoOiAwcHggIWltcG9ydGFudDtcbn1cbmlvbi1pbWcge1xuICBtYXgtd2lkdGg6IDEwMHB4O1xuICB3aWR0aDogMTAwcHg7XG4gIGhlaWdodDogMTAwcHg7XG59XG5pb24taW1nICsgZGl2IHtcbiAgd2lkdGg6IGNhbGMoMTAwJSAtIDExMHB4KTtcbiAgbWFyZ2luLWxlZnQ6IDEwcHg7XG4gIGZvbnQtc2l6ZTogMC45NWVtO1xufVxuLmdvb2RzLWdvb2RzIHtcbiAgbWFyZ2luLXJpZ2h0OiAwcHg7XG59XG4uc3dhcC1pY29uIHtcbiAgbWFyZ2luOiAxNnB4IDA7XG5cbiAgaW9uLWljb24ge1xuICAgIGZvbnQtc2l6ZTogMS42ZW07XG4gIH1cbn1cbi5nb29kcy10cmFjayB7XG4gIGZvbnQtc2l6ZTogMC45ZW07XG4gIGNvbG9yOiB2YXIoLS1pb24tY29sb3ItZGFyayk7XG59XG4uc3lzdGVtLW5vLWdvb2RzIHtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xuICBwYWRkaW5nOiA2cHg7XG4gIG1pbi1oZWlnaHQ6IDYwcHg7XG4gIGxpbmUtaGVpZ2h0OiA2MHB4O1xuICBib3JkZXI6IDAuNTVweCBkYXNoZWQgdmFyKC0taW9uLWNvbG9yLW1lZGl1bS10aW50KTtcbiAgYm9yZGVyLXJhZGl1czogMTBweDtcbn1cbi5uZXctZ29vZHMtaW1nIHtcbiAgbWF4LXdpZHRoOiA2MHB4O1xuICB3aWR0aDogNjBweDtcbiAgaGVpZ2h0OiA2MHB4O1xuICBtYXJnaW4tcmlnaHQ6IDEwcHg7XG4gIG1hcmdpbi1ib3R0b206IDEwcHg7XG4gIGZsZXgtc2hyaW5rOiAwO1xuICBib3JkZXI6IDAuNTVweCBzb2xpZCB2YXIoLS1pb24tY29sb3ItbGlnaHQtc2hhZGUpO1xufVxuLmNvbW1lbnRzLWxhYmVsIHtcbiAgbWFyZ2luLXRvcDogMTBweDtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xuICBwYWRkaW5nOiA2cHg7XG4gIG1pbi1oZWlnaHQ6IDMwcHg7XG4gIGxpbmUtaGVpZ2h0OiAzMHB4O1xuICBib3JkZXI6IDAuNTVweCBkYXNoZWQgdmFyKC0taW9uLWNvbG9yLW1lZGl1bS10aW50KTtcbiAgYm9yZGVyLXJhZGl1czogMTBweDtcbiAgZGlzcGxheTogYmxvY2s7XG59XG4iLCJpb24taXRlbSB7XG4gIC0tcGFkZGluZy1zdGFydDogMDtcbiAgLS1pbm5lci1wYWRkaW5nLWVuZDogMDtcbn1cblxuaW9uLWl0ZW0tb3B0aW9ucyB7XG4gIGJvcmRlci1ib3R0b20td2lkdGg6IDBweCAhaW1wb3J0YW50O1xufVxuXG5pb24taW1nIHtcbiAgbWF4LXdpZHRoOiAxMDBweDtcbiAgd2lkdGg6IDEwMHB4O1xuICBoZWlnaHQ6IDEwMHB4O1xufVxuXG5pb24taW1nICsgZGl2IHtcbiAgd2lkdGg6IGNhbGMoMTAwJSAtIDExMHB4KTtcbiAgbWFyZ2luLWxlZnQ6IDEwcHg7XG4gIGZvbnQtc2l6ZTogMC45NWVtO1xufVxuXG4uZ29vZHMtZ29vZHMge1xuICBtYXJnaW4tcmlnaHQ6IDBweDtcbn1cblxuLnN3YXAtaWNvbiB7XG4gIG1hcmdpbjogMTZweCAwO1xufVxuLnN3YXAtaWNvbiBpb24taWNvbiB7XG4gIGZvbnQtc2l6ZTogMS42ZW07XG59XG5cbi5nb29kcy10cmFjayB7XG4gIGZvbnQtc2l6ZTogMC45ZW07XG4gIGNvbG9yOiB2YXIoLS1pb24tY29sb3ItZGFyayk7XG59XG5cbi5zeXN0ZW0tbm8tZ29vZHMge1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gIHBhZGRpbmc6IDZweDtcbiAgbWluLWhlaWdodDogNjBweDtcbiAgbGluZS1oZWlnaHQ6IDYwcHg7XG4gIGJvcmRlcjogMC41NXB4IGRhc2hlZCB2YXIoLS1pb24tY29sb3ItbWVkaXVtLXRpbnQpO1xuICBib3JkZXItcmFkaXVzOiAxMHB4O1xufVxuXG4ubmV3LWdvb2RzLWltZyB7XG4gIG1heC13aWR0aDogNjBweDtcbiAgd2lkdGg6IDYwcHg7XG4gIGhlaWdodDogNjBweDtcbiAgbWFyZ2luLXJpZ2h0OiAxMHB4O1xuICBtYXJnaW4tYm90dG9tOiAxMHB4O1xuICBmbGV4LXNocmluazogMDtcbiAgYm9yZGVyOiAwLjU1cHggc29saWQgdmFyKC0taW9uLWNvbG9yLWxpZ2h0LXNoYWRlKTtcbn1cblxuLmNvbW1lbnRzLWxhYmVsIHtcbiAgbWFyZ2luLXRvcDogMTBweDtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xuICBwYWRkaW5nOiA2cHg7XG4gIG1pbi1oZWlnaHQ6IDMwcHg7XG4gIGxpbmUtaGVpZ2h0OiAzMHB4O1xuICBib3JkZXI6IDAuNTVweCBkYXNoZWQgdmFyKC0taW9uLWNvbG9yLW1lZGl1bS10aW50KTtcbiAgYm9yZGVyLXJhZGl1czogMTBweDtcbiAgZGlzcGxheTogYmxvY2s7XG59Il19 */";
    /***/
  },

  /***/
  "./src/app/pages/ticket-change-goods/ticket-change-goods.page.ts":
  /*!***********************************************************************!*\
    !*** ./src/app/pages/ticket-change-goods/ticket-change-goods.page.ts ***!
    \***********************************************************************/

  /*! exports provided: TicketChangeGoodsPage */

  /***/
  function srcAppPagesTicketChangeGoodsTicketChangeGoodsPageTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "TicketChangeGoodsPage", function () {
      return TicketChangeGoodsPage;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _components_index__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! ../../components/index */
    "./src/app/components/index.ts");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
    /* harmony import */


    var _ticket_list_ticket_list_page__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ../ticket-list/ticket-list.page */
    "./src/app/pages/ticket-list/ticket-list.page.ts");
    /* harmony import */


    var _ticket_detail_ticket_detail_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ../ticket-detail/ticket-detail.page */
    "./src/app/pages/ticket-detail/ticket-detail.page.ts");
    /* harmony import */


    var _modal_ticket_goods_swap_ticket_goods_swap_page__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
    /*! ../modal/ticket-goods-swap/ticket-goods-swap.page */
    "./src/app/pages/modal/ticket-goods-swap/ticket-goods-swap.page.ts");
    /* harmony import */


    var _service_index__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(
    /*! ../../service/index */
    "./src/app/service/index.ts");

    var TicketChangeGoodsPage = /*#__PURE__*/function () {
      function TicketChangeGoodsPage(commonUtils, activeRoute, storageUtils, ticketService, ticketDetailPage, modalCtrl) {
        var _this = this;

        _classCallCheck(this, TicketChangeGoodsPage);

        this.commonUtils = commonUtils;
        this.activeRoute = activeRoute;
        this.storageUtils = storageUtils;
        this.ticketService = ticketService;
        this.ticketDetailPage = ticketDetailPage;
        this.modalCtrl = modalCtrl;
        this.goodsList = [];
        this.activeRoute.queryParams.subscribe(function (params) {
          _this.matId = params.matId;
          _this.status = parseInt(params.status, 10);
        });
        this.goodsList = this.storageUtils.get(_components_index__WEBPACK_IMPORTED_MODULE_2__["ProjectConstant"].STORAGE_KEY_TICKET_GOODS_LIST);

        if (this.goodsList.length > 0) {
          this.ticketId = this.goodsList[0].ticket_id;
        }

        this.userInfo = this.storageUtils.get(_components_index__WEBPACK_IMPORTED_MODULE_2__["ProjectConstant"].STORAGE_KEY_USERINFO);
      }

      _createClass(TicketChangeGoodsPage, [{
        key: "ngOnInit",
        value: function ngOnInit() {}
      }, {
        key: "addChangeGoods",
        value: function addChangeGoods() {
          return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
            var modal, _ref, data, payload;

            return regeneratorRuntime.wrap(function _callee$(_context) {
              while (1) {
                switch (_context.prev = _context.next) {
                  case 0:
                    _context.next = 2;
                    return this.modalCtrl.create({
                      component: _modal_ticket_goods_swap_ticket_goods_swap_page__WEBPACK_IMPORTED_MODULE_7__["TicketGoodsSwapPage"],
                      componentProps: {
                        matId: this.matId
                      },
                      swipeToClose: true
                    });

                  case 2:
                    modal = _context.sent;
                    _context.next = 5;
                    return modal.present();

                  case 5:
                    _context.next = 7;
                    return modal.onWillDismiss();

                  case 7:
                    _ref = _context.sent;
                    data = _ref.data;

                    if (this.commonUtils.isNull(data)) {
                      _context.next = 22;
                      break;
                    }

                    console.log(data);

                    if (!this.checkHasExchangeGoods(data)) {
                      _context.next = 14;
                      break;
                    }

                    this.commonUtils.showToast('该商品已经在更换商品列表中...');
                    return _context.abrupt("return");

                  case 14:
                    payload = Object.assign({}, data);
                    payload.ticket_id = this.ticketId;
                    _context.next = 18;
                    return this.ticketDetailPage.saveTicketGoods(payload);

                  case 18:
                    _context.next = 20;
                    return this.ticketDetailPage.loadTicketExChangeGoodsList(this.ticketId);

                  case 20:
                    this.goodsList = _context.sent;
                    this.storageUtils.set(_components_index__WEBPACK_IMPORTED_MODULE_2__["ProjectConstant"].STORAGE_KEY_REFRESH, true);

                  case 22:
                  case "end":
                    return _context.stop();
                }
              }
            }, _callee, this);
          }));
        }
      }, {
        key: "onEdit",
        value: function onEdit(goods, index) {
          return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee2() {
            var modal, _ref2, data, payload;

            return regeneratorRuntime.wrap(function _callee2$(_context2) {
              while (1) {
                switch (_context2.prev = _context2.next) {
                  case 0:
                    if (!this.checkCanEdit()) {
                      _context2.next = 20;
                      break;
                    }

                    _context2.next = 3;
                    return this.modalCtrl.create({
                      component: _modal_ticket_goods_swap_ticket_goods_swap_page__WEBPACK_IMPORTED_MODULE_7__["TicketGoodsSwapPage"],
                      componentProps: {
                        ticketGoods: Object.assign({}, goods),
                        matId: this.matId
                      },
                      swipeToClose: true
                    });

                  case 3:
                    modal = _context2.sent;
                    _context2.next = 6;
                    return modal.present();

                  case 6:
                    _context2.next = 8;
                    return modal.onWillDismiss();

                  case 8:
                    _ref2 = _context2.sent;
                    data = _ref2.data;

                    if (this.commonUtils.isNull(data)) {
                      _context2.next = 18;
                      break;
                    }

                    payload = Object.assign({}, data);
                    _context2.next = 14;
                    return this.ticketDetailPage.saveTicketGoods(payload);

                  case 14:
                    _context2.next = 16;
                    return this.ticketDetailPage.loadTicketExChangeGoodsList(this.ticketId);

                  case 16:
                    this.goodsList = _context2.sent;
                    this.storageUtils.set(_components_index__WEBPACK_IMPORTED_MODULE_2__["ProjectConstant"].STORAGE_KEY_REFRESH, true);

                  case 18:
                    _context2.next = 21;
                    break;

                  case 20:
                    this.commonUtils.showToast('当前状态不可修改！');

                  case 21:
                  case "end":
                    return _context2.stop();
                }
              }
            }, _callee2, this);
          }));
        }
      }, {
        key: "onDelete",
        value: function onDelete(goods, index) {
          return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee3() {
            var res, loading;
            return regeneratorRuntime.wrap(function _callee3$(_context3) {
              while (1) {
                switch (_context3.prev = _context3.next) {
                  case 0:
                    if (!this.checkCanEdit()) {
                      _context3.next = 12;
                      break;
                    }

                    _context3.next = 3;
                    return this.commonUtils.showConfirm('确认', '确认删除该记录？');

                  case 3:
                    res = _context3.sent;

                    if (!res) {
                      _context3.next = 10;
                      break;
                    }

                    loading = this.commonUtils.showLoading('正在删除...');
                    _context3.next = 8;
                    return this.ticketService.deleteTicketGoods(goods);

                  case 8:
                    this.commonUtils.hideLoadingSync(loading);
                    this.goodsList.splice(index, 1);

                  case 10:
                    _context3.next = 13;
                    break;

                  case 12:
                    this.commonUtils.showToast('当前状态不可修改！');

                  case 13:
                  case "end":
                    return _context3.stop();
                }
              }
            }, _callee3, this);
          }));
        }
      }, {
        key: "checkHasExchangeGoods",
        value: function checkHasExchangeGoods(target) {
          var result = false;
          var _iteratorNormalCompletion = true;
          var _didIteratorError = false;
          var _iteratorError = undefined;

          try {
            for (var _iterator = this.goodsList[Symbol.iterator](), _step; !(_iteratorNormalCompletion = (_step = _iterator.next()).done); _iteratorNormalCompletion = true) {
              var goods = _step.value;

              if (goods.goods_id === target.goods_id && goods.goods_track === target.goods_track) {
                result = true;
                break;
              }
            }
          } catch (err) {
            _didIteratorError = true;
            _iteratorError = err;
          } finally {
            try {
              if (!_iteratorNormalCompletion && _iterator.return != null) {
                _iterator.return();
              }
            } finally {
              if (_didIteratorError) {
                throw _iteratorError;
              }
            }
          }

          return result;
        }
      }, {
        key: "checkCanEdit",
        value: function checkCanEdit() {
          var canPopModal = false;

          if (this.status === 0) {
            canPopModal = true;
          } else if (this.status === 1) {
            canPopModal = this.userInfo.role === _components_index__WEBPACK_IMPORTED_MODULE_2__["ProjectConstant"].ROLE_SUPER_ADMIN || this.userInfo.role === _components_index__WEBPACK_IMPORTED_MODULE_2__["ProjectConstant"].ROLE_SERIVICE && (this.userInfo.type === _components_index__WEBPACK_IMPORTED_MODULE_2__["ProjectConstant"].AGENT_LEADER || this.userInfo.type === _components_index__WEBPACK_IMPORTED_MODULE_2__["ProjectConstant"].AGENT_STORE_HEADER);
          } else if (this.status === 2) {
            canPopModal = false;
          }

          return canPopModal;
        }
      }, {
        key: "imageError",
        value: function imageError(event) {
          event.target.src = 'assets/imgs/mat/goods-no-image.svg';
        }
      }, {
        key: "ngOnDestroy",
        value: function ngOnDestroy() {
          this.storageUtils.remove(_components_index__WEBPACK_IMPORTED_MODULE_2__["ProjectConstant"].STORAGE_KEY_TICKET_GOODS_LIST);
        }
      }]);

      return TicketChangeGoodsPage;
    }();

    TicketChangeGoodsPage.ctorParameters = function () {
      return [{
        type: _components_index__WEBPACK_IMPORTED_MODULE_2__["CommonUtils"]
      }, {
        type: _angular_router__WEBPACK_IMPORTED_MODULE_3__["ActivatedRoute"]
      }, {
        type: _components_index__WEBPACK_IMPORTED_MODULE_2__["StorageUtils"]
      }, {
        type: _service_index__WEBPACK_IMPORTED_MODULE_8__["TicketService"]
      }, {
        type: _ticket_detail_ticket_detail_page__WEBPACK_IMPORTED_MODULE_6__["TicketDetailPage"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["ModalController"]
      }];
    };

    TicketChangeGoodsPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-ticket-change-goods',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./ticket-change-goods.page.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/ticket-change-goods/ticket-change-goods.page.html")).default,
      providers: [_service_index__WEBPACK_IMPORTED_MODULE_8__["TicketService"], _ticket_list_ticket_list_page__WEBPACK_IMPORTED_MODULE_5__["TicketListPage"], _ticket_detail_ticket_detail_page__WEBPACK_IMPORTED_MODULE_6__["TicketDetailPage"]],
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./ticket-change-goods.page.scss */
      "./src/app/pages/ticket-change-goods/ticket-change-goods.page.scss")).default]
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_components_index__WEBPACK_IMPORTED_MODULE_2__["CommonUtils"], _angular_router__WEBPACK_IMPORTED_MODULE_3__["ActivatedRoute"], _components_index__WEBPACK_IMPORTED_MODULE_2__["StorageUtils"], _service_index__WEBPACK_IMPORTED_MODULE_8__["TicketService"], _ticket_detail_ticket_detail_page__WEBPACK_IMPORTED_MODULE_6__["TicketDetailPage"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["ModalController"]])], TicketChangeGoodsPage);
    /***/
  }
}]);
//# sourceMappingURL=ticket-change-goods-ticket-change-goods-module-es5.js.map