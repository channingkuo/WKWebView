(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["mat-th-alert-mat-th-alert-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/mat-th-alert/mat-th-alert.page.html":
/*!*************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/mat-th-alert/mat-th-alert.page.html ***!
  \*************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\n  <ion-toolbar color=\"ysw\">\n    <ion-buttons slot=\"start\">\n      <ion-back-button></ion-back-button>\n    </ion-buttons>\n\n    <ion-title>\n      <ion-segment (ionChange)=\"segmentChanged($event)\" [value]=\"viewMode\">\n        <ion-segment-button value=\"T\">\n          <ion-label>温度</ion-label>\n        </ion-segment-button>\n        <ion-segment-button value=\"H\">\n          <ion-label>湿度</ion-label>\n        </ion-segment-button>\n      </ion-segment>\n    </ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <ion-refresher slot=\"fixed\" (ionRefresh)=\"doRefresh($event)\" pullMax=\"2000\">\n    <ion-refresher-content></ion-refresher-content>\n  </ion-refresher>\n\n  <ion-header>\n    <ion-toolbar color=\"ysw\" style=\"padding-top: 0;\">\n      <ion-title size=\"large\">{{viewMode === 'T' ? '温度警报' : '湿度警报'}}</ion-title>\n\n      <ion-buttons slot=\"end\">\n        <ion-buttons collapse=\"true\" slot=\"end\">\n          <ion-button (click)=\"onChooseCityArea()\">\n            <ion-label class=\"icon-text-small\">{{buttonText}}</ion-label>\n          </ion-button>\n        </ion-buttons>\n      </ion-buttons>\n    </ion-toolbar>\n\n    <ion-toolbar color=\"ysw\" collapse=\"condense\">\n      <ion-searchbar color=\"light\" placeholder=\"售药机名称、编号\" showCancelButton=\"focus\" cancelButtonText=\"取消\"\n        inputmode=\"search\" [(ngModel)]=\"queryString\" [debounce]=\"2000\" (ionInput)=\"onSearch($event)\"></ion-searchbar>\n    </ion-toolbar>\n  </ion-header>\n\n  <skeleton [loading]=\"loading\">\n    <ng-container [ngSwitch]=\"viewMode\">\n      <ion-list *ngSwitchCase=\"'T'\">\n        <ng-container *ngFor=\"let t of matTAlert\">\n          <ion-card>\n            <ion-card-header>\n              <ion-card-title class=\"flex ion-justify-content-between ion-align-item-center\">\n                <ion-label>{{t.matName}}</ion-label>\n                <ion-badge color=\"danger\" *ngIf=\"t.status === 0\" style=\"height: 20px;\">待处理</ion-badge>\n              </ion-card-title>\n              <ion-card-subtitle>\n                <ion-label>{{t.matSerial}}</ion-label>\n              </ion-card-subtitle>\n            </ion-card-header>\n            <ion-card-content class=\"flex flex-column\">\n              <ion-label style=\"font-size: 0.9em;\">\n                持续时间：\n              </ion-label>\n              <ion-label color=\"danger\">\n                <ion-label>\n                  {{t.createdDate| date: 'yyyy-MM-dd HH:mm:ss'}}{{' ~ '}}\n                </ion-label>\n                <ion-label>\n                  <ng-container *ngIf=\"t.fixedTime;else notFixed\">\n                    {{t.fixedTime| date: 'yyyy-MM-dd HH:mm:ss'}}\n                  </ng-container>\n                  <ng-template #notFixed>\n                    现在\n                  </ng-template>\n                </ion-label>\n              </ion-label>\n            </ion-card-content>\n          </ion-card>\n        </ng-container>\n      </ion-list>\n      <ion-list *ngSwitchCase=\"'H'\">\n        <ng-container *ngFor=\"let h of matHAlert\">\n          <ion-card>\n            <ion-card-header>\n              <ion-card-title class=\"flex ion-justify-content-between ion-align-item-center\">\n                <ion-label>{{h.matName}}</ion-label>\n                <ion-label color=\"danger\" *ngIf=\"h.status === 0\" style=\"height: 20px;\">待处理</ion-label>\n              </ion-card-title>\n              <ion-card-subtitle>\n                <ion-label>{{h.matSerial}}</ion-label>\n              </ion-card-subtitle>\n            </ion-card-header>\n            <ion-card-content class=\"flex flex-column\">\n              <ion-label color=\"dark\">\n                持续时间\n              </ion-label>\n              <ion-label style=\"font-size: 0.9em;\">\n                <ion-label>\n                  {{h.createdDate| date: 'yyyy-MM-dd HH:mm:ss'}}{{' ~ '}}\n                </ion-label>\n                <ion-label>\n                  <ng-container *ngIf=\"h.fixedTime;else notFixed\">\n                    {{h.fixedTime| date: 'yyyy-MM-dd HH:mm:ss'}}\n                  </ng-container>\n                  <ng-template #notFixed>\n                    现在\n                  </ng-template>\n                </ion-label>\n              </ion-label>\n            </ion-card-content>\n          </ion-card>\n        </ng-container>\n      </ion-list>\n    </ng-container>\n\n    <empty-view [data]=\"viewMode === 'T' ? matTAlert : matHAlert\" message=\"暂无警报数据~\">\n      <empty-content></empty-content>\n    </empty-view>\n  </skeleton>\n</ion-content>");

/***/ }),

/***/ "./src/app/pages/mat-th-alert/mat-th-alert.module.ts":
/*!***********************************************************!*\
  !*** ./src/app/pages/mat-th-alert/mat-th-alert.module.ts ***!
  \***********************************************************/
/*! exports provided: MatThAlertPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MatThAlertPageModule", function() { return MatThAlertPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm2015/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
/* harmony import */ var _mat_th_alert_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./mat-th-alert.page */ "./src/app/pages/mat-th-alert/mat-th-alert.page.ts");
/* harmony import */ var _module_index__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../module/index */ "./src/app/pages/module/index.ts");








let MatThAlertPageModule = class MatThAlertPageModule {
};
MatThAlertPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"],
            _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild([
                {
                    path: '',
                    component: _mat_th_alert_page__WEBPACK_IMPORTED_MODULE_6__["MatThAlertPage"]
                }
            ]),
            _module_index__WEBPACK_IMPORTED_MODULE_7__["EmptyModule"],
            _module_index__WEBPACK_IMPORTED_MODULE_7__["SkeletonModule"]
        ],
        declarations: [_mat_th_alert_page__WEBPACK_IMPORTED_MODULE_6__["MatThAlertPage"]]
    })
], MatThAlertPageModule);



/***/ }),

/***/ "./src/app/pages/mat-th-alert/mat-th-alert.page.scss":
/*!***********************************************************!*\
  !*** ./src/app/pages/mat-th-alert/mat-th-alert.page.scss ***!
  \***********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3BhZ2VzL21hdC10aC1hbGVydC9tYXQtdGgtYWxlcnQucGFnZS5zY3NzIn0= */");

/***/ }),

/***/ "./src/app/pages/mat-th-alert/mat-th-alert.page.ts":
/*!*********************************************************!*\
  !*** ./src/app/pages/mat-th-alert/mat-th-alert.page.ts ***!
  \*********************************************************/
/*! exports provided: MatThAlertPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MatThAlertPage", function() { return MatThAlertPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _service_index__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../service/index */ "./src/app/service/index.ts");
/* harmony import */ var _components_index__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../components/index */ "./src/app/components/index.ts");






let MatThAlertPage = class MatThAlertPage {
    constructor(matService, commonUtils, router, activatedRoute) {
        this.matService = matService;
        this.commonUtils = commonUtils;
        this.router = router;
        this.activatedRoute = activatedRoute;
        this.viewMode = _components_index__WEBPACK_IMPORTED_MODULE_5__["ProjectConstant"].VIEW_MODE_T;
        this.buttonText = '全部';
        this.selectedCity = '0';
        this.selectedArea = '0';
        this.queryString = '';
        this.matTAlert = [];
        this.matHAlert = [];
        this.loading = true;
    }
    ngOnInit() {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            if (this.viewMode === _components_index__WEBPACK_IMPORTED_MODULE_5__["ProjectConstant"].VIEW_MODE_T) {
                this.matTAlert = yield this.loadData();
            }
            else if (this.viewMode === _components_index__WEBPACK_IMPORTED_MODULE_5__["ProjectConstant"].VIEW_MODE_H) {
                this.matHAlert = yield this.loadData();
            }
            this.loading = false;
        });
    }
    loadData() {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            // const loading = this.commonUtils.showLoading();
            const alertType = this.viewMode === _components_index__WEBPACK_IMPORTED_MODULE_5__["ProjectConstant"].VIEW_MODE_T ? 0 : 1;
            const data = yield this.matService.getMatTHAlertInfo(alertType, this.queryString, this.selectedCity, this.selectedArea);
            // this.commonUtils.hideLoadingSync(loading);
            return data;
        });
    }
    doRefresh(event) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            if (this.viewMode === _components_index__WEBPACK_IMPORTED_MODULE_5__["ProjectConstant"].VIEW_MODE_T) {
                this.matTAlert = yield this.loadData();
            }
            else if (this.viewMode === _components_index__WEBPACK_IMPORTED_MODULE_5__["ProjectConstant"].VIEW_MODE_H) {
                this.matHAlert = yield this.loadData();
            }
            event.target.complete();
        });
    }
    onSearch(event) {
        if (this.timer) {
            clearTimeout(this.timer);
        }
        this.timer = setTimeout(() => tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            if (this.viewMode === _components_index__WEBPACK_IMPORTED_MODULE_5__["ProjectConstant"].VIEW_MODE_T) {
                this.matTAlert = yield this.loadData();
            }
            else if (this.viewMode === _components_index__WEBPACK_IMPORTED_MODULE_5__["ProjectConstant"].VIEW_MODE_H) {
                this.matHAlert = yield this.loadData();
            }
        }), 2000);
    }
    onChooseCityArea() {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            const data = yield this.commonUtils.popLocationPicker(this.selectedCity, this.selectedArea);
            this.selectedCity = data.city.value;
            this.selectedArea = data.area.value;
            if (this.selectedCity === '0') {
                this.buttonText = '全部';
            }
            else {
                this.buttonText = data.city.text;
                if (this.selectedArea !== '0') {
                    this.buttonText += ', ' + data.area.text;
                }
            }
            if (this.viewMode === _components_index__WEBPACK_IMPORTED_MODULE_5__["ProjectConstant"].VIEW_MODE_T) {
                this.matTAlert = yield this.loadData();
            }
            else if (this.viewMode === _components_index__WEBPACK_IMPORTED_MODULE_5__["ProjectConstant"].VIEW_MODE_H) {
                this.matHAlert = yield this.loadData();
            }
        });
    }
    segmentChanged(event) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            this.viewMode = event.detail.value;
            this.srcollToTop();
            if (this.viewMode === _components_index__WEBPACK_IMPORTED_MODULE_5__["ProjectConstant"].VIEW_MODE_T) {
                if (this.matTAlert.length <= 0) {
                    this.matTAlert = yield this.loadData();
                }
            }
            else if (this.viewMode === _components_index__WEBPACK_IMPORTED_MODULE_5__["ProjectConstant"].VIEW_MODE_H) {
                if (this.matHAlert.length <= 0) {
                    this.matHAlert = yield this.loadData();
                }
            }
        });
    }
    srcollToTop() {
        this.ionContent.scrollToTop(200);
    }
};
MatThAlertPage.ctorParameters = () => [
    { type: _service_index__WEBPACK_IMPORTED_MODULE_4__["MatService"] },
    { type: _components_index__WEBPACK_IMPORTED_MODULE_5__["CommonUtils"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_3__["ActivatedRoute"] }
];
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"])(_ionic_angular__WEBPACK_IMPORTED_MODULE_2__["IonContent"], { static: true }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["IonContent"])
], MatThAlertPage.prototype, "ionContent", void 0);
MatThAlertPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-mat-th-alert',
        template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./mat-th-alert.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/mat-th-alert/mat-th-alert.page.html")).default,
        providers: [_service_index__WEBPACK_IMPORTED_MODULE_4__["MatService"]],
        styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./mat-th-alert.page.scss */ "./src/app/pages/mat-th-alert/mat-th-alert.page.scss")).default]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_service_index__WEBPACK_IMPORTED_MODULE_4__["MatService"],
        _components_index__WEBPACK_IMPORTED_MODULE_5__["CommonUtils"],
        _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"],
        _angular_router__WEBPACK_IMPORTED_MODULE_3__["ActivatedRoute"]])
], MatThAlertPage);



/***/ })

}]);
//# sourceMappingURL=mat-th-alert-mat-th-alert-module-es2015.js.map