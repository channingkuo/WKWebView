(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["default~ticket-change-goods-ticket-change-goods-module~ticket-detail-ticket-detail-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/ticket-detail/ticket-detail.page.html":
/*!***************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/ticket-detail/ticket-detail.page.html ***!
  \***************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\n  <ion-toolbar color=\"ysw\">\n    <ion-buttons slot=\"start\">\n      <ion-back-button></ion-back-button>\n    </ion-buttons>\n    <ion-title>{{ticketId ? '工单详情' : '新工单'}}</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <ion-header collapse=\"condense\">\n    <ion-toolbar color=\"ysw\">\n      <ion-title size=\"large\">{{ticketId ? '工单详情' : '新工单'}}</ion-title>\n    </ion-toolbar>\n  </ion-header>\n\n  <ion-list>\n    <card-swap [editing]=\"editing\" [disabled]=\"!ticketId\" (switch)=\"onEditMainTicket($event)\">\n      <div slot=\"front\">\n        <ion-card>\n          <ion-card-header>\n            <ion-card-title class=\"flex ion-justify-content-between ion-align-items-center\">\n              <ion-label>\n                {{ticketData.ticket_no}}\n                <ion-icon (click)=\"copyOrderNumber(ticketData.ticket_no)\" style=\"font-size: 0.7em;margin-left: 2px;\"\n                  name=\"copy-outline\">\n                </ion-icon>\n              </ion-label>\n              <ion-badge [color]=\"genStatusColor(ticketData.ticket_status)\">\n                {{genStatusName(ticketData.ticket_status)}}\n              </ion-badge>\n            </ion-card-title>\n            <ion-card-subtitle>\n              <ion-label>{{ticketData.mat_name}} <small>{{ticketData.external_no}}</small></ion-label>\n            </ion-card-subtitle>\n          </ion-card-header>\n          <ion-card-content>\n            <div class=\"flex ion-justify-content-between ion-align-items-center content-line\">\n              <ion-label>工单类型：</ion-label>\n              <ion-label [color]=\"genTicketTypeColor(ticketData.ticket_type)\">{{genTicketType(ticketData.ticket_type)}}\n              </ion-label>\n            </div>\n            <div class=\"flex ion-justify-content-between ion-align-items-center content-line\">\n              <ion-label>工单主题：</ion-label>\n              <ion-label>{{ticketData.ticket_subject}}</ion-label>\n            </div>\n            <div class=\"flex ion-justify-content-between ion-align-items-center content-line\">\n              <ion-label>工单描述：</ion-label>\n              <ion-label>{{ticketData.description || '-'}}</ion-label>\n            </div>\n            <collaspe-line>\n              <div class=\"flex ion-justify-content-between ion-align-items-center content-line\">\n                <ion-label>负责人员：</ion-label>\n                <ion-label>{{ticketData.owner_name || '-'}}</ion-label>\n              </div>\n              <div class=\"flex ion-justify-content-between ion-align-items-center content-line\">\n                <ion-label>创建人员：</ion-label>\n                <ion-label>{{ticketData.created_by_name}}</ion-label>\n              </div>\n              <div class=\"flex ion-justify-content-between ion-align-items-center content-line\">\n                <ion-label>创建时间：</ion-label>\n                <ion-label>{{ticketData.created_date| date: 'yyyy-MM-dd HH:mm:ss'}}</ion-label>\n              </div>\n              <div class=\"flex ion-justify-content-between ion-align-items-center content-line\">\n                <ion-label>修改人员：</ion-label>\n                <ion-label>{{ticketData.updated_by_name}}</ion-label>\n              </div>\n              <div class=\"flex ion-justify-content-between ion-align-items-center content-line\">\n                <ion-label>最近修改：</ion-label>\n                <ion-label>{{ticketData.updated_date| date: 'yyyy-MM-dd HH:mm:ss'}}</ion-label>\n              </div>\n            </collaspe-line>\n\n            <div class=\"b-b-split\"></div>\n\n            <div *ngIf=\"ticketData.ticket_status <= 1 && !isStorePriv\" class=\"text-center m-t-10\">\n              <ion-button *ngIf=\"ticketData.ticket_status === 0\" (click)=\"setTicketPadding()\" fill=\"outline\"\n                expand=\"block\" color=\"danger\">\n                设置成处理中\n              </ion-button>\n              <ion-button *ngIf=\"ticketData.ticket_status === 1\" (click)=\"setTicketFinished()\" fill=\"outline\"\n                expand=\"block\" color=\"danger\">\n                处理完成\n              </ion-button>\n            </div>\n          </ion-card-content>\n        </ion-card>\n      </div>\n      <div slot=\"back\">\n        <ion-card>\n          <ion-card-header>\n            <ion-card-title class=\"flex ion-justify-content-between ion-align-items-center\">\n              <ion-label>{{ticketData.ticket_no || '请填写下列内容'}}</ion-label>\n              <ion-badge [color]=\"genStatusColor(ticketData.ticket_status)\">\n                {{genStatusName(ticketData.ticket_status)}}\n              </ion-badge>\n            </ion-card-title>\n          </ion-card-header>\n\n          <ion-card-content style=\"padding: 0;\">\n            <ion-item (click)=\"onChooseMat()\" button detail>\n              <ion-label class=\"flex ion-justify-content-start ion-align-items-center\">\n                关联售药机\n                <ion-label color=\"danger\">*</ion-label>：\n                <ion-label *ngIf=\"ticketData.mat_id\">{{ticketData.mat_name}}</ion-label>\n                <ion-label *ngIf=\"!ticketData.mat_id\" style=\"color: #9a9a9a;\">请选择售药机</ion-label>\n              </ion-label>\n            </ion-item>\n            <ion-item>\n              <ion-label class=\"flex ion-justify-content-start ion-align-items-center\">\n                工单主题\n                <ion-label color=\"danger\">*</ion-label>：\n              </ion-label>\n              <ion-input [(ngModel)]=\"ticketData.ticket_subject\" clearInput type=\"text\" placeholder=\"请填写工单主题\"\n                style=\"margin-left: 5px;\"></ion-input>\n            </ion-item>\n            <ion-item>\n              <ion-label>工单描述：</ion-label>\n              <ion-textarea [(ngModel)]=\"ticketData.description\" placeholder=\"请填写工单描述内容\" style=\"margin-left: 12px;\">\n              </ion-textarea>\n            </ion-item>\n            <ion-item (click)=\"onChooseType()\" button detail>\n              <ion-label class=\"flex ion-justify-content-start ion-align-items-center\">\n                工单类型\n                <ion-label color=\"danger\">*</ion-label>：\n                <ion-label *ngIf=\"ticketData.ticket_type\" style=\"margin-left: 12px;\">\n                  {{genTicketType(ticketData.ticket_type)}}</ion-label>\n                <ion-label *ngIf=\"!ticketData.ticket_type\" style=\"margin-left: 12px;color: #9a9a9a;\">请选择工单类型</ion-label>\n              </ion-label>\n            </ion-item>\n            <ion-item *ngIf=\"ticketId\" (click)=\"onChooseOwner()\" button detail>\n              <ion-label class=\"flex ion-justify-content-start ion-align-items-center\">\n                负责人\n                <ion-label color=\"danger\">*</ion-label>：\n                <ion-label *ngIf=\"ticketData.owner_id\" style=\"margin-left: 25px;\">{{ticketData.owner_name}}</ion-label>\n                <ion-label *ngIf=\"!ticketData.owner_id\" style=\"margin-left: 25px;color: #9a9a9a;\">请选择工单负责人</ion-label>\n              </ion-label>\n            </ion-item>\n            <!--\n            <ion-item disabled>\n              <ion-label class=\"flex ion-justify-content-start ion-align-items-center\">\n                工单状态\n                <ion-label color=\"danger\">*</ion-label>：\n                {{genStatusName(ticketData.ticket_status)}}\n              </ion-label>\n            </ion-item>\n            <ion-item disabled>\n              <ion-label class=\"ion-text-wrap\">\n                创建人：{{(ticketData.created_by_name || '-') + ' @ ' }}{{ticketData.created_date| date: 'yyyy-MM-dd HH:mm:ss'}}\n              </ion-label>\n            </ion-item>\n            <ion-item disabled>\n              <ion-label class=\"ion-text-wrap\">\n                修改人：{{(ticketData.updated_by_name || '-') + ' @ ' }}{{ticketData.updated_date| date: 'yyyy-MM-dd HH:mm:ss'}}\n              </ion-label>\n            </ion-item>\n            -->\n            <div class=\"action-buttons flex ion-justify-content-around ion-align-items-center\">\n              <ion-button class=\"w-45p\" size=\"small\" (click)=\"onReset()\" expand=\"block\" color=\"medium\">重 置</ion-button>\n              <ion-button class=\"w-45p\" size=\"small\" (click)=\"onSaveTicket()\" expand=\"block\" color=\"ysw\">保 存\n              </ion-button>\n            </div>\n          </ion-card-content>\n        </ion-card>\n      </div>\n    </card-swap>\n\n    <ng-container [ngSwitch]=\"ticketData.ticket_type\">\n      <ng-container *ngSwitchCase=\"3\">\n        <ion-card>\n          <split-label class=\"\">新建商品列表</split-label>\n\n          <ion-icon *ngIf=\"goodsList.length > 0 && ticketData.ticket_status === 0\" (click)=\"addNewGoods()\"\n            class=\"add-change-goods-icon\" color=\"dark\" name=\"add-outline\">\n          </ion-icon>\n          <ion-card-content class=\"m-t-5\" style=\"padding: 0;\">\n            <ng-container *ngFor=\"let goods of goodsList;index as i;\">\n              <ion-item-sliding>\n                <ion-item class=\"change-goods-scroll\">\n                  \n                  <ion-thumbnail item-start>\n                    <img [src]=\"goods.new_image\" />\n                  </ion-thumbnail>\n\n                  <ion-label (click)=\"viewNewGoods(goods)\" class=\"text-large\" style=\"margin-left: 10px;\">\n                    {{goods.new_goods_brand}} {{goods.new_goods_name}}\n                    \n                    <ion-label style=\"font-size: 13px;\">\n                      {{goods.new_goods_package}}\n                    </ion-label>\n                    <ion-label style=\"font-size: 13px;\">\n                      {{goods.new_goods_mfr}}\n                    </ion-label>\n                  </ion-label>\n                </ion-item>\n\n                <ion-item-options side=\"end\">\n                  <!--\n                  <ion-item-option color=\"primary\" (click)=\"viewNewGoods(goods, i)\">修改</ion-item-option>\n                  -->\n                  <ion-item-option color=\"danger\" (click)=\"onDelete(goods, i)\">删除</ion-item-option>\n                </ion-item-options>\n              </ion-item-sliding>\n            </ng-container>\n\n            <div (click)=\"addNewGoods()\" *ngIf=\"ticketData.ticket_status !== 2\" style=\"margin: 20px 10px 10px 10px;\"\n              class=\"add-change-goods flex flex-column ion-justify-content-center ion-align-items-center\">\n              <ion-icon name=\"add-outline\"></ion-icon>\n              <ion-label>点击新建商品</ion-label>\n            </div>\n          </ion-card-content>\n        </ion-card>\n      </ng-container>\n      <ng-container *ngSwitchCase=\"1\">\n        <ion-card>\n          <split-label class=\"\">更换商品列表</split-label>\n\n          <ion-icon *ngIf=\"goodsList.length > 0 && ticketData.ticket_status === 0\" (click)=\"addChangeGoods()\"\n            class=\"add-change-goods-icon\" color=\"dark\" name=\"add-outline\">\n          </ion-icon>\n          <ion-card-content class=\"m-t-5\" style=\"padding: 0;\">\n            <ng-container *ngFor=\"let goods of goodsList;index as i;\">\n              <ion-item-sliding>\n                <ion-item lines=\"none\"\n                  class=\"change-goods-scroll flex ion-justify-content-between ion-align-items-center\">\n                  <ion-label (click)=\"viewTrack(goods)\" class=\"text-large\">{{goods.goods_track}}</ion-label>\n\n                  <ion-label (click)=\"viewChangeGoods(goods)\">\n                    <ion-thumbnail class=\"change-goods-thumb\">\n                      <img [src]=\"goods.goods_thumb\" />\n                    </ion-thumbnail>\n                  </ion-label>\n\n                  <ion-label (click)=\"viewChangeGoods(goods)\"\n                    class=\"flex ion-justify-content-center ion-align-items-center\">\n                    <ion-icon class=\"text-large\" name=\"swap-horizontal-outline\"></ion-icon>\n                  </ion-label>\n\n                  <ion-label (click)=\"viewChangeGoods(goods)\">\n                    <ion-thumbnail class=\"change-goods-thumb\">\n                      <img [src]=\"goods.target_goods_thumb\" />\n                    </ion-thumbnail>\n                  </ion-label>\n                </ion-item>\n\n                <ion-item-options side=\"end\">\n                  <ion-item-option color=\"primary\" (click)=\"onEdit(goods, i)\">修改</ion-item-option>\n                  <ion-item-option color=\"danger\" (click)=\"onDelete(goods, i)\">删除</ion-item-option>\n                </ion-item-options>\n              </ion-item-sliding>\n            </ng-container>\n\n            <div (click)=\"addChangeGoods()\" *ngIf=\"ticketData.ticket_status !== 2\" style=\"margin: 20px 10px 10px 10px;\"\n              class=\"add-change-goods flex flex-column ion-justify-content-center ion-align-items-center\">\n              <ion-icon name=\"add-outline\"></ion-icon>\n              <ion-label>点击添加需更换的商品</ion-label>\n            </div>\n          </ion-card-content>\n        </ion-card>\n      </ng-container>\n      <ng-container *ngSwitchCase=\"2\">\n        <ion-card>\n          <!-- <ion-card-header>\n            <ion-card-title>\n              abc——机器异常\n            </ion-card-title>\n            <ion-card-subtitle>\n              abc\n            </ion-card-subtitle>\n          </ion-card-header> -->\n          <ion-card-content style=\"padding: 15px;\">\n            <div class=\"add-change-goods flex ion-justify-content-center ion-align-items-center\">\n              <ion-label>机器警报暂时请在PC上新建</ion-label>\n            </div>\n          </ion-card-content>\n        </ion-card>\n      </ng-container>\n      <!--\n      <ng-container *ngSwitchDefault>\n        <ion-card>\n          <ion-card-content>\n            <div class=\"add-change-goods flex ion-justify-content-center ion-align-items-center\"\n              style=\"padding-top: 10px;\">\n              <ion-label>请先选择工单类型</ion-label>\n            </div>\n          </ion-card-content>\n        </ion-card>\n      </ng-container>-->\n    </ng-container>\n  </ion-list>\n</ion-content>");

/***/ }),

/***/ "./src/app/pages/ticket-detail/ticket-detail.page.scss":
/*!*************************************************************!*\
  !*** ./src/app/pages/ticket-detail/ticket-detail.page.scss ***!
  \*************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".add-change-goods {\n  border: 0.55px dashed var(--ion-color-medium-tint);\n  padding: 2px 0 10px 0;\n  border-radius: 10px;\n  font-size: 13px;\n}\n.add-change-goods ion-icon {\n  font-size: 2em;\n  color: var(--ion-color-medium-tint);\n}\n.add-change-goods ion-label {\n  color: var(--ion-color-medium-tint);\n}\n.add-change-goods:active {\n  background-color: var(--ion-color-light);\n}\n.change-goods-scroll {\n  overflow-x: auto;\n  overflow-y: hidden;\n}\n.change-goods-card {\n  position: relative;\n  overflow: visible;\n  margin-top: 0;\n}\n.add-change-goods-icon {\n  position: absolute;\n  right: 4px;\n  top: -28px;\n  font-size: 2em;\n}\n.change-goods-scroll::-webkit-scrollbar {\n  display: none !important;\n}\n.change-goods-thumb {\n  --size: 60px;\n  --border-radius: 6px;\n  border-radius: 6px;\n  border: 0.55px solid var(--ion-color-light);\n  flex-shrink: 0;\n}\n.action-buttons {\n  padding: 15px;\n}\n.action-buttons ion-button {\n  height: 36px;\n}\nion-item-options {\n  border-bottom-width: 0px !important;\n}\nion-item-option {\n  font-size: 14px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Vc2Vycy9jaGFubmluZy9EZXNrdG9wL3lzdy1hcHAtc2VydmljZTQvc3JjL2FwcC9wYWdlcy90aWNrZXQtZGV0YWlsL3RpY2tldC1kZXRhaWwucGFnZS5zY3NzIiwic3JjL2FwcC9wYWdlcy90aWNrZXQtZGV0YWlsL3RpY2tldC1kZXRhaWwucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0Usa0RBQUE7RUFDQSxxQkFBQTtFQUNBLG1CQUFBO0VBQ0EsZUFBQTtBQ0NGO0FEQ0U7RUFDRSxjQUFBO0VBQ0EsbUNBQUE7QUNDSjtBRENFO0VBQ0UsbUNBQUE7QUNDSjtBREVBO0VBQ0Usd0NBQUE7QUNDRjtBRENBO0VBQ0UsZ0JBQUE7RUFDQSxrQkFBQTtBQ0VGO0FEQUE7RUFDRSxrQkFBQTtFQUNBLGlCQUFBO0VBQ0EsYUFBQTtBQ0dGO0FEREE7RUFDRSxrQkFBQTtFQUNBLFVBQUE7RUFDQSxVQUFBO0VBQ0EsY0FBQTtBQ0lGO0FERkE7RUFDRSx3QkFBQTtBQ0tGO0FESEE7RUFDRSxZQUFBO0VBQ0Esb0JBQUE7RUFDQSxrQkFBQTtFQUNBLDJDQUFBO0VBQ0EsY0FBQTtBQ01GO0FESEE7RUFDRSxhQUFBO0FDTUY7QURKQTtFQUNFLFlBQUE7QUNPRjtBRExBO0VBQ0UsbUNBQUE7QUNRRjtBRE5BO0VBQ0UsZUFBQTtBQ1NGIiwiZmlsZSI6InNyYy9hcHAvcGFnZXMvdGlja2V0LWRldGFpbC90aWNrZXQtZGV0YWlsLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5hZGQtY2hhbmdlLWdvb2RzIHtcbiAgYm9yZGVyOiAwLjU1cHggZGFzaGVkIHZhcigtLWlvbi1jb2xvci1tZWRpdW0tdGludCk7XG4gIHBhZGRpbmc6IDJweCAwIDEwcHggMDtcbiAgYm9yZGVyLXJhZGl1czogMTBweDtcbiAgZm9udC1zaXplOiAxM3B4O1xuXG4gIGlvbi1pY29uIHtcbiAgICBmb250LXNpemU6IDJlbTtcbiAgICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLW1lZGl1bS10aW50KTtcbiAgfVxuICBpb24tbGFiZWwge1xuICAgIGNvbG9yOiB2YXIoLS1pb24tY29sb3ItbWVkaXVtLXRpbnQpO1xuICB9XG59XG4uYWRkLWNoYW5nZS1nb29kczphY3RpdmUge1xuICBiYWNrZ3JvdW5kLWNvbG9yOiB2YXIoLS1pb24tY29sb3ItbGlnaHQpO1xufVxuLmNoYW5nZS1nb29kcy1zY3JvbGwge1xuICBvdmVyZmxvdy14OiBhdXRvO1xuICBvdmVyZmxvdy15OiBoaWRkZW47XG59XG4uY2hhbmdlLWdvb2RzLWNhcmQge1xuICBwb3NpdGlvbjogcmVsYXRpdmU7XG4gIG92ZXJmbG93OiB2aXNpYmxlO1xuICBtYXJnaW4tdG9wOiAwO1xufVxuLmFkZC1jaGFuZ2UtZ29vZHMtaWNvbiB7XG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgcmlnaHQ6IDRweDtcbiAgdG9wOiAtMjhweDtcbiAgZm9udC1zaXplOiAyZW07XG59XG4uY2hhbmdlLWdvb2RzLXNjcm9sbDo6LXdlYmtpdC1zY3JvbGxiYXIge1xuICBkaXNwbGF5OiBub25lICFpbXBvcnRhbnQ7XG59XG4uY2hhbmdlLWdvb2RzLXRodW1iIHtcbiAgLS1zaXplOiA2MHB4O1xuICAtLWJvcmRlci1yYWRpdXM6IDZweDtcbiAgYm9yZGVyLXJhZGl1czogNnB4O1xuICBib3JkZXI6IDAuNTVweCBzb2xpZCB2YXIoLS1pb24tY29sb3ItbGlnaHQpO1xuICBmbGV4LXNocmluazogMDtcbn1cblxuLmFjdGlvbi1idXR0b25zIHtcbiAgcGFkZGluZzogMTVweDtcbn1cbi5hY3Rpb24tYnV0dG9ucyBpb24tYnV0dG9uIHtcbiAgaGVpZ2h0OiAzNnB4O1xufVxuaW9uLWl0ZW0tb3B0aW9ucyB7XG4gIGJvcmRlci1ib3R0b20td2lkdGg6IDBweCAhaW1wb3J0YW50O1xufVxuaW9uLWl0ZW0tb3B0aW9uIHtcbiAgZm9udC1zaXplOiAxNHB4O1xufSIsIi5hZGQtY2hhbmdlLWdvb2RzIHtcbiAgYm9yZGVyOiAwLjU1cHggZGFzaGVkIHZhcigtLWlvbi1jb2xvci1tZWRpdW0tdGludCk7XG4gIHBhZGRpbmc6IDJweCAwIDEwcHggMDtcbiAgYm9yZGVyLXJhZGl1czogMTBweDtcbiAgZm9udC1zaXplOiAxM3B4O1xufVxuLmFkZC1jaGFuZ2UtZ29vZHMgaW9uLWljb24ge1xuICBmb250LXNpemU6IDJlbTtcbiAgY29sb3I6IHZhcigtLWlvbi1jb2xvci1tZWRpdW0tdGludCk7XG59XG4uYWRkLWNoYW5nZS1nb29kcyBpb24tbGFiZWwge1xuICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLW1lZGl1bS10aW50KTtcbn1cblxuLmFkZC1jaGFuZ2UtZ29vZHM6YWN0aXZlIHtcbiAgYmFja2dyb3VuZC1jb2xvcjogdmFyKC0taW9uLWNvbG9yLWxpZ2h0KTtcbn1cblxuLmNoYW5nZS1nb29kcy1zY3JvbGwge1xuICBvdmVyZmxvdy14OiBhdXRvO1xuICBvdmVyZmxvdy15OiBoaWRkZW47XG59XG5cbi5jaGFuZ2UtZ29vZHMtY2FyZCB7XG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcbiAgb3ZlcmZsb3c6IHZpc2libGU7XG4gIG1hcmdpbi10b3A6IDA7XG59XG5cbi5hZGQtY2hhbmdlLWdvb2RzLWljb24ge1xuICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gIHJpZ2h0OiA0cHg7XG4gIHRvcDogLTI4cHg7XG4gIGZvbnQtc2l6ZTogMmVtO1xufVxuXG4uY2hhbmdlLWdvb2RzLXNjcm9sbDo6LXdlYmtpdC1zY3JvbGxiYXIge1xuICBkaXNwbGF5OiBub25lICFpbXBvcnRhbnQ7XG59XG5cbi5jaGFuZ2UtZ29vZHMtdGh1bWIge1xuICAtLXNpemU6IDYwcHg7XG4gIC0tYm9yZGVyLXJhZGl1czogNnB4O1xuICBib3JkZXItcmFkaXVzOiA2cHg7XG4gIGJvcmRlcjogMC41NXB4IHNvbGlkIHZhcigtLWlvbi1jb2xvci1saWdodCk7XG4gIGZsZXgtc2hyaW5rOiAwO1xufVxuXG4uYWN0aW9uLWJ1dHRvbnMge1xuICBwYWRkaW5nOiAxNXB4O1xufVxuXG4uYWN0aW9uLWJ1dHRvbnMgaW9uLWJ1dHRvbiB7XG4gIGhlaWdodDogMzZweDtcbn1cblxuaW9uLWl0ZW0tb3B0aW9ucyB7XG4gIGJvcmRlci1ib3R0b20td2lkdGg6IDBweCAhaW1wb3J0YW50O1xufVxuXG5pb24taXRlbS1vcHRpb24ge1xuICBmb250LXNpemU6IDE0cHg7XG59Il19 */");

/***/ }),

/***/ "./src/app/pages/ticket-detail/ticket-detail.page.ts":
/*!***********************************************************!*\
  !*** ./src/app/pages/ticket-detail/ticket-detail.page.ts ***!
  \***********************************************************/
/*! exports provided: TicketDetailPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TicketDetailPage", function() { return TicketDetailPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _service_index__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../service/index */ "./src/app/service/index.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
/* harmony import */ var _components_index__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../components/index */ "./src/app/components/index.ts");
/* harmony import */ var _ticket_list_ticket_list_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../ticket-list/ticket-list.page */ "./src/app/pages/ticket-list/ticket-list.page.ts");
/* harmony import */ var _modal_mat_select_mat_select_page__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../modal/mat-select/mat-select.page */ "./src/app/pages/modal/mat-select/mat-select.page.ts");
/* harmony import */ var _modal_user_select_user_select_page__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../modal/user-select/user-select.page */ "./src/app/pages/modal/user-select/user-select.page.ts");
/* harmony import */ var _modal_ticket_goods_swap_ticket_goods_swap_page__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../modal/ticket-goods-swap/ticket-goods-swap.page */ "./src/app/pages/modal/ticket-goods-swap/ticket-goods-swap.page.ts");
/* harmony import */ var _modal_new_goods_new_goods_page__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../modal/new-goods/new-goods.page */ "./src/app/pages/modal/new-goods/new-goods.page.ts");












let TicketDetailPage = class TicketDetailPage {
    constructor(ticketService, activeRoute, router, modalCtrl, nativeUtils, ticketListPage, commonUtils, storageUtils, actionSheetCtrl) {
        this.ticketService = ticketService;
        this.activeRoute = activeRoute;
        this.router = router;
        this.modalCtrl = modalCtrl;
        this.nativeUtils = nativeUtils;
        this.ticketListPage = ticketListPage;
        this.commonUtils = commonUtils;
        this.storageUtils = storageUtils;
        this.actionSheetCtrl = actionSheetCtrl;
        this.editing = false;
        this.ticketData = {};
        this.goodsList = [];
        this.matAlertList = [];
        this.isStorePriv = false;
        this.activeRoute.queryParams.subscribe((params) => {
            if (!this.commonUtils.isNullOrEmptyString(params.ticketId)) {
                this.ticketId = params.ticketId;
            }
            if (!this.commonUtils.isNullOrEmptyString(params.editing)) {
                this.editing = params.editing && params.editing === 'true';
            }
        });
        // 处理子页面返回刷新当前页面
        const refresh = this.storageUtils.get(_components_index__WEBPACK_IMPORTED_MODULE_5__["ProjectConstant"].STORAGE_KEY_REFRESH);
        if (refresh) {
            setTimeout(() => tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
                if (this.ticketData.ticket_type === _components_index__WEBPACK_IMPORTED_MODULE_5__["ProjectConstant"].TICKET_CHANGE_GOODS
                    || this.ticketData.ticket_type === _components_index__WEBPACK_IMPORTED_MODULE_5__["ProjectConstant"].TICKET_NEW_GOODS) {
                    this.goodsList = yield this.loadTicketExChangeGoodsList();
                }
            }), 1000);
        }
        this.userInfo = this.storageUtils.get(_components_index__WEBPACK_IMPORTED_MODULE_5__["ProjectConstant"].STORAGE_KEY_USERINFO);
        if (this.userInfo.role === 'Service'
            && (this.userInfo.type === _components_index__WEBPACK_IMPORTED_MODULE_5__["ProjectConstant"].AGENT_STORE || this.userInfo.type === _components_index__WEBPACK_IMPORTED_MODULE_5__["ProjectConstant"].AGENT_STORE_HEADER)) {
            this.isStorePriv = true;
        }
    }
    ngOnInit() {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            if (!this.commonUtils.isNullOrEmptyString(this.ticketId)) {
                this.ticketData = yield this.loadTicketData();
                if (this.ticketData.ticket_type === _components_index__WEBPACK_IMPORTED_MODULE_5__["ProjectConstant"].TICKET_CHANGE_GOODS
                    || this.ticketData.ticket_type === _components_index__WEBPACK_IMPORTED_MODULE_5__["ProjectConstant"].TICKET_NEW_GOODS) {
                    this.goodsList = yield this.loadTicketExChangeGoodsList();
                }
                else if (this.ticketData.ticket_type === _components_index__WEBPACK_IMPORTED_MODULE_5__["ProjectConstant"].TICKET_MAT_ALERT) {
                    console.log('获取关联警报！');
                }
            }
        });
    }
    loadTicketData() {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            const loading = this.commonUtils.showLoading();
            const data = yield this.ticketService.ticketDetail(this.ticketId);
            this.commonUtils.hideLoadingSync(loading);
            return data;
        });
    }
    loadTicketExChangeGoodsList(ticketId) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            const data = yield this.ticketService.ticketExChangeGoodsList(ticketId || this.ticketId);
            return data;
        });
    }
    onEditMainTicket(editing) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            if (!editing) {
                this.ticketData = yield this.loadTicketData();
            }
        });
    }
    onReset() {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            const res = yield this.commonUtils.showConfirm('确认', '是否确定放弃修改部分？');
            if (res) {
                if (!this.commonUtils.isNullOrEmptyString(this.ticketId)) {
                    this.ticketData = yield this.loadTicketData();
                }
                else {
                    this.ticketData = {};
                }
            }
        });
    }
    onSaveTicket() {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            this.ticketData.owner_id = 16;
            if (this.commonUtils.isNull(this.ticketData.mat_id)) {
                this.commonUtils.showToast('请选择关联售药机！');
                return;
            }
            if (this.commonUtils.isNullOrEmptyString(this.ticketData.ticket_subject)) {
                this.commonUtils.showToast('请填写工单主题！');
                return;
            }
            if (this.commonUtils.isNull(this.ticketData.ticket_type)) {
                this.commonUtils.showToast('请选择工单类型！');
                return;
            }
            if (this.commonUtils.isNull(this.ticketData.owner_id)) {
                this.commonUtils.showToast('请选择工单负责人！');
                return;
            }
            const loading = this.commonUtils.showLoading('正在提交...');
            let savedTicket = yield this.ticketService.saveTicketData(this.ticketData);
            this.ticketId = savedTicket.id;
            this.commonUtils.hideLoadingSync(loading);
            this.ticketData = yield this.loadTicketData();
            setTimeout(() => {
                this.cardSwapComponent.close();
            }, 500);
        });
    }
    addChangeGoods() {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            if (this.ticketData.ticket_status !== 0) {
                this.commonUtils.showToast('请先点击“保存”按钮再来添加跟换商品！');
                return;
            }
            const modal = yield this.modalCtrl.create({
                component: _modal_ticket_goods_swap_ticket_goods_swap_page__WEBPACK_IMPORTED_MODULE_9__["TicketGoodsSwapPage"],
                componentProps: {
                    matId: this.ticketData.mat_id
                },
                swipeToClose: true
            });
            yield modal.present();
            const { data } = yield modal.onWillDismiss();
            if (!this.commonUtils.isNull(data)) {
                const payload = Object.assign({}, data);
                yield this.saveTicketGoods(payload);
                this.goodsList = yield this.loadTicketExChangeGoodsList();
            }
        });
    }
    saveTicketGoods(data) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            const payload = Object.assign({}, data);
            if (payload.new_image) {
                payload.new_image = payload.new_image.replace(/^data:image\/(jpeg|png|gif|jpg);base64,/, '');
            }
            if (payload.new_image1) {
                payload.new_image1 = payload.new_image1.replace(/^data:image\/(jpeg|png|gif|jpg);base64,/, '');
            }
            if (payload.new_image2) {
                payload.new_image2 = payload.new_image2.replace(/^data:image\/(jpeg|png|gif|jpg);base64,/, '');
            }
            const loading = this.commonUtils.showLoading('正在提交...');
            payload.ticket_id = this.ticketId;
            yield this.ticketService.saveTicketGoods(payload);
            this.commonUtils.hideLoadingSync(loading);
        });
    }
    onChooseMat() {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            if (this.goodsList.length > 0) {
                this.commonUtils.showAlert('警告', null, '替换商品删除后才能调整关联售药机！');
                return;
            }
            const modal = yield this.modalCtrl.create({
                component: _modal_mat_select_mat_select_page__WEBPACK_IMPORTED_MODULE_7__["MatSelectPage"],
                componentProps: {
                    selected: {
                        name: this.ticketData.mat_name,
                        id: this.ticketData.mat_id
                    }
                },
                cssClass: 'ysw-common-modal-vertical',
                swipeToClose: true
            });
            yield modal.present();
            const { data } = yield modal.onWillDismiss();
            if (!this.commonUtils.isNull(data)
                && !this.commonUtils.isNull(data.id)) {
                this.ticketData.mat_name = data.name;
                this.ticketData.mat_id = data.id;
            }
        });
    }
    onChooseType() {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            const buttons = [{
                    text: '跟换商品',
                    cssClass: 'ysw-action-sheet',
                    handler: () => {
                        if (this.ticketData.ticket_type !== 1 && this.matAlertList.length > 0) {
                            this.commonUtils.showAlert('警告', null, '关联的机器警报删除后才能调整工单类型！');
                        }
                        else {
                            this.ticketData.ticket_type = 1;
                        }
                    }
                }, {
                    text: '新建商品',
                    cssClass: 'ysw-action-sheet',
                    handler: () => {
                        if (this.ticketData.ticket_type !== 3
                            && (this.goodsList.length > 3 || this.matAlertList.length > 3)) {
                            this.commonUtils.showAlert('警告', null, '关联警报及商品删除后才能调整工单类型！');
                        }
                        else {
                            this.ticketData.ticket_type = 3;
                        }
                    }
                }, {
                    text: '机器警报',
                    cssClass: 'ysw-action-sheet',
                    handler: () => {
                        if (this.ticketData.ticket_type !== 2 && this.goodsList.length > 0) {
                            this.commonUtils.showAlert('警告', null, '替换商品删除后才能调整工单类型！');
                        }
                        else {
                            this.ticketData.ticket_type = 2;
                        }
                    }
                }, {
                    text: '取消',
                    cssClass: 'ysw-action-sheet',
                    role: 'cancel',
                    handler: () => { }
                }];
            const actionSheet = yield this.actionSheetCtrl.create({
                header: '工单类型',
                buttons
            });
            yield actionSheet.present();
        });
    }
    onChooseOwner() {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            const modal = yield this.modalCtrl.create({
                component: _modal_user_select_user_select_page__WEBPACK_IMPORTED_MODULE_8__["UserSelectPage"],
                componentProps: {},
                cssClass: 'ysw-common-modal-vertical',
                swipeToClose: true
            });
            yield modal.present();
            const { data } = yield modal.onWillDismiss();
            if (!this.commonUtils.isNull(data)
                && !this.commonUtils.isNull(data.id)) {
                this.ticketData.owner_name = data.realName;
                this.ticketData.owner_id = data.id;
            }
        });
    }
    viewTrack(goods) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            this.router.navigate(['tabs/home/mat/track'], {
                queryParams: {
                    matName: Base64.encode(this.ticketData.mat_name),
                    matId: this.ticketData.mat_id,
                    query: goods.goods_track
                }
            });
        });
    }
    viewChangeGoods(goods) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            const modal = yield this.modalCtrl.create({
                component: _modal_ticket_goods_swap_ticket_goods_swap_page__WEBPACK_IMPORTED_MODULE_9__["TicketGoodsSwapPage"],
                componentProps: {
                    ticketGoods: Object.assign({}, goods),
                    matId: this.ticketData.mat_id
                },
                swipeToClose: true
            });
            yield modal.present();
            const { data } = yield modal.onWillDismiss();
            if (!this.commonUtils.isNull(data)) {
                const payload = Object.assign({}, data);
                yield this.saveTicketGoods(payload);
                this.goodsList = yield this.loadTicketExChangeGoodsList();
            }
        });
    }
    setTicketPadding() {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            const res = yield this.commonUtils.showConfirm('确认', '确定是否提交改工单？提交后无法修改数据！');
            if (res) {
                const loading = this.commonUtils.showLoading('正在提交...');
                yield this.ticketService.setTicketPendding(this.ticketData);
                this.commonUtils.hideLoadingSync(loading);
                this.ticketData = yield this.loadTicketData();
            }
        });
    }
    setTicketFinished() {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            const res = yield this.commonUtils.showConfirm('确认', '确定把该工单标记为已完成？');
            if (res) {
                const loading = this.commonUtils.showLoading('正在提交...');
                yield this.ticketService.archiveTicket(this.ticketData.id);
                this.commonUtils.hideLoadingSync(loading);
                this.ticketData = yield this.loadTicketData();
            }
        });
    }
    onEdit(goods, index) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            if (this.checkCanEdit()) {
                const modal = yield this.modalCtrl.create({
                    component: _modal_ticket_goods_swap_ticket_goods_swap_page__WEBPACK_IMPORTED_MODULE_9__["TicketGoodsSwapPage"],
                    componentProps: {
                        ticketGoods: Object.assign({}, goods),
                        matId: this.ticketData.mat_id
                    },
                    swipeToClose: true
                });
                yield modal.present();
                const { data } = yield modal.onWillDismiss();
                if (!this.commonUtils.isNull(data)) {
                    const payload = Object.assign({}, data);
                    yield this.saveTicketGoods(payload);
                    this.goodsList = yield this.loadTicketExChangeGoodsList(this.ticketId);
                    this.storageUtils.set(_components_index__WEBPACK_IMPORTED_MODULE_5__["ProjectConstant"].STORAGE_KEY_REFRESH, true);
                }
            }
            else {
                this.commonUtils.showToast('当前状态不可修改！');
            }
        });
    }
    onDelete(goods, index) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            if (this.checkCanEdit()) {
                const res = yield this.commonUtils.showConfirm('确认', '确认删除该记录？');
                if (res) {
                    const loading = this.commonUtils.showLoading('正在删除...');
                    yield this.ticketService.deleteTicketGoods(goods);
                    this.commonUtils.hideLoadingSync(loading);
                    this.goodsList.splice(index, 1);
                }
            }
            else {
                this.commonUtils.showToast('当前状态不可修改！');
            }
        });
    }
    genStatusColor(status) {
        return this.ticketListPage.genStatusColor(status);
    }
    genStatusName(status) {
        return this.ticketListPage.genStatusName(status);
    }
    genTicketTypeColor(type) {
        return this.ticketListPage.genTicketTypeColor(type);
    }
    genTicketType(type) {
        return this.ticketListPage.genTicketType(type);
    }
    copyOrderNumber(ticketNo) {
        this.nativeUtils.copyToClipboard(ticketNo);
    }
    ngOnDestroy() {
        this.storageUtils.remove(_components_index__WEBPACK_IMPORTED_MODULE_5__["ProjectConstant"].STORAGE_KEY_REFRESH);
    }
    checkCanEdit() {
        let canPopModal = false;
        if (this.ticketData.ticket_status === 0) {
            canPopModal = true;
        }
        else if (this.ticketData.ticket_status === 1) {
            canPopModal = this.userInfo.role === _components_index__WEBPACK_IMPORTED_MODULE_5__["ProjectConstant"].ROLE_SUPER_ADMIN
                || (this.userInfo.role === _components_index__WEBPACK_IMPORTED_MODULE_5__["ProjectConstant"].ROLE_SERIVICE
                    && (this.userInfo.type === _components_index__WEBPACK_IMPORTED_MODULE_5__["ProjectConstant"].AGENT_LEADER || this.userInfo.type === _components_index__WEBPACK_IMPORTED_MODULE_5__["ProjectConstant"].AGENT_STORE_HEADER));
        }
        else if (this.ticketData.ticket_status === 2) {
            canPopModal = false;
        }
        return canPopModal;
    }
    addNewGoods() {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            const modal = yield this.modalCtrl.create({
                component: _modal_new_goods_new_goods_page__WEBPACK_IMPORTED_MODULE_10__["NewGoodsPage"],
                componentProps: {},
                swipeToClose: true
            });
            yield modal.present();
            const { data } = yield modal.onWillDismiss();
            if (!this.commonUtils.isNull(data)) {
                let payload = Object.assign({}, data);
                payload.new_goods_name = data.goodsName;
                payload.new_goods_package = data.goodsPackage;
                payload.new_goods_mfr = data.goodsMfr;
                payload.new_approved_code = data.approvedCode;
                payload.new_goods_brand = data.goodsBrand;
                payload.new_bar_code = data.barCode;
                payload.raw_goods_id = data.rawGoodsId;
                payload.created_goods_id = data.createdGoodsId;
                payload.goods_id = -1;
                payload.goods_track = "0-0-0";
                payload.ticket_id = this.ticketId;
                payload.new_image = data.goodsImage;
                payload.new_image1 = data.goodsImage1;
                payload.new_image2 = data.goodsImage2;
                yield this.saveTicketGoods(payload);
                this.goodsList = yield this.loadTicketExChangeGoodsList();
            }
        });
    }
    viewNewGoods(goods) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            goods.goodsName = goods.new_goods_name;
            goods.goodsPackage = goods.new_goods_package;
            goods.goodsMfr = goods.new_goods_mfr;
            goods.approvedCode = goods.new_approved_code;
            goods.goodsBrand = goods.new_goods_brand;
            goods.barCode = goods.new_bar_code;
            goods.rawGoodsId = goods.raw_goods_id;
            goods.createdGoodsId = goods.created_goods_id;
            goods.goodsImage = goods.new_image;
            goods.goodsImage1 = goods.new_image1;
            goods.goodsImage2 = goods.new_image2;
            const modal = yield this.modalCtrl.create({
                component: _modal_new_goods_new_goods_page__WEBPACK_IMPORTED_MODULE_10__["NewGoodsPage"],
                componentProps: { goods },
                swipeToClose: true
            });
            yield modal.present();
        });
    }
};
TicketDetailPage.ctorParameters = () => [
    { type: _service_index__WEBPACK_IMPORTED_MODULE_2__["TicketService"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_3__["ActivatedRoute"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["ModalController"] },
    { type: _components_index__WEBPACK_IMPORTED_MODULE_5__["NativeUtils"] },
    { type: _ticket_list_ticket_list_page__WEBPACK_IMPORTED_MODULE_6__["TicketListPage"] },
    { type: _components_index__WEBPACK_IMPORTED_MODULE_5__["CommonUtils"] },
    { type: _components_index__WEBPACK_IMPORTED_MODULE_5__["StorageUtils"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["ActionSheetController"] }
];
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"])(_components_index__WEBPACK_IMPORTED_MODULE_5__["CardSwapComponent"], { static: true }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _components_index__WEBPACK_IMPORTED_MODULE_5__["CardSwapComponent"])
], TicketDetailPage.prototype, "cardSwapComponent", void 0);
TicketDetailPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-ticket-detail',
        template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./ticket-detail.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/ticket-detail/ticket-detail.page.html")).default,
        providers: [_service_index__WEBPACK_IMPORTED_MODULE_2__["TicketService"], _ticket_list_ticket_list_page__WEBPACK_IMPORTED_MODULE_6__["TicketListPage"]],
        styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./ticket-detail.page.scss */ "./src/app/pages/ticket-detail/ticket-detail.page.scss")).default]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_service_index__WEBPACK_IMPORTED_MODULE_2__["TicketService"],
        _angular_router__WEBPACK_IMPORTED_MODULE_3__["ActivatedRoute"],
        _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"],
        _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["ModalController"],
        _components_index__WEBPACK_IMPORTED_MODULE_5__["NativeUtils"],
        _ticket_list_ticket_list_page__WEBPACK_IMPORTED_MODULE_6__["TicketListPage"],
        _components_index__WEBPACK_IMPORTED_MODULE_5__["CommonUtils"],
        _components_index__WEBPACK_IMPORTED_MODULE_5__["StorageUtils"],
        _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["ActionSheetController"]])
], TicketDetailPage);



/***/ })

}]);
//# sourceMappingURL=default~ticket-change-goods-ticket-change-goods-module~ticket-detail-ticket-detail-module-es2015.js.map