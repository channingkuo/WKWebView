(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["goods-storage-alert-goods-storage-alert-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/goods-storage-alert/goods-storage-alert.page.html":
/*!***************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/goods-storage-alert/goods-storage-alert.page.html ***!
  \***************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\n  <ion-toolbar color=\"ysw\">\n    <ion-buttons slot=\"start\">\n      <ion-back-button></ion-back-button>\n    </ion-buttons>\n    <ion-title>库存警报</ion-title>\n    <ion-buttons collapse=\"true\" slot=\"end\">\n      <ion-button (click)=\"onChooseCityArea()\">\n        <ion-label class=\"icon-text-small\">{{buttonText}}</ion-label>\n      </ion-button>\n    </ion-buttons>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <ion-refresher slot=\"fixed\" (ionRefresh)=\"doRefresh($event)\" pullMax=\"2000\">\n    <ion-refresher-content></ion-refresher-content>\n  </ion-refresher>\n\n  <ion-header collapse=\"condense\">\n    <ion-toolbar color=\"ysw\">\n      <ion-title size=\"large\">库存警报</ion-title>\n      <ion-buttons collapse=\"true\" slot=\"end\">\n        <ion-button (click)=\"onChooseCityArea()\">\n          <ion-label class=\"icon-text-small\">{{buttonText}}</ion-label>\n        </ion-button>\n      </ion-buttons>\n    </ion-toolbar>\n\n    <ion-toolbar color=\"ysw\">\n      <ion-searchbar color=\"light\" placeholder=\"售药机名称、编号\" showCancelButton=\"focus\" cancelButtonText=\"取消\"\n        inputmode=\"search\" [(ngModel)]=\"queryString\" [debounce]=\"2000\" (ionInput)=\"onSearch($event)\"></ion-searchbar>\n    </ion-toolbar>\n  </ion-header>\n\n  <div class=\"m-t-10\">\n    <ion-text color=\"danger m-l-20\">\n      <small>* 黄色表示库存低，红色表示售罄急需补货</small>\n    </ion-text>\n  </div>\n\n  <skeleton [loading]=\"loading\">\n    <ion-list>\n      <ng-container *ngFor=\"let mat of storageAlert\">\n        <ion-card (click)=\"viewStorageAlertView(mat)\">\n          <ion-card-header>\n            <ion-card-title class=\"flex ion-justify-content-between ion-align-items-center\">\n              <ion-label>{{mat.matName}}</ion-label>\n              <ion-label>\n                <ion-badge color=\"warning\">\n                  {{mat.goodsPriceAlertList.length}}\n                </ion-badge>\n                <ion-badge color=\"danger m-l-10\">\n                  {{mat.zeroCount}}\n                </ion-badge>\n              </ion-label>\n            </ion-card-title>\n            <ion-card-subtitle class=\"flex ion-justify-content-between ion-align-items-center\">\n              <ion-label>{{mat.matSerial}}</ion-label>\n              <ion-label>{{mat.goodsPriceAlertList.length}} 个商品库存需关注</ion-label>\n            </ion-card-subtitle>\n          </ion-card-header>\n        </ion-card>\n      </ng-container>\n    </ion-list>\n\n    <empty-view [data]=\"storageAlert\" message=\"暂无警报数据~\">\n      <empty-content></empty-content>\n    </empty-view>\n  </skeleton>\n</ion-content>");

/***/ }),

/***/ "./src/app/pages/goods-storage-alert/goods-storage-alert.module.ts":
/*!*************************************************************************!*\
  !*** ./src/app/pages/goods-storage-alert/goods-storage-alert.module.ts ***!
  \*************************************************************************/
/*! exports provided: GoodsStorageAlertPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "GoodsStorageAlertPageModule", function() { return GoodsStorageAlertPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm2015/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
/* harmony import */ var _goods_storage_alert_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./goods-storage-alert.page */ "./src/app/pages/goods-storage-alert/goods-storage-alert.page.ts");
/* harmony import */ var _module_index__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../module/index */ "./src/app/pages/module/index.ts");








let GoodsStorageAlertPageModule = class GoodsStorageAlertPageModule {
};
GoodsStorageAlertPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"],
            _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild([
                {
                    path: '',
                    component: _goods_storage_alert_page__WEBPACK_IMPORTED_MODULE_6__["GoodsStorageAlertPage"]
                }, {
                    path: 'goods',
                    loadChildren: () => __webpack_require__.e(/*! import() | goods-list-goods-list-module */ "goods-list-goods-list-module").then(__webpack_require__.bind(null, /*! ../goods-list/goods-list.module */ "./src/app/pages/goods-list/goods-list.module.ts")).then(m => m.GoodsListPageModule)
                }
            ]),
            _module_index__WEBPACK_IMPORTED_MODULE_7__["EmptyModule"],
            _module_index__WEBPACK_IMPORTED_MODULE_7__["SkeletonModule"]
        ],
        declarations: [_goods_storage_alert_page__WEBPACK_IMPORTED_MODULE_6__["GoodsStorageAlertPage"]]
    })
], GoodsStorageAlertPageModule);



/***/ }),

/***/ "./src/app/pages/goods-storage-alert/goods-storage-alert.page.scss":
/*!*************************************************************************!*\
  !*** ./src/app/pages/goods-storage-alert/goods-storage-alert.page.scss ***!
  \*************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("ion-card:first-child {\n  margin-top: 10px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Vc2Vycy9jaGFubmluZy9EZXNrdG9wL3lzdy1hcHAtc2VydmljZTQvc3JjL2FwcC9wYWdlcy9nb29kcy1zdG9yYWdlLWFsZXJ0L2dvb2RzLXN0b3JhZ2UtYWxlcnQucGFnZS5zY3NzIiwic3JjL2FwcC9wYWdlcy9nb29kcy1zdG9yYWdlLWFsZXJ0L2dvb2RzLXN0b3JhZ2UtYWxlcnQucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0UsZ0JBQUE7QUNDRiIsImZpbGUiOiJzcmMvYXBwL3BhZ2VzL2dvb2RzLXN0b3JhZ2UtYWxlcnQvZ29vZHMtc3RvcmFnZS1hbGVydC5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJpb24tY2FyZDpmaXJzdC1jaGlsZCB7XG4gIG1hcmdpbi10b3A6IDEwcHg7XG59IiwiaW9uLWNhcmQ6Zmlyc3QtY2hpbGQge1xuICBtYXJnaW4tdG9wOiAxMHB4O1xufSJdfQ== */");

/***/ }),

/***/ "./src/app/pages/goods-storage-alert/goods-storage-alert.page.ts":
/*!***********************************************************************!*\
  !*** ./src/app/pages/goods-storage-alert/goods-storage-alert.page.ts ***!
  \***********************************************************************/
/*! exports provided: GoodsStorageAlertPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "GoodsStorageAlertPage", function() { return GoodsStorageAlertPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _service_index__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../service/index */ "./src/app/service/index.ts");
/* harmony import */ var _components_index__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../components/index */ "./src/app/components/index.ts");





let GoodsStorageAlertPage = class GoodsStorageAlertPage {
    constructor(matService, commonUtils, storageUtils, router, activatedRoute) {
        this.matService = matService;
        this.commonUtils = commonUtils;
        this.storageUtils = storageUtils;
        this.router = router;
        this.activatedRoute = activatedRoute;
        this.buttonText = '全部';
        this.selectedCity = '0';
        this.selectedArea = '0';
        this.queryString = '';
        this.storageAlert = [];
        this.loading = true;
    }
    ngOnInit() {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            this.storageAlert = yield this.loadData();
            this.loading = false;
        });
    }
    loadData() {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            // const loading = this.commonUtils.showLoading();
            const alertSettings = this.storageUtils.get(_components_index__WEBPACK_IMPORTED_MODULE_4__["ProjectConstant"].STORAGE_KEY_ALERT_SETTINGS);
            const data = yield this.matService.getMatGoodsStorageAlertInfo(alertSettings.storage, this.queryString, this.selectedCity, this.selectedArea);
            data.forEach((mat) => {
                mat.zeroCount = mat.goodsPriceAlertList.filter(goods => goods.goodsNumber === 0).length;
            });
            // this.commonUtils.hideLoadingSync(loading);
            return data;
        });
    }
    doRefresh(event) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            this.storageAlert = yield this.loadData();
            event.target.complete();
        });
    }
    onSearch(event) {
        if (this.timer) {
            clearTimeout(this.timer);
        }
        this.timer = setTimeout(() => tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            this.storageAlert = yield this.loadData();
        }), 2000);
    }
    onChooseCityArea() {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            const data = yield this.commonUtils.popLocationPicker(this.selectedCity, this.selectedArea);
            this.selectedCity = data.city.value;
            this.selectedArea = data.area.value;
            if (this.selectedCity === '0') {
                this.buttonText = '全部';
            }
            else {
                this.buttonText = data.city.text;
                if (this.selectedArea !== '0') {
                    this.buttonText += ', ' + data.area.text;
                }
            }
            this.storageAlert = yield this.loadData();
        });
    }
    viewStorageAlertView(mat) {
        const goodsInfo = mat.goodsPriceAlertList;
        this.storageUtils.set(_components_index__WEBPACK_IMPORTED_MODULE_4__["ProjectConstant"].STORAGE_KEY_ALERT_GOODS_INFO, goodsInfo);
        this.router.navigate(['../goods/list'], {
            relativeTo: this.activatedRoute,
            queryParams: { title: encodeURI('库存警报：' + mat.matName) }
        });
    }
};
GoodsStorageAlertPage.ctorParameters = () => [
    { type: _service_index__WEBPACK_IMPORTED_MODULE_3__["MatService"] },
    { type: _components_index__WEBPACK_IMPORTED_MODULE_4__["CommonUtils"] },
    { type: _components_index__WEBPACK_IMPORTED_MODULE_4__["StorageUtils"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"] }
];
GoodsStorageAlertPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-goods-storage-alert',
        template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./goods-storage-alert.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/goods-storage-alert/goods-storage-alert.page.html")).default,
        providers: [_service_index__WEBPACK_IMPORTED_MODULE_3__["MatService"]],
        styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./goods-storage-alert.page.scss */ "./src/app/pages/goods-storage-alert/goods-storage-alert.page.scss")).default]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_service_index__WEBPACK_IMPORTED_MODULE_3__["MatService"],
        _components_index__WEBPACK_IMPORTED_MODULE_4__["CommonUtils"],
        _components_index__WEBPACK_IMPORTED_MODULE_4__["StorageUtils"],
        _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"],
        _angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"]])
], GoodsStorageAlertPage);



/***/ })

}]);
//# sourceMappingURL=goods-storage-alert-goods-storage-alert-module-es2015.js.map