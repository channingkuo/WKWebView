(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["ticket-list-ticket-list-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/ticket-list/ticket-list.page.html":
/*!***********************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/ticket-list/ticket-list.page.html ***!
  \***********************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\n  <ion-toolbar color=\"ysw\">\n    <ion-buttons slot=\"start\">\n      <ion-back-button></ion-back-button>\n    </ion-buttons>\n    <ion-title>工  单</ion-title>\n    <ion-buttons collapse=\"true\" slot=\"end\">\n      <ion-button (click)=\"onFilter()\">\n        <ion-label class=\"icon-text-small\">筛选</ion-label>\n      </ion-button>\n    </ion-buttons>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <ion-refresher slot=\"fixed\" (ionRefresh)=\"doRefresh($event)\" pullMax=\"2000\">\n    <ion-refresher-content></ion-refresher-content>\n  </ion-refresher>\n\n  <ion-header collapse=\"condense\">\n    <ion-toolbar color=\"ysw\">\n      <ion-title size=\"large\">工  单</ion-title>\n      <ion-buttons slot=\"end\">\n        <ion-button (click)=\"viewDetail({}, true)\">\n          <ion-label class=\"icon-text-small\">新工单</ion-label>\n        </ion-button>\n        <ion-button (click)=\"onFilter()\">\n          <ion-label class=\"icon-text-small\">筛选</ion-label>\n        </ion-button>\n      </ion-buttons>\n    </ion-toolbar>\n\n    <ion-toolbar color=\"ysw\">\n      <ion-searchbar color=\"light\" placeholder=\"售药机名称、编号\" showCancelButton=\"focus\" cancelButtonText=\"取消\"\n        inputmode=\"search\" [(ngModel)]=\"queryString\" [debounce]=\"2000\" (ionInput)=\"onSearch($event)\"></ion-searchbar>\n    </ion-toolbar>\n  </ion-header>\n\n  <skeleton [loading]=\"loading\">\n    <ion-list>\n      <ng-container *ngFor=\"let ticket of ticketList\">\n        <ion-card (click)=\"viewDetail(ticket, false)\">\n          <ion-card-header>\n            <ion-card-title class=\"flex ion-justify-content-between ion-align-items-center\">\n              <ion-label>{{ticket.ticket_no | stringSecurity}}</ion-label>\n              <ion-badge [color]=\"genStatusColor(ticket.ticket_status)\">\n                {{genStatusName(ticket.ticket_status)}}\n              </ion-badge>\n            </ion-card-title>\n            <ion-card-subtitle>\n              <ion-label>\n                {{ticket.mat_name}} <small>{{ticket.external_no}}</small>\n              </ion-label>\n            </ion-card-subtitle>\n          </ion-card-header>\n          <ion-card-content>\n            <div class=\"flex ion-justify-content-between ion-align-items-center content-line\">\n              <ion-label>工单类型：</ion-label>\n              <ion-label [color]=\"genTicketTypeColor(ticket.type)\">{{genTicketType(ticket.type)}}</ion-label>\n            </div>\n            <div class=\"flex ion-justify-content-between ion-align-items-center content-line\">\n              <ion-label>工单主题：</ion-label>\n              <ion-label>{{ticket.ticket_subject}}</ion-label>\n            </div>\n            <div class=\"flex ion-justify-content-between ion-align-items-center content-line\">\n              <ion-label>创建人员：</ion-label>\n              <ion-label>{{ticket.created_by_name}}</ion-label>\n            </div>\n            <div class=\"flex ion-justify-content-between ion-align-items-center content-line\">\n              <ion-label>创建时间：</ion-label>\n              <ion-label>{{ticket.created_date| date: 'yyyy-MM-dd HH:mm:ss'}}</ion-label>\n            </div>\n            <!--\n            <div class=\"flex ion-justify-content-between ion-align-items-center content-line\">\n              <ion-label>修改人：</ion-label>\n              <ion-label>{{ticket.updated_by_name}}</ion-label>\n            </div>\n            <div class=\"flex ion-justify-content-between ion-align-items-center content-line\">\n              <ion-label>最近修改：</ion-label>\n              <ion-label>{{ticket.updated_date| date: 'yyyy-MM-dd HH:mm:ss'}}</ion-label>\n            </div>\n            -->\n          </ion-card-content>\n        </ion-card>\n      </ng-container>\n    </ion-list>\n\n    <empty-view [data]=\"ticketList\" message=\"暂无订单数据~\">\n      <empty-content></empty-content>\n    </empty-view>\n\n    <ion-infinite-scroll threshold=\"100px\" (ionInfinite)=\"onInfinite($event)\">\n      <ion-infinite-scroll-content loadingSpinner=\"bubbles\" loadingText=\"加载更多...\">\n      </ion-infinite-scroll-content>\n    </ion-infinite-scroll>\n  </skeleton>\n</ion-content>");

/***/ }),

/***/ "./src/app/modal-transitions.ts":
/*!**************************************!*\
  !*** ./src/app/modal-transitions.ts ***!
  \**************************************/
/*! exports provided: RightLeaveAnimation, RightEnterAnimation */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "RightLeaveAnimation", function() { return RightLeaveAnimation; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "RightEnterAnimation", function() { return RightEnterAnimation; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _ionic_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @ionic/core */ "./node_modules/@ionic/core/dist/esm/index.mjs");


const RightLeaveAnimation = (baseEl, presentingEl, duration = 700) => {
    const backdropAnimation = Object(_ionic_core__WEBPACK_IMPORTED_MODULE_1__["createAnimation"])()
        // tslint:disable-next-line:no-non-null-assertion
        .addElement(baseEl.querySelector('ion-backdrop'))
        .fromTo('opacity', 'var(--backdrop-opacity)', 0.0);
    const wrapperAnimation = Object(_ionic_core__WEBPACK_IMPORTED_MODULE_1__["createAnimation"])()
        // tslint:disable-next-line:no-non-null-assertion
        .addElement(baseEl.querySelector('.modal-wrapper'))
        .beforeStyles({ opacity: 1 })
        .fromTo('transform', 'translateX(0vh)', 'translateX(100vh)');
    const baseAnimation = Object(_ionic_core__WEBPACK_IMPORTED_MODULE_1__["createAnimation"])()
        .addElement(baseEl)
        .easing('cubic-bezier(0.32,0.72,0,1)')
        .duration(duration)
        .addAnimation([backdropAnimation, wrapperAnimation]);
    if (presentingEl) {
        const transformOffset = (!CSS.supports('width', 'max(0px, 1px)')) ? '30px' : 'max(30px, var(--ion-safe-area-top, 0px))';
        const modalTransform = (presentingEl.tagName === 'ION-MODAL'
            && presentingEl.presentingElement !== undefined)
            ? '-10px' : transformOffset;
        const bodyEl = document.body;
        const presentingAnimation = Object(_ionic_core__WEBPACK_IMPORTED_MODULE_1__["createAnimation"])()
            .addElement(presentingEl)
            .beforeClearStyles(['transform'])
            .afterClearStyles(['transform'])
            .onFinish(currentStep => {
            // only reset background color if this is the last card-style modal
            if (currentStep !== 1) {
                return;
            }
            presentingEl.style.setProperty('overflow', '');
            const numModals = Array.from(bodyEl.querySelectorAll('ion-modal')).filter(m => m.presentingElement !== undefined).length;
            if (numModals <= 1) {
                bodyEl.style.setProperty('background-color', '');
            }
        })
            .keyframes([
            { offset: 0, filter: 'contrast(0.85)', transform: `translateX(${modalTransform})`, borderRadius: '10px 10px 0 0' },
            { offset: 1, filter: 'contrast(1)', transform: 'translateX(0px) scale(1)', borderRadius: '0px' }
        ]);
        baseAnimation.addAnimation(presentingAnimation);
    }
    return baseAnimation;
};
const RightEnterAnimation = (baseEl, presentingEl, duration = 700) => {
    const backdropAnimation = Object(_ionic_core__WEBPACK_IMPORTED_MODULE_1__["createAnimation"])()
        // tslint:disable-next-line:no-non-null-assertion
        .addElement(baseEl.querySelector('ion-backdrop'))
        .fromTo('opacity', 0.01, 'var(--backdrop-opacity)')
        .beforeStyles({
        'pointer-events': 'none'
    })
        .afterClearStyles(['pointer-events']);
    const wrapperAnimation = Object(_ionic_core__WEBPACK_IMPORTED_MODULE_1__["createAnimation"])()
        // tslint:disable-next-line:no-non-null-assertion
        .addElement(baseEl.querySelector('.modal-wrapper'))
        .beforeStyles({ opacity: 1 })
        .fromTo('transform', 'translateX(100vh)', 'translateX(0vh)');
    const baseAnimation = Object(_ionic_core__WEBPACK_IMPORTED_MODULE_1__["createAnimation"])()
        .addElement(baseEl)
        .easing('cubic-bezier(0.32,0.72,0,1)')
        .duration(500)
        .beforeAddClass('show-modal')
        .addAnimation([backdropAnimation, wrapperAnimation]);
    if (presentingEl) {
        /**
         * Fallback for browsers that does not support `max()` (ex: Firefox)
         * No need to wrry about statusbar padding since engines like Gecko
         * are not used as the engine for standlone Cordova/Capacitor apps
         */
        const transformOffset = (!CSS.supports('width', 'max(0px, 1px)')) ? '30px' : 'max(30px, var(--ion-safe-area-top, 0px))';
        const modalTransform = (presentingEl.tagName === 'ION-MODAL'
            && presentingEl.presentingElement !== undefined)
            ? '-10px' : transformOffset;
        const bodyEl = document.body;
        const finalTransform = `translateX(${modalTransform})`;
        const presentingAnimation = Object(_ionic_core__WEBPACK_IMPORTED_MODULE_1__["createAnimation"])()
            .beforeStyles({
            transform: 'translateX(0)',
            'transform-origin': 'top center',
            overflow: 'hidden'
        })
            .afterStyles({
            transform: finalTransform
        })
            .beforeAddWrite(() => bodyEl.style.setProperty('background-color', 'black'))
            .addElement(presentingEl)
            .keyframes([
            { offset: 0, filter: 'contrast(1)', transform: 'translateX(0px) scale(1)', borderRadius: '0px' },
            { offset: 1, filter: 'contrast(0.85)', transform: finalTransform, borderRadius: '10px 10px 0 0' }
        ]);
        baseAnimation.addAnimation(presentingAnimation);
    }
    return baseAnimation;
};


/***/ }),

/***/ "./src/app/pages/ticket-list/ticket-list.module.ts":
/*!*********************************************************!*\
  !*** ./src/app/pages/ticket-list/ticket-list.module.ts ***!
  \*********************************************************/
/*! exports provided: TicketListPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TicketListPageModule", function() { return TicketListPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm2015/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
/* harmony import */ var _ticket_list_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./ticket-list.page */ "./src/app/pages/ticket-list/ticket-list.page.ts");
/* harmony import */ var _module_index__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../module/index */ "./src/app/pages/module/index.ts");








let TicketListPageModule = class TicketListPageModule {
};
TicketListPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"],
            _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild([
                {
                    path: 'list',
                    component: _ticket_list_page__WEBPACK_IMPORTED_MODULE_6__["TicketListPage"]
                }, {
                    path: 'detail',
                    loadChildren: () => Promise.all(/*! import() | ticket-detail-ticket-detail-module */[__webpack_require__.e("default~ticket-change-goods-ticket-change-goods-module~ticket-detail-ticket-detail-module"), __webpack_require__.e("ticket-detail-ticket-detail-module")]).then(__webpack_require__.bind(null, /*! ../ticket-detail/ticket-detail.module */ "./src/app/pages/ticket-detail/ticket-detail.module.ts")).then(m => m.TicketDetailPageModule)
                }, {
                    path: 'detail/goods',
                    loadChildren: () => Promise.all(/*! import() | ticket-change-goods-ticket-change-goods-module */[__webpack_require__.e("default~ticket-change-goods-ticket-change-goods-module~ticket-detail-ticket-detail-module"), __webpack_require__.e("ticket-change-goods-ticket-change-goods-module")]).then(__webpack_require__.bind(null, /*! ../ticket-change-goods/ticket-change-goods.module */ "./src/app/pages/ticket-change-goods/ticket-change-goods.module.ts")).then(m => m.TicketChangeGoodsPageModule)
                }
            ]),
            _module_index__WEBPACK_IMPORTED_MODULE_7__["EmptyModule"],
            _module_index__WEBPACK_IMPORTED_MODULE_7__["StringSecurityModule"],
            _module_index__WEBPACK_IMPORTED_MODULE_7__["SplitLabelModule"],
            _module_index__WEBPACK_IMPORTED_MODULE_7__["SkeletonModule"]
        ],
        declarations: [_ticket_list_page__WEBPACK_IMPORTED_MODULE_6__["TicketListPage"]]
    })
], TicketListPageModule);



/***/ }),

/***/ "./src/app/pages/ticket-list/ticket-list.page.scss":
/*!*********************************************************!*\
  !*** ./src/app/pages/ticket-list/ticket-list.page.scss ***!
  \*********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3BhZ2VzL3RpY2tldC1saXN0L3RpY2tldC1saXN0LnBhZ2Uuc2NzcyJ9 */");

/***/ }),

/***/ "./src/app/pages/ticket-list/ticket-list.page.ts":
/*!*******************************************************!*\
  !*** ./src/app/pages/ticket-list/ticket-list.page.ts ***!
  \*******************************************************/
/*! exports provided: TicketListPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TicketListPage", function() { return TicketListPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _service_index__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../service/index */ "./src/app/service/index.ts");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _components_index__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../components/index */ "./src/app/components/index.ts");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../../environments/environment */ "./src/environments/environment.ts");
/* harmony import */ var _modal_transitions__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../modal-transitions */ "./src/app/modal-transitions.ts");
/* harmony import */ var _modal_ticket_filter_ticket_filter_page__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../modal/ticket-filter/ticket-filter.page */ "./src/app/pages/modal/ticket-filter/ticket-filter.page.ts");









let TicketListPage = class TicketListPage {
    constructor(ticketService, activeRoute, router, modalCtrl, commonUtils) {
        this.ticketService = ticketService;
        this.activeRoute = activeRoute;
        this.router = router;
        this.modalCtrl = modalCtrl;
        this.commonUtils = commonUtils;
        this.queryString = '';
        this.showMore = true;
        this.pageIndex = _environments_environment__WEBPACK_IMPORTED_MODULE_6__["environment"].pageIndex;
        this.pageSize = _environments_environment__WEBPACK_IMPORTED_MODULE_6__["environment"].pageSize;
        this.ticketNo = '';
        this.subject = '';
        this.alertId = null;
        this.status = null;
        this.type = null;
        this.ticketList = [];
        this.loading = true;
    }
    ngOnInit() {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            this.ticketList = yield this.loadTicketList(false);
            this.loading = false;
        });
    }
    loadTicketList(showLoading = true) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            let loading;
            if (showLoading) {
                loading = this.commonUtils.showLoading('正在加载...');
            }
            const payload = {
                ticketNo: this.ticketNo,
                matCode: this.queryString,
                subject: this.subject,
                alertId: this.alertId,
                status: this.status,
                type: this.type
            };
            const data = yield this.ticketService.ticketList(this.pageIndex, this.pageSize, payload);
            if (showLoading) {
                this.commonUtils.hideLoadingSync(loading);
            }
            this.showMore = data.list.length >= this.pageSize;
            this.infiniteScroll.disabled = !this.showMore;
            return data.list;
        });
    }
    doRefresh(event) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            this.pageIndex = 1;
            this.ticketList = yield this.loadTicketList();
            event.target.complete();
        });
    }
    onInfinite(event) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            this.pageIndex += 1;
            const data = yield this.loadTicketList();
            this.ticketList = [...this.ticketList, ...data];
            event.target.complete();
        });
    }
    onSearch(event) {
        if (this.timer) {
            clearTimeout(this.timer);
        }
        this.timer = setTimeout(() => tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            this.pageIndex = 1;
            this.ticketList = yield this.loadTicketList();
        }), 2000);
    }
    onFilter() {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            const modal = yield this.modalCtrl.create({
                component: _modal_ticket_filter_ticket_filter_page__WEBPACK_IMPORTED_MODULE_8__["TicketFilterPage"],
                componentProps: {
                    ticketNo: this.ticketNo,
                    subject: this.subject,
                    alertId: this.alertId,
                    status: this.status,
                    type: this.type
                },
                enterAnimation: _modal_transitions__WEBPACK_IMPORTED_MODULE_7__["RightEnterAnimation"],
                leaveAnimation: _modal_transitions__WEBPACK_IMPORTED_MODULE_7__["RightLeaveAnimation"],
                backdropDismiss: true,
                cssClass: 'ysw-filter-modal-horizontal'
            });
            yield modal.present();
            const { data } = yield modal.onWillDismiss();
            if (!this.commonUtils.isNull(data)) {
                this.pageIndex = 1;
                this.ticketNo = data.ticketNo;
                this.subject = data.subject;
                this.alertId = data.alertId;
                this.status = data.status;
                this.type = data.type;
                this.ticketList = yield this.loadTicketList();
            }
        });
    }
    viewDetail(ticket, editing) {
        this.router.navigate(['../detail'], {
            relativeTo: this.activeRoute,
            queryParams: {
                ticketId: ticket.id,
                editing
            }
        });
    }
    genStatusColor(status) {
        switch (status) {
            case 0:
                return 'warning';
            case 1:
                return 'ysw';
            case 2:
                return 'success';
            default:
                return 'warning';
        }
    }
    genStatusName(status) {
        switch (status) {
            case 0:
                return '待处理';
            case 1:
                return '处理中';
            case 2:
                return '已处理';
            default:
                return '待处理';
        }
    }
    genTicketType(type) {
        switch (type) {
            case 0:
                return '其他';
            case 1:
                return '更换商品';
            case 2:
                return '机器异常';
            case 3:
                return '新建商品';
            default:
                return '其他';
        }
    }
    genTicketTypeColor(type) {
        switch (type) {
            case 0:
                return 'ysw';
            case 1:
                return 'success';
            case 2:
                return 'warning';
            default:
                return 'ysw';
        }
    }
};
TicketListPage.ctorParameters = () => [
    { type: _service_index__WEBPACK_IMPORTED_MODULE_2__["TicketService"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_4__["ActivatedRoute"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_4__["Router"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["ModalController"] },
    { type: _components_index__WEBPACK_IMPORTED_MODULE_5__["CommonUtils"] }
];
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"])(_ionic_angular__WEBPACK_IMPORTED_MODULE_3__["IonInfiniteScroll"], { static: true }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["IonInfiniteScroll"])
], TicketListPage.prototype, "infiniteScroll", void 0);
TicketListPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-ticket-list',
        template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./ticket-list.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/ticket-list/ticket-list.page.html")).default,
        providers: [_service_index__WEBPACK_IMPORTED_MODULE_2__["TicketService"]],
        styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./ticket-list.page.scss */ "./src/app/pages/ticket-list/ticket-list.page.scss")).default]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_service_index__WEBPACK_IMPORTED_MODULE_2__["TicketService"],
        _angular_router__WEBPACK_IMPORTED_MODULE_4__["ActivatedRoute"],
        _angular_router__WEBPACK_IMPORTED_MODULE_4__["Router"],
        _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["ModalController"],
        _components_index__WEBPACK_IMPORTED_MODULE_5__["CommonUtils"]])
], TicketListPage);



/***/ })

}]);
//# sourceMappingURL=ticket-list-ticket-list-module-es2015.js.map