function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["mat-track-supply-mat-track-supply-module"], {
  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/mat-track-supply/mat-track-supply.page.html":
  /*!*********************************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/mat-track-supply/mat-track-supply.page.html ***!
    \*********************************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppPagesMatTrackSupplyMatTrackSupplyPageHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-header>\n  <ion-toolbar color=\"ysw\">\n    <ion-buttons slot=\"start\">\n      <ion-back-button>返回</ion-back-button>\n    </ion-buttons>\n    <ion-title>调整库存</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <ion-header collapse=\"condense\">\n    <ion-toolbar color=\"ysw\">\n      <ion-title size=\"large\">调整库存</ion-title>\n    </ion-toolbar>\n  </ion-header>\n\n  <ion-list>\n    <ion-card>\n      <ion-card-header>\n        <ion-card-title class=\"flex ion-justify-content-between ion-align-items-center m-b-5\">\n          <ion-label>\n            {{matTrack.goodsTrack}}\n            <ion-icon class=\"lock-icon\" *ngIf=\"!matTrack.isPublish\" color=\"danger\" name=\"lock-closed-outline\"></ion-icon>\n          </ion-label>\n          <ion-label>\n            {{(matTrack.brandName || '') + ' '}}{{matTrack.goodsName}}\n          </ion-label>\n        </ion-card-title>\n      </ion-card-header>\n      <ion-card-content class=\"p-t-0\">\n        <div class=\"flex ion-justify-content-start ion-align-items-start\">\n          <ion-img (ionError)=\"imageError($event)\" *ngIf=\"matTrack.goodsId && matTrack.goodsName\"\n            [src]=\"matTrack.goodsImage || 'assets/imgs/mat/goods-no-image.svg'\" [alt]=\"matTrack.goodsTrack\">\n          </ion-img>\n          <div *ngIf=\"!matTrack.goodsId || !matTrack.goodsName\"\n            class=\"track-no-goods flex ion-justify-content-center ion-align-items-center\">\n            暂未绑定商品\n          </div>\n          <div class=\"flex ion-justify-content-center ion-align-items-start flex-column\">\n            <ion-label>\n              <ion-label color=\"dark\">规格：</ion-label>{{matTrack.goodsPackage || '-'}}\n            </ion-label>\n            <ion-label class=\"m-t-10\">\n              <ion-label color=\"dark\">厂商：</ion-label>{{matTrack.mfrName || '-'}}\n            </ion-label>\n            <ion-label class=\"flex ion-justify-content-between ion-align-items-center m-t-10 w-100p\">\n              <ion-label>\n                <ion-label color=\"dark\">最大：</ion-label>{{matTrack.maxNumber}} {{matTrack.goodsUnit}}\n              </ion-label>\n              <ion-label class=\"w-55p\">\n                <ion-label color=\"dark\">库存：</ion-label>\n                <ng-container *ngIf=\"matTrack.goodsNumber && matTrack.goodsNumber > 0;else noGoodsNumber\">\n                  <ion-label [color]=\"matTrack.goodsNumber <= storageAlert ? 'warning' : ''\">\n                    {{matTrack.goodsNumber}}<ion-label color=\"danger\" *ngIf=\"matTrack.lockedNumber\">\n                      [{{matTrack.lockedNumber}}]</ion-label> {{matTrack.goodsUnit}}\n                  </ion-label>\n                </ng-container>\n                <ng-template #noGoodsNumber>\n                  <ion-label color=\"danger\">售罄</ion-label>\n                </ng-template>\n              </ion-label>\n            </ion-label>\n            <ion-label class=\"flex ion-justify-content-between ion-align-items-center m-t-10 w-100p\">\n              <ion-label>\n                <ion-label color=\"dark\">限购：</ion-label>{{matTrack.limitation}} {{matTrack.goodsUnit}}\n              </ion-label>\n              <ion-label class=\"w-55p\">\n                <ion-label color=\"dark\">价格：</ion-label>\n                <ion-label color=\"danger\">{{matTrack.goodsPrice| currency: '￥'}}</ion-label>\n              </ion-label>\n            </ion-label>\n          </div>\n        </div>\n      </ion-card-content>\n    </ion-card>\n\n    <ion-card>\n      <ion-card-content class=\"p-5\">\n        <split-label class=\"m-b-5\">库存数量</split-label>\n\n        <div class=\"m-l-10 m-r-10 m-b-10 p-b-10 b-b-split\">\n          <ion-label class=\"flex ion-justify-content-between ion-align-items-center content-line\">\n            <ion-label color=\"dark\" class=\"supply-label\">库存</ion-label>\n            <ion-label class=\"number-label margin-right-30\">{{matTrack.goodsNumber}}{{' ' + matTrack.goodsUnit}}\n            </ion-label>\n          </ion-label>\n          <ion-label class=\"flex ion-justify-content-between ion-align-items-center content-line\">\n            <ion-label color=\"dark\" class=\"supply-label\">补了</ion-label>\n            <ion-label class=\"flex ion-justify-content-around ion-align-items-center\">\n              <ion-icon (click)=\"minusNumber(matTrack)\" color=\"primary\" name=\"remove-circle-outline\"></ion-icon>\n              <ion-label class=\"number-label\">{{matTrack.supplyNumber}}{{' ' + matTrack.goodsUnit}}</ion-label>\n              <ion-icon (click)=\"plusNumber(matTrack)\" color=\"primary\" name=\"add-circle-outline\"></ion-icon>\n            </ion-label>\n          </ion-label>\n          <ion-label class=\"flex ion-justify-content-between ion-align-items-center content-line\">\n            <ion-label color=\"dark\" class=\"supply-label\">合计</ion-label>\n            <ion-label class=\"number-label margin-right-30\">\n              {{(matTrack.goodsNumber || 0) + matTrack.supplyNumber}}{{' ' + matTrack.goodsUnit}}\n            </ion-label>\n          </ion-label>\n        </div>\n\n        <split-label>批号 & 效期</split-label>\n\n        <div class=\"m-l-10 m-r-10\">\n          <ng-container *ngIf=\"beList.length > 0;else noBE\">\n            <ng-container *ngFor=\"let be of beList;index as i\">\n              <div class=\"flex ion-justify-content-between ion-align-items-center content-line\">\n                <ion-label class=\"flex ion-justify-content-between ion-align-items-center\">\n                  <ion-label class=\"supply-label\" color=\"dark\">批号：</ion-label>\n                  <ion-label color=\"medium\">{{be.batchNo}}</ion-label>\n                </ion-label>\n                <ion-label class=\"flex ion-justify-content-between ion-align-items-center content-line\">\n                  <ion-label class=\"supply-label\" color=\"dark\">效期：</ion-label>\n                  <ion-label color=\"medium\">{{be.expireDate| date: 'yyyy-MM-dd'}}</ion-label>\n                </ion-label>\n              </div>\n\n              <div class=\"flex ion-justify-content-between ion-align-items-center m-b-5 p-b-5 b-b-split\">\n                <ion-button class=\"icon-text-small\" fill=\"clear\" color=\"danger\" (click)=\"onDelete(be, i)\">\n                  <ion-icon size=\"small\" slot=\"start\" name=\"trash-outline\" style=\"-webkit-margin-end: 0;\"></ion-icon>\n                  删除该批号\n                </ion-button>\n                <ion-label class=\"flex ion-justify-content-around ion-align-items-center content-line\">\n                  <ion-icon (click)=\"minusBENumber(be)\" color=\"primary\" name=\"remove-circle-outline\"></ion-icon>\n                  <ion-label class=\"number-label\">{{be.goodsNumber + ' 个'}}</ion-label>\n                  <ion-icon (click)=\"plusBENumber(be)\" color=\"primary\" name=\"add-circle-outline\"></ion-icon>\n                </ion-label>\n              </div>\n            </ng-container>\n          </ng-container>\n\n          <div class=\"w-100p text-center\">\n            <ion-button fill=\"clear\" color=\"default\" (click)=\"addBE()\">\n              <ion-icon size=\"larger\" slot=\"start\" name=\"add-outline\" style=\"-webkit-margin-end: 0;\"></ion-icon>添加新批号\n            </ion-button>\n          </div>\n\n          <ng-template #noBE>\n            <ion-label class=\"flex ion-justify-content-center m-t-20 m-b-10\" style=\"font-size: small;\">补货别忘记添加批号、效期！\n            </ion-label>\n          </ng-template>\n        </div>\n      </ion-card-content>\n    </ion-card>\n\n    <div class=\"w-100p text-center p-l-15 p-r-15 p-b-15\">\n      <ion-button class=\"m-t-15\" expand=\"block\" (click)=\"saveSupply()\">\n        提交调整\n      </ion-button>\n    </div>\n  </ion-list>\n</ion-content>";
    /***/
  },

  /***/
  "./src/app/pages/mat-track-supply/mat-track-supply.module.ts":
  /*!*******************************************************************!*\
    !*** ./src/app/pages/mat-track-supply/mat-track-supply.module.ts ***!
    \*******************************************************************/

  /*! exports provided: MatTrackSupplyPageModule */

  /***/
  function srcAppPagesMatTrackSupplyMatTrackSupplyModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "MatTrackSupplyPageModule", function () {
      return MatTrackSupplyPageModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/fesm2015/common.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/fesm2015/forms.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
    /* harmony import */


    var _guard_dirty_guard_guard__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ../../guard/dirty-guard.guard */
    "./src/app/guard/dirty-guard.guard.ts");
    /* harmony import */


    var _mat_track_supply_page__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
    /*! ./mat-track-supply.page */
    "./src/app/pages/mat-track-supply/mat-track-supply.page.ts");
    /* harmony import */


    var _module_index__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(
    /*! ../module/index */
    "./src/app/pages/module/index.ts");

    var MatTrackSupplyPageModule = function MatTrackSupplyPageModule() {
      _classCallCheck(this, MatTrackSupplyPageModule);
    };

    MatTrackSupplyPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"], _module_index__WEBPACK_IMPORTED_MODULE_8__["SplitLabelModule"], _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild([{
        path: '',
        component: _mat_track_supply_page__WEBPACK_IMPORTED_MODULE_7__["MatTrackSupplyPage"],
        canDeactivate: [_guard_dirty_guard_guard__WEBPACK_IMPORTED_MODULE_6__["DirtyGuardGuard"]]
      }])],
      declarations: [_mat_track_supply_page__WEBPACK_IMPORTED_MODULE_7__["MatTrackSupplyPage"]]
    })], MatTrackSupplyPageModule);
    /***/
  },

  /***/
  "./src/app/pages/mat-track-supply/mat-track-supply.page.scss":
  /*!*******************************************************************!*\
    !*** ./src/app/pages/mat-track-supply/mat-track-supply.page.scss ***!
    \*******************************************************************/

  /*! exports provided: default */

  /***/
  function srcAppPagesMatTrackSupplyMatTrackSupplyPageScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "ion-img {\n  max-width: 90px;\n  width: 90px;\n  height: 90px;\n}\n\nion-card-content {\n  padding: 15px;\n}\n\nion-card-content ion-label {\n  font-size: 13px;\n}\n\nion-img + div {\n  width: calc(100% - 100px);\n  margin-left: 10px;\n  font-size: 0.95em;\n}\n\n.number-label {\n  margin: 0 6px;\n}\n\n.margin-right-30 {\n  margin-right: 30px;\n}\n\nion-icon[name=remove-circle-outline] {\n  font-size: 2em;\n}\n\nion-icon[name=add-circle-outline] {\n  font-size: 2em;\n  margin-right: -2px;\n}\n\n.batch-no-expire-date {\n  position: relative;\n  overflow: visible;\n  margin-top: 32px;\n}\n\nion-item {\n  --padding-start: 0px;\n  --inner-padding-end: 0px;\n}\n\nion-item-options {\n  border-bottom-width: 0px !important;\n}\n\n.be-be {\n  margin-right: 0px;\n}\n\n.be-be + .be-be {\n  border-top: 0.55px solid var(--ion-color-light);\n  margin-top: 6px;\n  padding-top: 6px;\n}\n\n.lock-icon {\n  top: -9px;\n  position: absolute;\n  left: 8px;\n  font-size: 30px;\n}\n\n.supply-label {\n  margin-left: 10px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Vc2Vycy9jaGFubmluZy9EZXNrdG9wL3lzdy1hcHAtc2VydmljZTQvc3JjL2FwcC9wYWdlcy9tYXQtdHJhY2stc3VwcGx5L21hdC10cmFjay1zdXBwbHkucGFnZS5zY3NzIiwic3JjL2FwcC9wYWdlcy9tYXQtdHJhY2stc3VwcGx5L21hdC10cmFjay1zdXBwbHkucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0UsZUFBQTtFQUNBLFdBQUE7RUFDQSxZQUFBO0FDQ0Y7O0FEQ0E7RUFDRSxhQUFBO0FDRUY7O0FEQUE7RUFDRSxlQUFBO0FDR0Y7O0FEREE7RUFDRSx5QkFBQTtFQUNBLGlCQUFBO0VBQ0EsaUJBQUE7QUNJRjs7QURGQTtFQUNFLGFBQUE7QUNLRjs7QURIQTtFQUNFLGtCQUFBO0FDTUY7O0FESkE7RUFDRSxjQUFBO0FDT0Y7O0FETEE7RUFDRSxjQUFBO0VBQ0Esa0JBQUE7QUNRRjs7QUROQTtFQUNFLGtCQUFBO0VBQ0EsaUJBQUE7RUFDQSxnQkFBQTtBQ1NGOztBRFBBO0VBQ0Usb0JBQUE7RUFDQSx3QkFBQTtBQ1VGOztBRFJBO0VBQ0UsbUNBQUE7QUNXRjs7QURUQTtFQUNFLGlCQUFBO0FDWUY7O0FEVkE7RUFDRSwrQ0FBQTtFQUNBLGVBQUE7RUFDQSxnQkFBQTtBQ2FGOztBRFhBO0VBQ0UsU0FBQTtFQUNBLGtCQUFBO0VBQ0EsU0FBQTtFQUNBLGVBQUE7QUNjRjs7QURaQTtFQUNFLGlCQUFBO0FDZUYiLCJmaWxlIjoic3JjL2FwcC9wYWdlcy9tYXQtdHJhY2stc3VwcGx5L21hdC10cmFjay1zdXBwbHkucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiaW9uLWltZyB7XG4gIG1heC13aWR0aDogOTBweDtcbiAgd2lkdGg6IDkwcHg7XG4gIGhlaWdodDogOTBweDtcbn1cbmlvbi1jYXJkLWNvbnRlbnQge1xuICBwYWRkaW5nOiAxNXB4O1xufVxuaW9uLWNhcmQtY29udGVudCBpb24tbGFiZWwge1xuICBmb250LXNpemU6IDEzcHg7XG59XG5pb24taW1nICsgZGl2IHtcbiAgd2lkdGg6IGNhbGMoMTAwJSAtIDEwMHB4KTtcbiAgbWFyZ2luLWxlZnQ6IDEwcHg7XG4gIGZvbnQtc2l6ZTogMC45NWVtO1xufVxuLm51bWJlci1sYWJlbCB7XG4gIG1hcmdpbjogMCA2cHg7XG59XG4ubWFyZ2luLXJpZ2h0LTMwIHtcbiAgbWFyZ2luLXJpZ2h0OiAzMHB4O1xufVxuaW9uLWljb25bbmFtZT1cInJlbW92ZS1jaXJjbGUtb3V0bGluZVwiXSB7XG4gIGZvbnQtc2l6ZTogMmVtO1xufVxuaW9uLWljb25bbmFtZT1cImFkZC1jaXJjbGUtb3V0bGluZVwiXSB7XG4gIGZvbnQtc2l6ZTogMmVtO1xuICBtYXJnaW4tcmlnaHQ6IC0ycHg7XG59XG4uYmF0Y2gtbm8tZXhwaXJlLWRhdGUge1xuICBwb3NpdGlvbjogcmVsYXRpdmU7XG4gIG92ZXJmbG93OiB2aXNpYmxlO1xuICBtYXJnaW4tdG9wOiAzMnB4O1xufVxuaW9uLWl0ZW0ge1xuICAtLXBhZGRpbmctc3RhcnQ6IDBweDtcbiAgLS1pbm5lci1wYWRkaW5nLWVuZDogMHB4O1xufVxuaW9uLWl0ZW0tb3B0aW9ucyB7XG4gIGJvcmRlci1ib3R0b20td2lkdGg6IDBweCAhaW1wb3J0YW50O1xufVxuLmJlLWJlIHtcbiAgbWFyZ2luLXJpZ2h0OiAwcHg7XG59XG4uYmUtYmUgKyAuYmUtYmUge1xuICBib3JkZXItdG9wOiAwLjU1cHggc29saWQgdmFyKC0taW9uLWNvbG9yLWxpZ2h0KTtcbiAgbWFyZ2luLXRvcDogNnB4O1xuICBwYWRkaW5nLXRvcDogNnB4O1xufVxuLmxvY2staWNvbiB7XG4gIHRvcDogLTlweDtcbiAgcG9zaXRpb246IGFic29sdXRlO1xuICBsZWZ0OiA4cHg7XG4gIGZvbnQtc2l6ZTogMzBweDtcbn1cbi5zdXBwbHktbGFiZWwge1xuICBtYXJnaW4tbGVmdDogMTBweDtcbn1cbiIsImlvbi1pbWcge1xuICBtYXgtd2lkdGg6IDkwcHg7XG4gIHdpZHRoOiA5MHB4O1xuICBoZWlnaHQ6IDkwcHg7XG59XG5cbmlvbi1jYXJkLWNvbnRlbnQge1xuICBwYWRkaW5nOiAxNXB4O1xufVxuXG5pb24tY2FyZC1jb250ZW50IGlvbi1sYWJlbCB7XG4gIGZvbnQtc2l6ZTogMTNweDtcbn1cblxuaW9uLWltZyArIGRpdiB7XG4gIHdpZHRoOiBjYWxjKDEwMCUgLSAxMDBweCk7XG4gIG1hcmdpbi1sZWZ0OiAxMHB4O1xuICBmb250LXNpemU6IDAuOTVlbTtcbn1cblxuLm51bWJlci1sYWJlbCB7XG4gIG1hcmdpbjogMCA2cHg7XG59XG5cbi5tYXJnaW4tcmlnaHQtMzAge1xuICBtYXJnaW4tcmlnaHQ6IDMwcHg7XG59XG5cbmlvbi1pY29uW25hbWU9cmVtb3ZlLWNpcmNsZS1vdXRsaW5lXSB7XG4gIGZvbnQtc2l6ZTogMmVtO1xufVxuXG5pb24taWNvbltuYW1lPWFkZC1jaXJjbGUtb3V0bGluZV0ge1xuICBmb250LXNpemU6IDJlbTtcbiAgbWFyZ2luLXJpZ2h0OiAtMnB4O1xufVxuXG4uYmF0Y2gtbm8tZXhwaXJlLWRhdGUge1xuICBwb3NpdGlvbjogcmVsYXRpdmU7XG4gIG92ZXJmbG93OiB2aXNpYmxlO1xuICBtYXJnaW4tdG9wOiAzMnB4O1xufVxuXG5pb24taXRlbSB7XG4gIC0tcGFkZGluZy1zdGFydDogMHB4O1xuICAtLWlubmVyLXBhZGRpbmctZW5kOiAwcHg7XG59XG5cbmlvbi1pdGVtLW9wdGlvbnMge1xuICBib3JkZXItYm90dG9tLXdpZHRoOiAwcHggIWltcG9ydGFudDtcbn1cblxuLmJlLWJlIHtcbiAgbWFyZ2luLXJpZ2h0OiAwcHg7XG59XG5cbi5iZS1iZSArIC5iZS1iZSB7XG4gIGJvcmRlci10b3A6IDAuNTVweCBzb2xpZCB2YXIoLS1pb24tY29sb3ItbGlnaHQpO1xuICBtYXJnaW4tdG9wOiA2cHg7XG4gIHBhZGRpbmctdG9wOiA2cHg7XG59XG5cbi5sb2NrLWljb24ge1xuICB0b3A6IC05cHg7XG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgbGVmdDogOHB4O1xuICBmb250LXNpemU6IDMwcHg7XG59XG5cbi5zdXBwbHktbGFiZWwge1xuICBtYXJnaW4tbGVmdDogMTBweDtcbn0iXX0= */";
    /***/
  },

  /***/
  "./src/app/pages/mat-track-supply/mat-track-supply.page.ts":
  /*!*****************************************************************!*\
    !*** ./src/app/pages/mat-track-supply/mat-track-supply.page.ts ***!
    \*****************************************************************/

  /*! exports provided: MatTrackSupplyPage */

  /***/
  function srcAppPagesMatTrackSupplyMatTrackSupplyPageTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "MatTrackSupplyPage", function () {
      return MatTrackSupplyPage;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
    /* harmony import */


    var js_base64__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! js-base64 */
    "./node_modules/js-base64/base64.js");
    /* harmony import */


    var js_base64__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(js_base64__WEBPACK_IMPORTED_MODULE_4__);
    /* harmony import */


    var _components_index__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ../../components/index */
    "./src/app/components/index.ts");
    /* harmony import */


    var _service_index__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ../../service/index */
    "./src/app/service/index.ts");
    /* harmony import */


    var _modal_batch_expire_batch_expire_page__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
    /*! ../modal/batch-expire/batch-expire.page */
    "./src/app/pages/modal/batch-expire/batch-expire.page.ts");
    /* harmony import */


    var rxjs__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(
    /*! rxjs */
    "./node_modules/rxjs/_esm2015/index.js");

    var MatTrackSupplyPage = /*#__PURE__*/function () {
      function MatTrackSupplyPage(commonUtils, activeRoute, modalCtrl, navCtrl, storageUtils, matTrackService) {
        var _this = this;

        _classCallCheck(this, MatTrackSupplyPage);

        this.commonUtils = commonUtils;
        this.activeRoute = activeRoute;
        this.modalCtrl = modalCtrl;
        this.navCtrl = navCtrl;
        this.storageUtils = storageUtils;
        this.matTrackService = matTrackService;
        this.dirty = false;
        this.collapse = true;
        this.matTrack = {};
        this.beList = [];
        this.storageAlert = 0;
        var alertSettings = this.storageUtils.get(_components_index__WEBPACK_IMPORTED_MODULE_5__["ProjectConstant"].STORAGE_KEY_ALERT_SETTINGS);
        this.storageAlert = alertSettings.storage;
        this.activeRoute.queryParams.subscribe(function (params) {
          if (!_this.commonUtils.isNull(params.matTrack)) {
            try {
              _this.matTrack = JSON.parse(js_base64__WEBPACK_IMPORTED_MODULE_4__["Base64"].decode(params.matTrack));
              _this.matTrack.supplyNumber = 0;
              console.log(_this.matTrack);
            } catch (e) {
              _this.matTrack = {};
              console.error(e);
            }
          }

          if (!_this.commonUtils.isNullOrEmptyString(params.matName)) {
            _this.matName = js_base64__WEBPACK_IMPORTED_MODULE_4__["Base64"].decode(params.matName);
          }
        });
      }

      _createClass(MatTrackSupplyPage, [{
        key: "ngOnInit",
        value: function ngOnInit() {
          return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
            return regeneratorRuntime.wrap(function _callee$(_context) {
              while (1) {
                switch (_context.prev = _context.next) {
                  case 0:
                    _context.next = 2;
                    return this.loadBatchNoAndExpireDate();

                  case 2:
                    this.beList = _context.sent;

                  case 3:
                  case "end":
                    return _context.stop();
                }
              }
            }, _callee, this);
          }));
        }
      }, {
        key: "loadBatchNoAndExpireDate",
        value: function loadBatchNoAndExpireDate() {
          return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee2() {
            return regeneratorRuntime.wrap(function _callee2$(_context2) {
              while (1) {
                switch (_context2.prev = _context2.next) {
                  case 0:
                    _context2.next = 2;
                    return this.matTrackService.getBatchNoAndExpireDate(this.matTrack.id);

                  case 2:
                    return _context2.abrupt("return", _context2.sent);

                  case 3:
                  case "end":
                    return _context2.stop();
                }
              }
            }, _callee2, this);
          }));
        }
      }, {
        key: "minusNumber",
        value: function minusNumber(matTrack) {
          return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee3() {
            var res;
            return regeneratorRuntime.wrap(function _callee3$(_context3) {
              while (1) {
                switch (_context3.prev = _context3.next) {
                  case 0:
                    if (!(matTrack.supplyNumber <= 0)) {
                      _context3.next = 7;
                      break;
                    }

                    _context3.next = 3;
                    return this.commonUtils.showConfirm('确认', '补货数量为负数意味着撤回商品？');

                  case 3:
                    res = _context3.sent;

                    if (res) {
                      matTrack.supplyNumber--;
                    }

                    _context3.next = 8;
                    break;

                  case 7:
                    matTrack.supplyNumber--;

                  case 8:
                  case "end":
                    return _context3.stop();
                }
              }
            }, _callee3, this);
          }));
        }
      }, {
        key: "plusNumber",
        value: function plusNumber(matTrack) {
          if (matTrack.supplyNumber + matTrack.goodsNumber >= matTrack.maxNumber) {
            this.commonUtils.showToast('补货数量不能超过货道最大限制！');
            return;
          }

          matTrack.supplyNumber++;
        }
      }, {
        key: "minusBENumber",
        value: function minusBENumber(be) {
          return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee4() {
            var res;
            return regeneratorRuntime.wrap(function _callee4$(_context4) {
              while (1) {
                switch (_context4.prev = _context4.next) {
                  case 0:
                    if (!(be.goodsNumber === 1)) {
                      _context4.next = 7;
                      break;
                    }

                    _context4.next = 3;
                    return this.commonUtils.showConfirm('确认', '是否确认将该批号、效期数量置为零？');

                  case 3:
                    res = _context4.sent;

                    if (res) {
                      be.goodsNumber--;
                    }

                    _context4.next = 8;
                    break;

                  case 7:
                    if (be.goodsNumber < 1) {
                      this.commonUtils.showToast('批号、效期数量不能为负数！');
                    } else {
                      be.goodsNumber--;
                    }

                  case 8:
                  case "end":
                    return _context4.stop();
                }
              }
            }, _callee4, this);
          }));
        }
      }, {
        key: "plusBENumber",
        value: function plusBENumber(be) {
          var beCount = 0;
          this.beList.forEach(function (item) {
            beCount += parseInt(item.goodsNumber, 10);
          });

          if (this.matTrack.supplyNumber + this.matTrack.goodsNumber > beCount) {
            be.goodsNumber++;
          } else {
            this.commonUtils.showToast('批号、效期数量不允许超过合计数量！');
          }
        }
      }, {
        key: "onDelete",
        value: function onDelete(be, index) {
          return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee5() {
            var res;
            return regeneratorRuntime.wrap(function _callee5$(_context5) {
              while (1) {
                switch (_context5.prev = _context5.next) {
                  case 0:
                    _context5.next = 2;
                    return this.commonUtils.showConfirm('确认', '是否确认删除该批号、效期？');

                  case 2:
                    res = _context5.sent;

                    if (!res) {
                      _context5.next = 9;
                      break;
                    }

                    this.beList.splice(index, 1);

                    if (this.commonUtils.isNull(be.id)) {
                      _context5.next = 9;
                      break;
                    }

                    _context5.next = 8;
                    return this.matTrackService.deleteBatchNoAndExpireDate(be.id);

                  case 8:
                    this.dirty = true;

                  case 9:
                  case "end":
                    return _context5.stop();
                }
              }
            }, _callee5, this);
          }));
        }
      }, {
        key: "addBE",
        value: function addBE() {
          return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee6() {
            var modal, _ref, data;

            return regeneratorRuntime.wrap(function _callee6$(_context6) {
              while (1) {
                switch (_context6.prev = _context6.next) {
                  case 0:
                    _context6.next = 2;
                    return this.modalCtrl.create({
                      component: _modal_batch_expire_batch_expire_page__WEBPACK_IMPORTED_MODULE_7__["BatchExpirePage"],
                      backdropDismiss: true,
                      cssClass: 'ysw-action-modal-vertical2'
                    });

                  case 2:
                    modal = _context6.sent;
                    _context6.next = 5;
                    return modal.present();

                  case 5:
                    _context6.next = 7;
                    return modal.onWillDismiss();

                  case 7:
                    _ref = _context6.sent;
                    data = _ref.data;

                    if (!this.commonUtils.isNull(data)) {
                      this.beList.unshift({
                        trackGoodsId: this.matTrack.id,
                        goodsNumber: data.goodsNumber,
                        batchNo: data.batchNo,
                        expireDate: data.expireDate
                      });
                    }

                  case 10:
                  case "end":
                    return _context6.stop();
                }
              }
            }, _callee6, this);
          }));
        }
      }, {
        key: "saveSupply",
        value: function saveSupply() {
          return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee7() {
            var _this2 = this;

            var beCount, res, loading, payload;
            return regeneratorRuntime.wrap(function _callee7$(_context7) {
              while (1) {
                switch (_context7.prev = _context7.next) {
                  case 0:
                    beCount = 0;
                    this.beList.forEach(function (item) {
                      beCount += parseInt(item.goodsNumber, 10);
                    });

                    if (!(this.matTrack.supplyNumber + this.matTrack.goodsNumber !== beCount)) {
                      _context7.next = 5;
                      break;
                    }

                    this.commonUtils.showToast('批号、效期数量必须与合计数量相同！');
                    return _context7.abrupt("return");

                  case 5:
                    _context7.next = 7;
                    return this.commonUtils.showConfirm('确认', '是否确认调整商品库存？');

                  case 7:
                    res = _context7.sent;

                    if (!res) {
                      _context7.next = 17;
                      break;
                    }

                    loading = this.commonUtils.showLoading('正在提交...');
                    payload = {
                      matId: this.matTrack.matId,
                      supplySets: [{
                        trackGoodsId: this.matTrack.id,
                        goodsId: this.matTrack.goodsId,
                        supplyNumber: this.matTrack.supplyNumber,
                        matGoodsStorageSets: this.beList
                      }]
                    };
                    _context7.next = 13;
                    return this.matTrackService.supplyMatTrackGoods(payload);

                  case 13:
                    this.commonUtils.hideLoadingSync(loading);
                    this.commonUtils.showToast('提交成功！', 'middle', 1000);
                    this.dirty = false;
                    setTimeout(function () {
                      _this2.navCtrl.pop();

                      _this2.storageUtils.set(_components_index__WEBPACK_IMPORTED_MODULE_5__["ProjectConstant"].STORAGE_KEY_REFRESH, true);
                    }, 1000);

                  case 17:
                  case "end":
                    return _context7.stop();
                }
              }
            }, _callee7, this);
          }));
        }
      }, {
        key: "imageError",
        value: function imageError(event) {
          event.target.src = 'assets/imgs/mat/goods-no-image.svg';
        }
      }, {
        key: "dirtyCheck",
        value: function dirtyCheck() {
          var _this3 = this;

          // tslint:disable-next-line: deprecation
          return rxjs__WEBPACK_IMPORTED_MODULE_8__["Observable"].create(function (observer) {
            if (_this3.dirty) {
              _this3.commonUtils.showAlert('页面离开提示', '', '数据尚未保存，请先点击完成保存数据！');

              observer.next(false);
            } else {
              observer.next(true);
            }
          });
        }
      }]);

      return MatTrackSupplyPage;
    }();

    MatTrackSupplyPage.ctorParameters = function () {
      return [{
        type: _components_index__WEBPACK_IMPORTED_MODULE_5__["CommonUtils"]
      }, {
        type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["ModalController"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["NavController"]
      }, {
        type: _components_index__WEBPACK_IMPORTED_MODULE_5__["StorageUtils"]
      }, {
        type: _service_index__WEBPACK_IMPORTED_MODULE_6__["MatTrackService"]
      }];
    };

    MatTrackSupplyPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-mat-track-supply',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./mat-track-supply.page.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/mat-track-supply/mat-track-supply.page.html")).default,
      providers: [_service_index__WEBPACK_IMPORTED_MODULE_6__["MatTrackService"]],
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./mat-track-supply.page.scss */
      "./src/app/pages/mat-track-supply/mat-track-supply.page.scss")).default]
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_components_index__WEBPACK_IMPORTED_MODULE_5__["CommonUtils"], _angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"], _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["ModalController"], _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["NavController"], _components_index__WEBPACK_IMPORTED_MODULE_5__["StorageUtils"], _service_index__WEBPACK_IMPORTED_MODULE_6__["MatTrackService"]])], MatTrackSupplyPage);
    /***/
  }
}]);
//# sourceMappingURL=mat-track-supply-mat-track-supply-module-es5.js.map