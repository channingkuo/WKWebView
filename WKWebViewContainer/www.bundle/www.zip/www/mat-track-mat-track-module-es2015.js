(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["mat-track-mat-track-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/mat-track/mat-track.page.html":
/*!*******************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/mat-track/mat-track.page.html ***!
  \*******************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\n  <ion-toolbar color=\"ysw\">\n    <ion-buttons slot=\"start\">\n      <ion-back-button></ion-back-button>\n    </ion-buttons>\n    <ion-title>{{matName}} <small>{{matNo}}</small></ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <ion-refresher slot=\"fixed\" (ionRefresh)=\"doRefresh($event)\" pullMax=\"2000\">\n    <ion-refresher-content></ion-refresher-content>\n  </ion-refresher>\n\n  <ion-header collapse=\"condense\">\n    <ion-toolbar color=\"ysw\">\n      <ion-title size=\"large\">货道·商品 - <small>{{matName}}</small></ion-title>\n    </ion-toolbar>\n\n    <ion-toolbar color=\"ysw\">\n      <ion-searchbar color=\"light\" placeholder=\"轨道编号、商品名称\" showCancelButton=\"focus\" cancelButtonText=\"取消\"\n        inputmode=\"search\" [(ngModel)]=\"queryString\" [debounce]=\"2000\" (ionInput)=\"onSearch($event)\"></ion-searchbar>\n    </ion-toolbar>\n  </ion-header>\n\n  <skeleton [loading]=\"loading\">\n    <ion-list>\n      <ng-container *ngFor=\"let matTrack of matTrackList\">\n        <ion-card>\n          <ion-card-header>\n            <ion-card-title class=\"flex ion-justify-content-between ion-align-items-center m-b-5\">\n              <ion-label style=\"width: 100px;\">\n                <ion-label [color]=\"matTrack.goodsId && matTrack.goodsName ? '' : 'medium'\">{{matTrack.goodsTrack}}\n                </ion-label>\n                <ion-icon class=\"lock-icon\" *ngIf=\"!matTrack.isPublish\" color=\"danger\" name=\"lock-closed-outline\">\n                </ion-icon>\n              </ion-label>\n              <ion-label>\n                <ng-container *ngIf=\"matTrack.goodsId && matTrack.goodsName;else noGoods\">\n                  <ion-label>{{(matTrack.brandName || '') + ' '}}{{matTrack.goodsName}}</ion-label>\n                </ng-container>\n                <ng-template #noGoods>\n                  <ion-label color=\"medium\">暂未绑定商品</ion-label>\n                </ng-template>\n              </ion-label>\n            </ion-card-title>\n          </ion-card-header>\n          <ion-card-content>\n            <div class=\"flex ion-justify-content-start ion-align-items-start\">\n              <ion-img (ionError)=\"imageError($event)\" *ngIf=\"matTrack.goodsId && matTrack.goodsName\"\n                [src]=\"matTrack.goodsImage || 'assets/imgs/mat/goods-no-image.svg'\" [alt]=\"matTrack.goodsTrack\">\n              </ion-img>\n              <div *ngIf=\"!matTrack.goodsId || !matTrack.goodsName\"\n                class=\"track-no-goods flex ion-justify-content-center ion-align-items-center\">\n                暂未绑定商品\n              </div>\n              <div class=\"flex ion-justify-content-center ion-align-items-start flex-column\">\n                <ion-label>\n                  <ion-label color=\"dark\">规格：</ion-label>{{matTrack.goodsPackage || '-'}}\n                </ion-label>\n                <ion-label class=\"m-t-10\">\n                  <ion-label color=\"dark\">厂商：</ion-label>{{matTrack.mfrName || '-'}}\n                </ion-label>\n                <ion-label class=\"flex ion-justify-content-between ion-align-items-center m-t-10 w-100p\">\n                  <ion-label>\n                    <ion-label color=\"dark\">最大：</ion-label>{{matTrack.maxNumber || '-'}} {{matTrack.goodsUnit}}\n                  </ion-label>\n                  <ion-label class=\"w-55p\">\n                    <ion-label color=\"dark\">库存：</ion-label>\n                    <ng-container *ngIf=\"matTrack.goodsNumber && matTrack.goodsNumber > 0;else noGoodsNumber\">\n                      <ion-label [color]=\"matTrack.goodsNumber <= storageAlert ? 'warning' : ''\">\n                        {{matTrack.goodsNumber}}<ion-label color=\"danger\" *ngIf=\"matTrack.lockedNumber\">\n                          [{{matTrack.lockedNumber || '-'}}]</ion-label> {{matTrack.goodsUnit}}\n                      </ion-label>\n                    </ng-container>\n                    <ng-template #noGoodsNumber>\n                      <ion-label color=\"danger\">售罄</ion-label>\n                    </ng-template>\n                  </ion-label>\n                </ion-label>\n                <ion-label class=\"flex ion-justify-content-between ion-align-items-center m-t-10 w-100p\">\n                  <ion-label>\n                    <ion-label color=\"dark\">限购：</ion-label>{{matTrack.limitation}} {{matTrack.goodsUnit}}\n                  </ion-label>\n                  <ion-label class=\"w-55p\">\n                    <ion-label color=\"dark\">价格：</ion-label>\n                    <ion-label color=\"danger\">{{matTrack.goodsPrice| currency: '￥'}}</ion-label>\n                  </ion-label>\n                </ion-label>\n              </div>\n            </div>\n            <div *ngIf=\"hideActions !== 1\" class=\"m-t-5 text-right\">\n              <ion-button *ngIf=\"matTrack.trackType === 1\" style=\"height: 32px;\" (click)=\"openMatTrack(matTrack)\"\n                size=\"small\" color=\"ysw\">打开</ion-button>\n              <ion-button style=\"height: 32px;\" (click)=\"bindGoods(matTrack)\" size=\"small\" color=\"ysw\">绑定商品</ion-button>\n              <ion-button *ngIf=\"canModityQuantity\" style=\"height: 32px;\" (click)=\"supplyGoods(matTrack)\" size=\"small\"\n                color=\"ysw\">调整库存\n              </ion-button>\n              <ion-button style=\"height: 32px;\" (click)=\"changeGoodsPrice(matTrack)\" size=\"small\" color=\"ysw\">调整价格\n              </ion-button>\n              <ion-button *ngIf=\"canViewMore\" style=\"height: 32px;\" (click)=\"showMoreActions(matTrack)\" size=\"small\"\n                color=\"ysw\">更多\n              </ion-button>\n            </div>\n          </ion-card-content>\n        </ion-card>\n      </ng-container>\n    </ion-list>\n  </skeleton>\n</ion-content>");

/***/ }),

/***/ "./src/app/pages/mat-track/mat-track.module.ts":
/*!*****************************************************!*\
  !*** ./src/app/pages/mat-track/mat-track.module.ts ***!
  \*****************************************************/
/*! exports provided: MatTrackPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MatTrackPageModule", function() { return MatTrackPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm2015/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
/* harmony import */ var _mat_track_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./mat-track.page */ "./src/app/pages/mat-track/mat-track.page.ts");
/* harmony import */ var _module_index__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../module/index */ "./src/app/pages/module/index.ts");








let MatTrackPageModule = class MatTrackPageModule {
};
MatTrackPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"],
            _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild([
                {
                    path: '',
                    component: _mat_track_page__WEBPACK_IMPORTED_MODULE_6__["MatTrackPage"]
                }, {
                    path: 'supply',
                    loadChildren: () => __webpack_require__.e(/*! import() | mat-track-supply-mat-track-supply-module */ "mat-track-supply-mat-track-supply-module").then(__webpack_require__.bind(null, /*! ../mat-track-supply/mat-track-supply.module */ "./src/app/pages/mat-track-supply/mat-track-supply.module.ts")).then(m => m.MatTrackSupplyPageModule)
                }
            ]),
            _module_index__WEBPACK_IMPORTED_MODULE_7__["EmptyModule"],
            _module_index__WEBPACK_IMPORTED_MODULE_7__["SkeletonModule"]
        ],
        declarations: [_mat_track_page__WEBPACK_IMPORTED_MODULE_6__["MatTrackPage"]]
    })
], MatTrackPageModule);



/***/ }),

/***/ "./src/app/pages/mat-track/mat-track.page.scss":
/*!*****************************************************!*\
  !*** ./src/app/pages/mat-track/mat-track.page.scss ***!
  \*****************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("ion-card-title ion-label {\n  font-size: 0.8em;\n}\n\nion-img {\n  max-width: 90px;\n  width: 90px;\n  height: 100px;\n}\n\n.track-no-goods {\n  width: 90px;\n  min-width: 90px;\n  height: 90px;\n  border: 0.55px solid #eee;\n  border-radius: 6px;\n  font-size: 0.8em;\n}\n\nion-img + div,\n.track-no-goods + div {\n  width: calc(100% - 100px);\n  margin-left: 10px;\n  font-size: 0.95em;\n}\n\nion-button {\n  --padding-start: 6px;\n  --padding-end: 6px;\n}\n\n.lock-icon {\n  top: -3px;\n  position: absolute;\n  left: 9px;\n  font-size: 30px;\n}\n\nion-card-content ion-label {\n  font-size: 13px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Vc2Vycy9jaGFubmluZy9EZXNrdG9wL3lzdy1hcHAtc2VydmljZTQvc3JjL2FwcC9wYWdlcy9tYXQtdHJhY2svbWF0LXRyYWNrLnBhZ2Uuc2NzcyIsInNyYy9hcHAvcGFnZXMvbWF0LXRyYWNrL21hdC10cmFjay5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSxnQkFBQTtBQ0NGOztBRENBO0VBQ0UsZUFBQTtFQUNBLFdBQUE7RUFDQSxhQUFBO0FDRUY7O0FEQUE7RUFDRSxXQUFBO0VBQ0EsZUFBQTtFQUNBLFlBQUE7RUFDQSx5QkFBQTtFQUNBLGtCQUFBO0VBQ0EsZ0JBQUE7QUNHRjs7QUREQTs7RUFFRSx5QkFBQTtFQUNBLGlCQUFBO0VBQ0EsaUJBQUE7QUNJRjs7QURGQTtFQUNFLG9CQUFBO0VBQ0Esa0JBQUE7QUNLRjs7QURIQTtFQUNFLFNBQUE7RUFDQSxrQkFBQTtFQUNBLFNBQUE7RUFDQSxlQUFBO0FDTUY7O0FESkE7RUFDRSxlQUFBO0FDT0YiLCJmaWxlIjoic3JjL2FwcC9wYWdlcy9tYXQtdHJhY2svbWF0LXRyYWNrLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbImlvbi1jYXJkLXRpdGxlIGlvbi1sYWJlbCB7XG4gIGZvbnQtc2l6ZTogMC44ZW07XG59XG5pb24taW1nIHtcbiAgbWF4LXdpZHRoOiA5MHB4O1xuICB3aWR0aDogOTBweDtcbiAgaGVpZ2h0OiAxMDBweDtcbn1cbi50cmFjay1uby1nb29kcyB7XG4gIHdpZHRoOiA5MHB4O1xuICBtaW4td2lkdGg6IDkwcHg7XG4gIGhlaWdodDogOTBweDtcbiAgYm9yZGVyOiAwLjU1cHggc29saWQgI2VlZTtcbiAgYm9yZGVyLXJhZGl1czogNnB4O1xuICBmb250LXNpemU6IDAuOGVtO1xufVxuaW9uLWltZyArIGRpdixcbi50cmFjay1uby1nb29kcyArIGRpdiB7XG4gIHdpZHRoOiBjYWxjKDEwMCUgLSAxMDBweCk7XG4gIG1hcmdpbi1sZWZ0OiAxMHB4O1xuICBmb250LXNpemU6IDAuOTVlbTtcbn1cbmlvbi1idXR0b24ge1xuICAtLXBhZGRpbmctc3RhcnQ6IDZweDtcbiAgLS1wYWRkaW5nLWVuZDogNnB4O1xufVxuLmxvY2staWNvbiB7XG4gIHRvcDogLTNweDtcbiAgcG9zaXRpb246IGFic29sdXRlO1xuICBsZWZ0OiA5cHg7XG4gIGZvbnQtc2l6ZTogMzBweDtcbn1cbmlvbi1jYXJkLWNvbnRlbnQgaW9uLWxhYmVsIHtcbiAgZm9udC1zaXplOiAxM3B4O1xufSIsImlvbi1jYXJkLXRpdGxlIGlvbi1sYWJlbCB7XG4gIGZvbnQtc2l6ZTogMC44ZW07XG59XG5cbmlvbi1pbWcge1xuICBtYXgtd2lkdGg6IDkwcHg7XG4gIHdpZHRoOiA5MHB4O1xuICBoZWlnaHQ6IDEwMHB4O1xufVxuXG4udHJhY2stbm8tZ29vZHMge1xuICB3aWR0aDogOTBweDtcbiAgbWluLXdpZHRoOiA5MHB4O1xuICBoZWlnaHQ6IDkwcHg7XG4gIGJvcmRlcjogMC41NXB4IHNvbGlkICNlZWU7XG4gIGJvcmRlci1yYWRpdXM6IDZweDtcbiAgZm9udC1zaXplOiAwLjhlbTtcbn1cblxuaW9uLWltZyArIGRpdixcbi50cmFjay1uby1nb29kcyArIGRpdiB7XG4gIHdpZHRoOiBjYWxjKDEwMCUgLSAxMDBweCk7XG4gIG1hcmdpbi1sZWZ0OiAxMHB4O1xuICBmb250LXNpemU6IDAuOTVlbTtcbn1cblxuaW9uLWJ1dHRvbiB7XG4gIC0tcGFkZGluZy1zdGFydDogNnB4O1xuICAtLXBhZGRpbmctZW5kOiA2cHg7XG59XG5cbi5sb2NrLWljb24ge1xuICB0b3A6IC0zcHg7XG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgbGVmdDogOXB4O1xuICBmb250LXNpemU6IDMwcHg7XG59XG5cbmlvbi1jYXJkLWNvbnRlbnQgaW9uLWxhYmVsIHtcbiAgZm9udC1zaXplOiAxM3B4O1xufSJdfQ== */");

/***/ }),

/***/ "./src/app/pages/mat-track/mat-track.page.ts":
/*!***************************************************!*\
  !*** ./src/app/pages/mat-track/mat-track.page.ts ***!
  \***************************************************/
/*! exports provided: MatTrackPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MatTrackPage", function() { return MatTrackPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
/* harmony import */ var _components_index__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../components/index */ "./src/app/components/index.ts");
/* harmony import */ var _service_index__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../service/index */ "./src/app/service/index.ts");
/* harmony import */ var js_base64__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! js-base64 */ "./node_modules/js-base64/base64.js");
/* harmony import */ var js_base64__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(js_base64__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _modal_goods_select_goods_select_page__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../modal/goods-select/goods-select.page */ "./src/app/pages/modal/goods-select/goods-select.page.ts");
/* harmony import */ var _modal_swap_track_goods_swap_track_goods_page__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../modal/swap-track-goods/swap-track-goods.page */ "./src/app/pages/modal/swap-track-goods/swap-track-goods.page.ts");
/* harmony import */ var _service_mat_cab_service__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../service/mat.cab.service */ "./src/app/service/mat.cab.service.ts");










let MatTrackPage = class MatTrackPage {
    constructor(activeRoute, commonUtils, storageUtils, matService, matTrackService, meituanService, router, alertCtrl, modalCtrl, matCabService, actionSheetCtrl) {
        this.activeRoute = activeRoute;
        this.commonUtils = commonUtils;
        this.storageUtils = storageUtils;
        this.matService = matService;
        this.matTrackService = matTrackService;
        this.meituanService = meituanService;
        this.router = router;
        this.alertCtrl = alertCtrl;
        this.modalCtrl = modalCtrl;
        this.matCabService = matCabService;
        this.actionSheetCtrl = actionSheetCtrl;
        this.storageAlert = 0;
        this.queryString = '';
        this.matTrackList = [];
        this.loading = true;
        this.canModityQuantity = true;
        this.canViewMore = true;
        const alertSettings = this.storageUtils.get(_components_index__WEBPACK_IMPORTED_MODULE_4__["ProjectConstant"].STORAGE_KEY_ALERT_SETTINGS);
        this.storageAlert = alertSettings.storage;
        this.activeRoute.queryParams.subscribe((params) => {
            this.matName = js_base64__WEBPACK_IMPORTED_MODULE_6__["Base64"].decode(params.matName);
            this.matId = params.matId;
            this.matNo = params.matNo;
            this.hideActions = parseInt(params.hideAction, 10);
            this.enableMeituan = parseInt(params.enableMeituan, 10);
            if (!commonUtils.isNullOrEmptyString(params.query)) {
                this.queryString = params.query;
            }
            // 处理子页面返回刷新当前页面
            const refresh = this.storageUtils.get(_components_index__WEBPACK_IMPORTED_MODULE_4__["ProjectConstant"].STORAGE_KEY_REFRESH);
            if (refresh) {
                setTimeout(() => tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
                    this.matTrackList = yield this.loadMatTrackGoodsList();
                    this.storageUtils.remove(_components_index__WEBPACK_IMPORTED_MODULE_4__["ProjectConstant"].STORAGE_KEY_REFRESH);
                }), 555);
            }
        });
        this.userInfo = this.storageUtils.get(_components_index__WEBPACK_IMPORTED_MODULE_4__["ProjectConstant"].STORAGE_KEY_USERINFO);
        if (this.userInfo.role === 'Service'
            && (this.userInfo.type === _components_index__WEBPACK_IMPORTED_MODULE_4__["ProjectConstant"].AGENT_STORE || this.userInfo.type === _components_index__WEBPACK_IMPORTED_MODULE_4__["ProjectConstant"].AGENT_STORE_HEADER)) {
            this.canViewMore = false;
            this.canModityQuantity = false;
        }
    }
    ngOnInit() {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            this.matTrackList = yield this.loadMatTrackGoodsList();
            this.loading = false;
        });
    }
    loadMatTrackGoodsList() {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            if (this.commonUtils.isNull(this.matId)) {
                this.commonUtils.showToast('售药机Id丢失！');
                return;
            }
            // const loading = this.commonUtils.showLoading('正在加载...');
            const data = yield this.matService.getMatTrackGoodsList(this.matId, this.queryString);
            // this.commonUtils.hideLoadingSync(loading);
            return data;
        });
    }
    onSearch(event) {
        if (this.timer) {
            clearTimeout(this.timer);
        }
        this.timer = setTimeout(() => tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            this.matTrackList = yield this.loadMatTrackGoodsList();
        }), 2000);
    }
    doRefresh(event) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            this.matTrackList = yield this.loadMatTrackGoodsList();
            event.target.complete();
        });
    }
    supplyGoods(matTrack) {
        if (matTrack.enableErp === _components_index__WEBPACK_IMPORTED_MODULE_4__["ProjectConstant"].ENABLE_ERP) {
            this.commonUtils.showToast('开启ERP对接的售药机只能在Web端修改库存！');
            return;
        }
        if (!matTrack.goodsId || !matTrack.goodsName) {
            this.commonUtils.showToast('该货道暂未绑定商品！');
            return;
        }
        this.router.navigate(['../supply'], {
            relativeTo: this.activeRoute,
            queryParams: {
                matTrack: js_base64__WEBPACK_IMPORTED_MODULE_6__["Base64"].encode(JSON.stringify(matTrack)),
                matName: js_base64__WEBPACK_IMPORTED_MODULE_6__["Base64"].encode(this.matName)
            }
        });
    }
    bindGoods(matTrack) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            let openModal = false;
            if (this.commonUtils.isNullOrEmptyString(matTrack.goodsId)
                || this.commonUtils.isNullOrEmptyString(matTrack.goodsName)) {
                openModal = true;
            }
            else {
                if (matTrack.goodsNumber <= 0) {
                    openModal = yield this.commonUtils.showConfirm('确认', '该货道上已绑定商品，是否要更换商品！');
                }
                else {
                    this.commonUtils.showToast('该货道上已绑定商品，要更换商品，请先清空库存！');
                    return;
                }
            }
            if (openModal) {
                const modal = yield this.modalCtrl.create({
                    component: _modal_goods_select_goods_select_page__WEBPACK_IMPORTED_MODULE_7__["GoodsSelectPage"],
                    componentProps: {
                        matId: matTrack.matId
                    },
                    cssClass: 'ysw-common-modal-vertical',
                    swipeToClose: true
                });
                yield modal.present();
                const { data } = yield modal.onWillDismiss();
                if (!this.commonUtils.isNull(data)) {
                    yield this.bindGoodsToTrack(data, matTrack);
                }
            }
        });
    }
    bindGoodsToTrack(goods, matTrack) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            const loading = this.commonUtils.showLoading('正在绑定...');
            yield this.matTrackService.changeMatTrackGoods(matTrack.matId, matTrack.id, goods);
            this.commonUtils.hideLoadingSync(loading);
            this.commonUtils.showToast('绑定成功!');
            this.syncChangeGoodsToMeituan(matTrack, goods);
            // 刷新页面
            this.matTrackList = yield this.loadMatTrackGoodsList();
            this.commonUtils.showToast('新商品价格为建议价格，请尽快调整为正常售卖价格！', 'middle', 5000);
        });
    }
    syncChangeGoodsToMeituan(matTrack, goods) {
        if (this.enableMeituan === 1) {
            const syncPayload = {
                matId: this.matId,
                goodsId: matTrack.goodsId,
                type: 5,
                newGoodsId: goods.goodsId
            };
            this.meituanService.updateMatGoodsToMeituan(syncPayload);
        }
    }
    changeMaxNumber(matTrack) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            const alert = yield this.alertCtrl.create({
                header: matTrack.goodsTrack,
                message: '调整轨道核定数',
                inputs: [{
                        name: 'maxNumber',
                        type: 'number',
                        placeholder: '请输入轨道核定数'
                    }],
                buttons: [{
                        text: '取消',
                        role: 'cancel',
                        cssClass: 'secondary',
                        handler: () => { }
                    }, {
                        text: '确认',
                        handler: (data) => tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
                            if (!this.commonUtils.isNullOrEmptyString(data)
                                && !this.commonUtils.isNullOrEmptyString(data.maxNumber)) {
                                if (data.maxNumber < matTrack.goodsNumber) {
                                    this.commonUtils.showToast('修改后的轨道核定数不能少于库存数！');
                                    return;
                                }
                                yield this.matTrackService.changeMatTrackGoodsMaxNumber(matTrack.matId, matTrack.id, data.maxNumber);
                                // 刷新页面
                                this.matTrackList = yield this.loadMatTrackGoodsList();
                            }
                            else {
                                this.commonUtils.showToast('请输入轨道核定数！');
                            }
                        })
                    }],
                backdropDismiss: false
            });
            yield alert.present();
        });
    }
    showMoreActions(matTrack) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            const buttons = [{
                    text: matTrack.isPublish ? '锁定货道' : '解锁货道',
                    cssClass: 'ysw-action-sheet',
                    handler: () => {
                        this.changeLock(matTrack);
                    }
                }, {
                    text: '调整核定数',
                    cssClass: 'ysw-action-sheet',
                    handler: () => {
                        this.changeMaxNumber(matTrack);
                    }
                }, {
                    text: '货道互换',
                    cssClass: 'ysw-action-sheet',
                    handler: () => {
                        this.swapMatTrackGoods(matTrack);
                    }
                }, {
                    text: '清空货道',
                    role: 'destructive',
                    cssClass: 'ysw-action-sheet',
                    handler: () => {
                        this.deleteMatTrackGoods(matTrack);
                    }
                }, {
                    text: '取消',
                    cssClass: 'ysw-action-sheet',
                    role: 'cancel',
                    handler: () => { }
                }];
            const actionSheet = yield this.actionSheetCtrl.create({
                header: matTrack.goodsTrack,
                buttons
            });
            yield actionSheet.present();
        });
    }
    changeLock(matTrack) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            const res = yield this.commonUtils.showConfirm('确认', `确定${matTrack.isPublish ? '锁定' : '解锁'}该货道？`);
            if (res) {
                this.matTrackService.toggleMatTrackLock(this.matId, matTrack.id).then(() => {
                    matTrack.isPublish = !matTrack.isPublish;
                    this.syncTrackLockToMeituan(matTrack);
                });
            }
        });
    }
    syncTrackLockToMeituan(matTrack) {
        if (this.enableMeituan === 1) {
            const syncPayload = {
                matId: this.matId,
                goodsId: matTrack.goodsId,
                type: 3,
                soldOut: matTrack.isPublish ? 1 : 0
            };
            this.meituanService.updateMatGoodsToMeituan(syncPayload);
        }
    }
    changeGoodsPrice(matTrack) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            if (!matTrack.goodsId || !matTrack.goodsName) {
                this.commonUtils.showToast('该货道暂未绑定商品！');
                return;
            }
            const alert = yield this.alertCtrl.create({
                header: matTrack.goodsTrack,
                message: '调整轨道商品价格',
                inputs: [{
                        name: 'price',
                        type: 'number',
                        placeholder: '请输入商品新价格'
                    }],
                buttons: [{
                        text: '取消',
                        role: 'cancel',
                        cssClass: 'secondary',
                        handler: () => { }
                    }, {
                        text: '确认',
                        handler: (data) => tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
                            if (!this.commonUtils.isNullOrEmptyString(data)
                                && !this.commonUtils.isNullOrEmptyString(data.price)) {
                                if (data.price < 0) {
                                    this.commonUtils.showToast('商品价格不能小于零！');
                                    return;
                                }
                                yield this.matTrackService.changeMatTrackGoodsPrice(matTrack.matId, matTrack.id, data.price);
                                this.syncPriceToMeituan(matTrack, data.price);
                                // 刷新页面
                                const loading = this.commonUtils.showLoading('正在修改价格...');
                                this.matTrackList = yield this.loadMatTrackGoodsList();
                                this.commonUtils.hideLoadingSync(loading);
                                this.commonUtils.showToast('修改成功!');
                            }
                            else {
                                this.commonUtils.showToast('请输入商品新价格！');
                            }
                        })
                    }],
                backdropDismiss: false
            });
            yield alert.present();
        });
    }
    syncPriceToMeituan(matTrack, price) {
        if (this.enableMeituan === 1) {
            const syncPayload = {
                matId: this.matId,
                goodsId: matTrack.goodsId,
                type: 1,
                price
            };
            this.meituanService.updateMatGoodsToMeituan(syncPayload);
        }
    }
    swapMatTrackGoods(matTrack) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            const modal = yield this.modalCtrl.create({
                component: _modal_swap_track_goods_swap_track_goods_page__WEBPACK_IMPORTED_MODULE_8__["SwapTrackGoodsPage"],
                componentProps: {
                    sourceTrack: matTrack
                },
                swipeToClose: true
            });
            this.storageUtils.set(_components_index__WEBPACK_IMPORTED_MODULE_4__["ProjectConstant"].STORAGE_KEY_MAT_TRACK_LIST, this.matTrackList);
            yield modal.present();
            const { data } = yield modal.onWillDismiss();
            if (!this.commonUtils.isNull(data)
                && !this.commonUtils.isNull(data.sourceId)
                && !this.commonUtils.isNull(data.targetId)) {
                const loading = this.commonUtils.showLoading('正在交轨道到商品...');
                yield this.matTrackService.swapMatTrackGoods(matTrack.matId, data.sourceId, data.targetId);
                this.commonUtils.hideLoadingSync(loading);
                this.commonUtils.showToast('操作成功！');
                // 刷新页面
                this.matTrackList = yield this.loadMatTrackGoodsList();
            }
        });
    }
    deleteMatTrackGoods(matTrack) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            if (matTrack.goodsName > 0) {
                this.commonUtils.showToast('清空轨道商品前请先清空库存！');
                return;
            }
            const alert = yield this.alertCtrl.create({
                header: '确认',
                message: `是否清空轨道${matTrack.goodsTrack}上的商品？`,
                buttons: [{
                        text: '取消',
                        role: 'cancel',
                        cssClass: 'secondary',
                        handler: () => { }
                    }, {
                        text: '确认',
                        handler: () => tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
                            yield this.matTrackService.deleteMatTrackGoods(matTrack.matId, matTrack.id);
                            // 刷新页面
                            this.matTrackList = yield this.loadMatTrackGoodsList();
                        })
                    }],
                backdropDismiss: false
            });
            yield alert.present();
        });
    }
    imageError(event) {
        event.target.src = 'assets/imgs/mat/goods-no-image.svg';
    }
    openMatTrack(matTrack) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            if (yield this.commonUtils.showConfirm('温馨提示', '确定要打开：' + matTrack.goodsTrack + '号格子？')) {
                const data = yield this.matCabService.openMatTrack(this.matId, matTrack.trackCode);
                if (data.success) {
                    this.commonUtils.showToast('打开成功！');
                }
                else {
                    this.commonUtils.showToast(data.message);
                }
            }
        });
    }
};
MatTrackPage.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"] },
    { type: _components_index__WEBPACK_IMPORTED_MODULE_4__["CommonUtils"] },
    { type: _components_index__WEBPACK_IMPORTED_MODULE_4__["StorageUtils"] },
    { type: _service_index__WEBPACK_IMPORTED_MODULE_5__["MatService"] },
    { type: _service_index__WEBPACK_IMPORTED_MODULE_5__["MatTrackService"] },
    { type: _service_index__WEBPACK_IMPORTED_MODULE_5__["MeituanService"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["AlertController"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["ModalController"] },
    { type: _service_mat_cab_service__WEBPACK_IMPORTED_MODULE_9__["MatCabService"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["ActionSheetController"] }
];
MatTrackPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-mat-track',
        template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./mat-track.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/mat-track/mat-track.page.html")).default,
        providers: [_service_index__WEBPACK_IMPORTED_MODULE_5__["MatService"], _service_index__WEBPACK_IMPORTED_MODULE_5__["MatTrackService"], _service_index__WEBPACK_IMPORTED_MODULE_5__["MeituanService"], _service_mat_cab_service__WEBPACK_IMPORTED_MODULE_9__["MatCabService"]],
        styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./mat-track.page.scss */ "./src/app/pages/mat-track/mat-track.page.scss")).default]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"],
        _components_index__WEBPACK_IMPORTED_MODULE_4__["CommonUtils"],
        _components_index__WEBPACK_IMPORTED_MODULE_4__["StorageUtils"],
        _service_index__WEBPACK_IMPORTED_MODULE_5__["MatService"],
        _service_index__WEBPACK_IMPORTED_MODULE_5__["MatTrackService"],
        _service_index__WEBPACK_IMPORTED_MODULE_5__["MeituanService"],
        _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"],
        _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["AlertController"],
        _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["ModalController"],
        _service_mat_cab_service__WEBPACK_IMPORTED_MODULE_9__["MatCabService"],
        _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["ActionSheetController"]])
], MatTrackPage);



/***/ })

}]);
//# sourceMappingURL=mat-track-mat-track-module-es2015.js.map