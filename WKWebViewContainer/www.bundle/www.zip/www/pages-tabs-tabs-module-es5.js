function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-tabs-tabs-module"], {
  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/tabs/tabs.page.html":
  /*!*********************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/tabs/tabs.page.html ***!
    \*********************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppPagesTabsTabsPageHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-tabs>\n  <ion-tab-bar slot=\"bottom\" yswShowHideTabs>\n    <ion-tab-button tab=\"home\">\n      <ion-icon name=\"home\" size=\"small\"></ion-icon>\n      <ion-label>首页</ion-label>\n    </ion-tab-button>\n    <ion-tab-button tab=\"mat\">\n      <ion-icon name=\"newspaper\" size=\"small\"></ion-icon>\n      <ion-label>售药机</ion-label>\n    </ion-tab-button>\n    <ion-tab-button tab=\"profile\">\n      <ion-icon name=\"person\" size=\"small\"></ion-icon>\n      <ion-label>我的</ion-label>\n    </ion-tab-button>\n  </ion-tab-bar>\n</ion-tabs>";
    /***/
  },

  /***/
  "./src/app/pages/tabs/tabs-routing.module.ts":
  /*!***************************************************!*\
    !*** ./src/app/pages/tabs/tabs-routing.module.ts ***!
    \***************************************************/

  /*! exports provided: TabsPageRoutingModule */

  /***/
  function srcAppPagesTabsTabsRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "TabsPageRoutingModule", function () {
      return TabsPageRoutingModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");
    /* harmony import */


    var _tabs_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./tabs.page */
    "./src/app/pages/tabs/tabs.page.ts");
    /* harmony import */


    var _guard_login_guard_guard__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! ../../guard/login-guard.guard */
    "./src/app/guard/login-guard.guard.ts");

    var routes = [{
      path: 'tabs',
      component: _tabs_page__WEBPACK_IMPORTED_MODULE_3__["TabsPage"],
      children: [{
        path: 'home',
        children: [{
          path: '',
          loadChildren: function loadChildren() {
            return __webpack_require__.e(
            /*! import() | home-home-module */
            "home-home-module").then(__webpack_require__.bind(null,
            /*! ../home/home.module */
            "./src/app/pages/home/home.module.ts")).then(function (m) {
              return m.HomePageModule;
            });
          },
          canActivate: [_guard_login_guard_guard__WEBPACK_IMPORTED_MODULE_4__["LoginGuardGuard"]]
        }, {
          path: 'order',
          loadChildren: function loadChildren() {
            return Promise.all(
            /*! import() | order-list-order-list-module */
            [__webpack_require__.e("default~order-detail-order-detail-module~order-list-order-list-module"), __webpack_require__.e("order-list-order-list-module")]).then(__webpack_require__.bind(null,
            /*! ../order-list/order-list.module */
            "./src/app/pages/order-list/order-list.module.ts")).then(function (m) {
              return m.OrderListPageModule;
            });
          },
          canActivate: [_guard_login_guard_guard__WEBPACK_IMPORTED_MODULE_4__["LoginGuardGuard"]]
        }, {
          path: 'supply',
          loadChildren: function loadChildren() {
            return __webpack_require__.e(
            /*! import() | supply-list-supply-list-module */
            "supply-list-supply-list-module").then(__webpack_require__.bind(null,
            /*! ../supply-list/supply-list.module */
            "./src/app/pages/supply-list/supply-list.module.ts")).then(function (m) {
              return m.SupplyListPageModule;
            });
          },
          canActivate: [_guard_login_guard_guard__WEBPACK_IMPORTED_MODULE_4__["LoginGuardGuard"]]
        }, {
          path: 'ticket',
          loadChildren: function loadChildren() {
            return __webpack_require__.e(
            /*! import() | ticket-list-ticket-list-module */
            "ticket-list-ticket-list-module").then(__webpack_require__.bind(null,
            /*! ../ticket-list/ticket-list.module */
            "./src/app/pages/ticket-list/ticket-list.module.ts")).then(function (m) {
              return m.TicketListPageModule;
            });
          },
          canActivate: [_guard_login_guard_guard__WEBPACK_IMPORTED_MODULE_4__["LoginGuardGuard"]]
        }, {
          path: 'questions',
          loadChildren: function loadChildren() {
            return __webpack_require__.e(
            /*! import() | questions-questions-module */
            "questions-questions-module").then(__webpack_require__.bind(null,
            /*! ../questions/questions.module */
            "./src/app/pages/questions/questions.module.ts")).then(function (m) {
              return m.QuestionsPageModule;
            });
          },
          canActivate: [_guard_login_guard_guard__WEBPACK_IMPORTED_MODULE_4__["LoginGuardGuard"]]
        }, {
          path: 'mat/track/alert',
          loadChildren: function loadChildren() {
            return __webpack_require__.e(
            /*! import() | mat-track-alert-mat-track-alert-module */
            "mat-track-alert-mat-track-alert-module").then(__webpack_require__.bind(null,
            /*! ../mat-track-alert/mat-track-alert.module */
            "./src/app/pages/mat-track-alert/mat-track-alert.module.ts")).then(function (m) {
              return m.MatTrackAlertPageModule;
            });
          },
          canActivate: [_guard_login_guard_guard__WEBPACK_IMPORTED_MODULE_4__["LoginGuardGuard"]]
        }, {
          path: 'mat/th/alert',
          loadChildren: function loadChildren() {
            return __webpack_require__.e(
            /*! import() | mat-th-alert-mat-th-alert-module */
            "mat-th-alert-mat-th-alert-module").then(__webpack_require__.bind(null,
            /*! ../mat-th-alert/mat-th-alert.module */
            "./src/app/pages/mat-th-alert/mat-th-alert.module.ts")).then(function (m) {
              return m.MatThAlertPageModule;
            });
          },
          canActivate: [_guard_login_guard_guard__WEBPACK_IMPORTED_MODULE_4__["LoginGuardGuard"]]
        }, {
          path: 'goods/price/alert',
          loadChildren: function loadChildren() {
            return __webpack_require__.e(
            /*! import() | goods-price-alert-goods-price-alert-module */
            "goods-price-alert-goods-price-alert-module").then(__webpack_require__.bind(null,
            /*! ../goods-price-alert/goods-price-alert.module */
            "./src/app/pages/goods-price-alert/goods-price-alert.module.ts")).then(function (m) {
              return m.GoodsPriceAlertPageModule;
            });
          },
          canActivate: [_guard_login_guard_guard__WEBPACK_IMPORTED_MODULE_4__["LoginGuardGuard"]]
        }, {
          path: 'goods/expire/alert',
          loadChildren: function loadChildren() {
            return __webpack_require__.e(
            /*! import() | goods-expire-alert-goods-expire-alert-module */
            "goods-expire-alert-goods-expire-alert-module").then(__webpack_require__.bind(null,
            /*! ../goods-expire-alert/goods-expire-alert.module */
            "./src/app/pages/goods-expire-alert/goods-expire-alert.module.ts")).then(function (m) {
              return m.GoodsExpireAlertPageModule;
            });
          },
          canActivate: [_guard_login_guard_guard__WEBPACK_IMPORTED_MODULE_4__["LoginGuardGuard"]]
        }, {
          path: 'goods/storage/alert',
          loadChildren: function loadChildren() {
            return __webpack_require__.e(
            /*! import() | goods-storage-alert-goods-storage-alert-module */
            "goods-storage-alert-goods-storage-alert-module").then(__webpack_require__.bind(null,
            /*! ../goods-storage-alert/goods-storage-alert.module */
            "./src/app/pages/goods-storage-alert/goods-storage-alert.module.ts")).then(function (m) {
              return m.GoodsStorageAlertPageModule;
            });
          },
          canActivate: [_guard_login_guard_guard__WEBPACK_IMPORTED_MODULE_4__["LoginGuardGuard"]]
        }, {
          path: 'goods/storage/alert',
          loadChildren: function loadChildren() {
            return __webpack_require__.e(
            /*! import() | goods-storage-alert-goods-storage-alert-module */
            "goods-storage-alert-goods-storage-alert-module").then(__webpack_require__.bind(null,
            /*! ../goods-storage-alert/goods-storage-alert.module */
            "./src/app/pages/goods-storage-alert/goods-storage-alert.module.ts")).then(function (m) {
              return m.GoodsStorageAlertPageModule;
            });
          },
          canActivate: [_guard_login_guard_guard__WEBPACK_IMPORTED_MODULE_4__["LoginGuardGuard"]]
        }, {
          path: 'mat/network/alert',
          loadChildren: function loadChildren() {
            return __webpack_require__.e(
            /*! import() | mat-mat-module */
            "mat-mat-module").then(__webpack_require__.bind(null,
            /*! ../mat/mat.module */
            "./src/app/pages/mat/mat.module.ts")).then(function (m) {
              return m.MatPageModule;
            });
          },
          canActivate: [_guard_login_guard_guard__WEBPACK_IMPORTED_MODULE_4__["LoginGuardGuard"]]
        }, {
          path: 'mat/track',
          loadChildren: function loadChildren() {
            return Promise.all(
            /*! import() | mat-track-mat-track-module */
            [__webpack_require__.e("common"), __webpack_require__.e("mat-track-mat-track-module")]).then(__webpack_require__.bind(null,
            /*! ../mat-track/mat-track.module */
            "./src/app/pages/mat-track/mat-track.module.ts")).then(function (m) {
              return m.MatTrackPageModule;
            });
          }
        }]
      }, {
        path: 'mat',
        children: [{
          path: '',
          loadChildren: function loadChildren() {
            return __webpack_require__.e(
            /*! import() | mat-mat-module */
            "mat-mat-module").then(__webpack_require__.bind(null,
            /*! ../mat/mat.module */
            "./src/app/pages/mat/mat.module.ts")).then(function (m) {
              return m.MatPageModule;
            });
          },
          canActivate: [_guard_login_guard_guard__WEBPACK_IMPORTED_MODULE_4__["LoginGuardGuard"]]
        }, {
          path: 'track',
          loadChildren: function loadChildren() {
            return Promise.all(
            /*! import() | mat-track-mat-track-module */
            [__webpack_require__.e("common"), __webpack_require__.e("mat-track-mat-track-module")]).then(__webpack_require__.bind(null,
            /*! ../mat-track/mat-track.module */
            "./src/app/pages/mat-track/mat-track.module.ts")).then(function (m) {
              return m.MatTrackPageModule;
            });
          }
        }, {
          path: 'cab',
          loadChildren: function loadChildren() {
            return Promise.all(
            /*! import() | mat-cab-list-mat-cab-list-module */
            [__webpack_require__.e("common"), __webpack_require__.e("mat-cab-list-mat-cab-list-module")]).then(__webpack_require__.bind(null,
            /*! ../mat-cab-list/mat-cab-list.module */
            "./src/app/pages/mat-cab-list/mat-cab-list.module.ts")).then(function (m) {
              return m.MatCabListPageModule;
            });
          }
        }]
      }, {
        path: 'profile',
        children: [{
          path: '',
          loadChildren: function loadChildren() {
            return __webpack_require__.e(
            /*! import() | profile-profile-module */
            "profile-profile-module").then(__webpack_require__.bind(null,
            /*! ../profile/profile.module */
            "./src/app/pages/profile/profile.module.ts")).then(function (m) {
              return m.ProfilePageModule;
            });
          },
          canActivate: [_guard_login_guard_guard__WEBPACK_IMPORTED_MODULE_4__["LoginGuardGuard"]]
        }, {
          path: 'order',
          loadChildren: function loadChildren() {
            return Promise.all(
            /*! import() | order-list-order-list-module */
            [__webpack_require__.e("default~order-detail-order-detail-module~order-list-order-list-module"), __webpack_require__.e("order-list-order-list-module")]).then(__webpack_require__.bind(null,
            /*! ../order-list/order-list.module */
            "./src/app/pages/order-list/order-list.module.ts")).then(function (m) {
              return m.OrderListPageModule;
            });
          },
          canActivate: [_guard_login_guard_guard__WEBPACK_IMPORTED_MODULE_4__["LoginGuardGuard"]]
        }, {
          path: 'supply',
          loadChildren: function loadChildren() {
            return __webpack_require__.e(
            /*! import() | supply-list-supply-list-module */
            "supply-list-supply-list-module").then(__webpack_require__.bind(null,
            /*! ../supply-list/supply-list.module */
            "./src/app/pages/supply-list/supply-list.module.ts")).then(function (m) {
              return m.SupplyListPageModule;
            });
          },
          canActivate: [_guard_login_guard_guard__WEBPACK_IMPORTED_MODULE_4__["LoginGuardGuard"]]
        }, {
          path: 'ticket',
          loadChildren: function loadChildren() {
            return __webpack_require__.e(
            /*! import() | ticket-list-ticket-list-module */
            "ticket-list-ticket-list-module").then(__webpack_require__.bind(null,
            /*! ../ticket-list/ticket-list.module */
            "./src/app/pages/ticket-list/ticket-list.module.ts")).then(function (m) {
              return m.TicketListPageModule;
            });
          },
          canActivate: [_guard_login_guard_guard__WEBPACK_IMPORTED_MODULE_4__["LoginGuardGuard"]]
        }]
      }, {
        path: 'goods',
        children: [{
          path: '',
          loadChildren: function loadChildren() {
            return __webpack_require__.e(
            /*! import() | goods-detail-goods-detail-module */
            "goods-detail-goods-detail-module").then(__webpack_require__.bind(null,
            /*! ../goods-detail/goods-detail.module */
            "./src/app/pages/goods-detail/goods-detail.module.ts")).then(function (m) {
              return m.GoodsDetailPageModule;
            });
          }
        }]
      }, {
        path: 'push/order',
        children: [{
          path: '',
          loadChildren: function loadChildren() {
            return Promise.all(
            /*! import() | order-list-order-list-module */
            [__webpack_require__.e("default~order-detail-order-detail-module~order-list-order-list-module"), __webpack_require__.e("order-list-order-list-module")]).then(__webpack_require__.bind(null,
            /*! ../order-list/order-list.module */
            "./src/app/pages/order-list/order-list.module.ts")).then(function (m) {
              return m.OrderListPageModule;
            });
          },
          canActivate: [_guard_login_guard_guard__WEBPACK_IMPORTED_MODULE_4__["LoginGuardGuard"]]
        }, {
          path: 'detail',
          loadChildren: function loadChildren() {
            return Promise.all(
            /*! import() | order-detail-order-detail-module */
            [__webpack_require__.e("default~order-detail-order-detail-module~order-list-order-list-module"), __webpack_require__.e("order-detail-order-detail-module")]).then(__webpack_require__.bind(null,
            /*! ../order-detail/order-detail.module */
            "./src/app/pages/order-detail/order-detail.module.ts")).then(function (m) {
              return m.OrderDetailPageModule;
            });
          },
          canActivate: [_guard_login_guard_guard__WEBPACK_IMPORTED_MODULE_4__["LoginGuardGuard"]]
        }]
      }, {
        path: '',
        redirectTo: '/tabs/home',
        pathMatch: 'full'
      }]
    }, {
      path: '',
      redirectTo: '/tabs/home',
      pathMatch: 'full'
    }];

    var TabsPageRoutingModule = function TabsPageRoutingModule() {
      _classCallCheck(this, TabsPageRoutingModule);
    };

    TabsPageRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
      exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })], TabsPageRoutingModule);
    /***/
  },

  /***/
  "./src/app/pages/tabs/tabs.module.ts":
  /*!*******************************************!*\
    !*** ./src/app/pages/tabs/tabs.module.ts ***!
    \*******************************************/

  /*! exports provided: TabsPageModule */

  /***/
  function srcAppPagesTabsTabsModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "TabsPageModule", function () {
      return TabsPageModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/fesm2015/common.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/fesm2015/forms.js");
    /* harmony import */


    var _tabs_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ./tabs-routing.module */
    "./src/app/pages/tabs/tabs-routing.module.ts");
    /* harmony import */


    var _tabs_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ./tabs.page */
    "./src/app/pages/tabs/tabs.page.ts");
    /* harmony import */


    var _module_index__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
    /*! ../module/index */
    "./src/app/pages/module/index.ts"); // import { ShowHideTabsDirective } from '../../components/index';


    var TabsPageModule = function TabsPageModule() {
      _classCallCheck(this, TabsPageModule);
    };

    TabsPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["NgModule"])({
      imports: [_ionic_angular__WEBPACK_IMPORTED_MODULE_1__["IonicModule"], _angular_common__WEBPACK_IMPORTED_MODULE_3__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormsModule"], _tabs_routing_module__WEBPACK_IMPORTED_MODULE_5__["TabsPageRoutingModule"], _module_index__WEBPACK_IMPORTED_MODULE_7__["ShowHideTabsModule"]],
      declarations: [_tabs_page__WEBPACK_IMPORTED_MODULE_6__["TabsPage"]]
    })], TabsPageModule);
    /***/
  },

  /***/
  "./src/app/pages/tabs/tabs.page.scss":
  /*!*******************************************!*\
    !*** ./src/app/pages/tabs/tabs.page.scss ***!
    \*******************************************/

  /*! exports provided: default */

  /***/
  function srcAppPagesTabsTabsPageScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3BhZ2VzL3RhYnMvdGFicy5wYWdlLnNjc3MifQ== */";
    /***/
  },

  /***/
  "./src/app/pages/tabs/tabs.page.ts":
  /*!*****************************************!*\
    !*** ./src/app/pages/tabs/tabs.page.ts ***!
    \*****************************************/

  /*! exports provided: TabsPage */

  /***/
  function srcAppPagesTabsTabsPageTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "TabsPage", function () {
      return TabsPage;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
    /* harmony import */


    var _components_index__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ../../components/index */
    "./src/app/components/index.ts");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");
    /* harmony import */


    var _jiguang_ionic_jpush_ngx__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! @jiguang-ionic/jpush/ngx */
    "./node_modules/@jiguang-ionic/jpush/ngx/index.js");
    /* harmony import */


    var _environments_environment__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ../../../environments/environment */
    "./src/environments/environment.ts");

    var TabsPage = /*#__PURE__*/function () {
      function TabsPage(platform, storageUtils, commonUtils, nativeUtils, router, activeRoute, jPush) {
        _classCallCheck(this, TabsPage);

        this.platform = platform;
        this.storageUtils = storageUtils;
        this.commonUtils = commonUtils;
        this.nativeUtils = nativeUtils;
        this.router = router;
        this.activeRoute = activeRoute;
        this.jPush = jPush;
      }

      _createClass(TabsPage, [{
        key: "ngOnInit",
        value: function ngOnInit() {
          var _this = this;

          this.storageUtils.set(_components_index__WEBPACK_IMPORTED_MODULE_3__["ProjectConstant"].STORAGE_KEY_ALERT_SETTINGS, {
            price: 1.00,
            storage: 3,
            expire: 6
          });

          if (this.platform.is('hybrid')) {
            if (_environments_environment__WEBPACK_IMPORTED_MODULE_6__["environment"].production) {
              this.jPush.setDebugMode(false);
            } else {
              this.jPush.setDebugMode(true);
            }

            this.jPush.init();
            var userInfo = this.storageUtils.get(_components_index__WEBPACK_IMPORTED_MODULE_3__["ProjectConstant"].STORAGE_KEY_USERINFO);

            if (!this.commonUtils.isNull(userInfo) && !this.commonUtils.isNullOrEmptyString(userInfo.token)) {
              this.jPush.setAlias({
                sequence: 1,
                alias: userInfo.userAccount
              }).then(function (data) {
                console.log('注册Alias成功：' + JSON.stringify(data));
              }).catch(function (err) {
                console.log('注册Alias失败：' + JSON.stringify(err));
              });
            }

            var handleReceiveRegistrationId = function handleReceiveRegistrationId(event) {
              console.log('RegistrationId：' + event.registrationId);
            };

            document.addEventListener('jpush.receiveRegistrationId', handleReceiveRegistrationId, false);

            var haneldOpenNotification = function haneldOpenNotification(event) {
              if (!_this.commonUtils.isNull(userInfo) && !_this.commonUtils.isNullOrEmptyString(userInfo.token)) {
                _this.handleNotificationClick(event);
              }
            };

            document.addEventListener('jpush.openNotification', haneldOpenNotification, false);
          }
        }
      }, {
        key: "handleNotificationClick",
        value: function handleNotificationClick(event) {
          if (this.platform.is('android')) {
            console.log('Tab page: android');
            console.log(event);
            var extras = event.extras;
            console.log(extras); // Meituan Order

            if (extras.pushType === _components_index__WEBPACK_IMPORTED_MODULE_3__["ProjectConstant"].MEITUAN_MAT_ORDER) {
              console.log('Meituan Order');
              console.log('extras.value=' + extras.value);
              console.log('Base64.encode(JSON.stringify(extras.value))=' + Base64.encode(JSON.stringify(extras.value)));
              this.router.navigate(['push/order/detail'], {
                relativeTo: this.activeRoute,
                queryParams: {
                  orderId: Base64.encode(JSON.stringify(extras.value))
                }
              });
              console.log('After navigate');
            }
          } else if (this.platform.is('ios')) {
            console.log(event);
            var _extras = event.extras;

            if (_extras.pushType === _components_index__WEBPACK_IMPORTED_MODULE_3__["ProjectConstant"].REQUEST_PUSH_CODE) {
              this.nativeUtils.copyToClipboard(_extras.value, '');
            } else if (_extras.pushType === _components_index__WEBPACK_IMPORTED_MODULE_3__["ProjectConstant"].MEITUAN_MAT_ORDER) {
              this.router.navigate(['push/order/detail'], {
                relativeTo: this.activeRoute,
                queryParams: {
                  orderId: Base64.encode(JSON.stringify(_extras.value))
                }
              });
            }
          }
        }
      }]);

      return TabsPage;
    }();

    TabsPage.ctorParameters = function () {
      return [{
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["Platform"]
      }, {
        type: _components_index__WEBPACK_IMPORTED_MODULE_3__["StorageUtils"]
      }, {
        type: _components_index__WEBPACK_IMPORTED_MODULE_3__["CommonUtils"]
      }, {
        type: _components_index__WEBPACK_IMPORTED_MODULE_3__["NativeUtils"]
      }, {
        type: _angular_router__WEBPACK_IMPORTED_MODULE_4__["Router"]
      }, {
        type: _angular_router__WEBPACK_IMPORTED_MODULE_4__["ActivatedRoute"]
      }, {
        type: _jiguang_ionic_jpush_ngx__WEBPACK_IMPORTED_MODULE_5__["JPush"]
      }];
    };

    TabsPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-tabs',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./tabs.page.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/tabs/tabs.page.html")).default,
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./tabs.page.scss */
      "./src/app/pages/tabs/tabs.page.scss")).default]
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_2__["Platform"], _components_index__WEBPACK_IMPORTED_MODULE_3__["StorageUtils"], _components_index__WEBPACK_IMPORTED_MODULE_3__["CommonUtils"], _components_index__WEBPACK_IMPORTED_MODULE_3__["NativeUtils"], _angular_router__WEBPACK_IMPORTED_MODULE_4__["Router"], _angular_router__WEBPACK_IMPORTED_MODULE_4__["ActivatedRoute"], _jiguang_ionic_jpush_ngx__WEBPACK_IMPORTED_MODULE_5__["JPush"]])], TabsPage);
    /***/
  }
}]);
//# sourceMappingURL=pages-tabs-tabs-module-es5.js.map