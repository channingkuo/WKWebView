(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["profile-profile-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/profile/profile.page.html":
/*!***************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/profile/profile.page.html ***!
  \***************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\n  <ion-toolbar color=\"ysw\">\n    <ion-title></ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content [forceOverscroll]=\"true\">\n  <div class=\"profile-header-content\">\n    <div class=\"profile-pane flex ion-justify-content-between ion-align-items-center flex-column\">\n      <ion-avatar *ngIf=\"userInfo.avatar;else noAvatar\">\n        <img [src]=\"userInfo.avatar\">\n      </ion-avatar>\n      <ng-template #noAvatar>\n        <div class=\"no-avatar flex ion-justify-content-center ion-align-items-center\">\n          {{userInfo.userName.substring(0, 1)}}</div>\n      </ng-template>\n      <ion-label>{{userInfo.userName}}</ion-label>\n    </div>\n  </div>\n\n  <ion-list class=\"profile-list\">\n    <ion-item button detail lines=\"none\" (click)=\"openSettingsView({title: '价格阀值', type: 'price'})\">\n      <ion-label slot=\"start\">价格阀值</ion-label>\n      <ion-label slot=\"end\">{{alertSettings.price | currency: '￥'}}</ion-label>\n    </ion-item>\n\n    <ion-item button detail lines=\"none\" (click)=\"openSettingsView({title: '库存阀值', type: 'storage'})\">\n      <ion-label slot=\"start\">库存阀值</ion-label>\n      <ion-label slot=\"end\">{{alertSettings.storage}}个</ion-label>\n    </ion-item>\n\n    <ion-item button detail lines=\"none\" (click)=\"openSettingsView({title: '效期阀值', type: 'expire'})\">\n      <ion-label slot=\"start\">效期阀值</ion-label>\n      <ion-label slot=\"end\">{{alertSettings.expire}}个月</ion-label>\n    </ion-item>\n  </ion-list>\n\n  <ion-list class=\"profile-quick-link\" style=\"margin-top: 15px;\">\n    <ion-item button detail lines=\"none\" (click)=\"viewOrderList()\">\n      <ion-label>订单</ion-label>\n    </ion-item>\n\n    <ion-item button detail lines=\"none\" (click)=\"viewSupplyList()\">\n      <ion-label>补货单</ion-label>\n    </ion-item>\n\n    <ion-item button detail lines=\"none\" (click)=\"viewTicketList()\">\n      <ion-label>工单</ion-label>\n    </ion-item>\n  </ion-list>\n\n  <ion-list *ngIf=\"!isIOS\" class=\"profile-list\" style=\"margin-top: 15px;\">\n    <ion-item button detail lines=\"none\" (click)=\"checkVersion()\">\n      <ion-label slot=\"start\">当前版本：{{version}}</ion-label>\n      <ion-label slot=\"end\" style>\n        检查更新\n      </ion-label>\n    </ion-item>\n  </ion-list>\n\n  <ion-button (click)=\"logout()\" expand=\"full\" fill=\"outline\" color=\"medium\">注  销</ion-button>\n</ion-content>");

/***/ }),

/***/ "./src/app/pages/profile/profile.module.ts":
/*!*************************************************!*\
  !*** ./src/app/pages/profile/profile.module.ts ***!
  \*************************************************/
/*! exports provided: ProfilePageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ProfilePageModule", function() { return ProfilePageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm2015/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _profile_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./profile.page */ "./src/app/pages/profile/profile.page.ts");







let ProfilePageModule = class ProfilePageModule {
};
ProfilePageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["NgModule"])({
        imports: [
            _ionic_angular__WEBPACK_IMPORTED_MODULE_1__["IonicModule"],
            _angular_common__WEBPACK_IMPORTED_MODULE_3__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormsModule"],
            _angular_router__WEBPACK_IMPORTED_MODULE_5__["RouterModule"].forChild([
                {
                    path: '',
                    component: _profile_page__WEBPACK_IMPORTED_MODULE_6__["ProfilePage"]
                }
            ])
        ],
        declarations: [_profile_page__WEBPACK_IMPORTED_MODULE_6__["ProfilePage"]]
    })
], ProfilePageModule);



/***/ }),

/***/ "./src/app/pages/profile/profile.page.scss":
/*!*************************************************!*\
  !*** ./src/app/pages/profile/profile.page.scss ***!
  \*************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".profile-header-content {\n  height: 140px;\n  width: 100%;\n  background: -webkit-gradient(linear, left top, left bottom, from(var(--ion-color-ysw)), to(var(--ion-color-ysw-content)));\n  background: linear-gradient(var(--ion-color-ysw), var(--ion-color-ysw-content));\n}\n\nion-content {\n  --background: var(--ion-color-ysw-content-view);\n}\n\n.no-avatar {\n  width: 60px;\n  height: 60px;\n  border-radius: 50%;\n  background-color: var(--ion-color-medium-contrast);\n  color: var(--ion-color-medium);\n  font-weight: 700;\n  font-size: 1.6em;\n}\n\n.profile-pane ion-label {\n  margin-top: 10px;\n  font-size: 1.2em;\n  color: var(--ion-color-dark);\n  font-weight: 700;\n}\n\n.profile-list ion-label[slot=start] {\n  color: var(--ion-color-dark-tint);\n}\n\n.profile-list ion-label[slot=end] {\n  text-align: right;\n  color: var(--ion-color-medium);\n  font-size: 12px;\n}\n\n.profile-quick-link ion-label {\n  color: var(--ion-color-dark-tint);\n}\n\nion-button {\n  margin-top: 40px;\n  height: 40px;\n}\n\nion-list ion-label {\n  font-size: 14px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Vc2Vycy9jaGFubmluZy9EZXNrdG9wL3lzdy1hcHAtc2VydmljZTQvc3JjL2FwcC9wYWdlcy9wcm9maWxlL3Byb2ZpbGUucGFnZS5zY3NzIiwic3JjL2FwcC9wYWdlcy9wcm9maWxlL3Byb2ZpbGUucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0UsYUFBQTtFQUNBLFdBQUE7RUFDQSx5SEFBQTtFQUFBLCtFQUFBO0FDQ0Y7O0FEQ0E7RUFDRSwrQ0FBQTtBQ0VGOztBREFBO0VBQ0UsV0FBQTtFQUNBLFlBQUE7RUFDQSxrQkFBQTtFQUNBLGtEQUFBO0VBQ0EsOEJBQUE7RUFDQSxnQkFBQTtFQUNBLGdCQUFBO0FDR0Y7O0FEREE7RUFDRSxnQkFBQTtFQUNBLGdCQUFBO0VBQ0EsNEJBQUE7RUFDQSxnQkFBQTtBQ0lGOztBREZBO0VBQ0UsaUNBQUE7QUNLRjs7QURIQTtFQUNFLGlCQUFBO0VBQ0EsOEJBQUE7RUFDQSxlQUFBO0FDTUY7O0FESkE7RUFDRSxpQ0FBQTtBQ09GOztBRExBO0VBQ0UsZ0JBQUE7RUFDQSxZQUFBO0FDUUY7O0FETkE7RUFDRSxlQUFBO0FDU0YiLCJmaWxlIjoic3JjL2FwcC9wYWdlcy9wcm9maWxlL3Byb2ZpbGUucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLnByb2ZpbGUtaGVhZGVyLWNvbnRlbnQge1xuICBoZWlnaHQ6IDE0MHB4O1xuICB3aWR0aDogMTAwJTtcbiAgYmFja2dyb3VuZDogbGluZWFyLWdyYWRpZW50KHZhcigtLWlvbi1jb2xvci15c3cpLCB2YXIoLS1pb24tY29sb3IteXN3LWNvbnRlbnQpKTtcbn1cbmlvbi1jb250ZW50IHtcbiAgLS1iYWNrZ3JvdW5kOiB2YXIoLS1pb24tY29sb3IteXN3LWNvbnRlbnQtdmlldyk7XG59XG4ubm8tYXZhdGFyIHtcbiAgd2lkdGg6IDYwcHg7XG4gIGhlaWdodDogNjBweDtcbiAgYm9yZGVyLXJhZGl1czogNTAlO1xuICBiYWNrZ3JvdW5kLWNvbG9yOiB2YXIoLS1pb24tY29sb3ItbWVkaXVtLWNvbnRyYXN0KTtcbiAgY29sb3I6IHZhcigtLWlvbi1jb2xvci1tZWRpdW0pO1xuICBmb250LXdlaWdodDogNzAwO1xuICBmb250LXNpemU6IDEuNmVtO1xufVxuLnByb2ZpbGUtcGFuZSBpb24tbGFiZWwge1xuICBtYXJnaW4tdG9wOiAxMHB4O1xuICBmb250LXNpemU6IDEuMmVtO1xuICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLWRhcmspO1xuICBmb250LXdlaWdodDogNzAwO1xufVxuLnByb2ZpbGUtbGlzdCBpb24tbGFiZWxbc2xvdD1cInN0YXJ0XCJdIHtcbiAgY29sb3I6IHZhcigtLWlvbi1jb2xvci1kYXJrLXRpbnQpO1xufVxuLnByb2ZpbGUtbGlzdCBpb24tbGFiZWxbc2xvdD1cImVuZFwiXSB7XG4gIHRleHQtYWxpZ246IHJpZ2h0O1xuICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLW1lZGl1bSk7XG4gIGZvbnQtc2l6ZTogMTJweDtcbn1cbi5wcm9maWxlLXF1aWNrLWxpbmsgaW9uLWxhYmVsIHtcbiAgY29sb3I6IHZhcigtLWlvbi1jb2xvci1kYXJrLXRpbnQpO1xufVxuaW9uLWJ1dHRvbiB7XG4gIG1hcmdpbi10b3A6IDQwcHg7XG4gIGhlaWdodDogNDBweDtcbn1cbmlvbi1saXN0IGlvbi1sYWJlbCB7XG4gIGZvbnQtc2l6ZTogMTRweDtcbn1cbiIsIi5wcm9maWxlLWhlYWRlci1jb250ZW50IHtcbiAgaGVpZ2h0OiAxNDBweDtcbiAgd2lkdGg6IDEwMCU7XG4gIGJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCh2YXIoLS1pb24tY29sb3IteXN3KSwgdmFyKC0taW9uLWNvbG9yLXlzdy1jb250ZW50KSk7XG59XG5cbmlvbi1jb250ZW50IHtcbiAgLS1iYWNrZ3JvdW5kOiB2YXIoLS1pb24tY29sb3IteXN3LWNvbnRlbnQtdmlldyk7XG59XG5cbi5uby1hdmF0YXIge1xuICB3aWR0aDogNjBweDtcbiAgaGVpZ2h0OiA2MHB4O1xuICBib3JkZXItcmFkaXVzOiA1MCU7XG4gIGJhY2tncm91bmQtY29sb3I6IHZhcigtLWlvbi1jb2xvci1tZWRpdW0tY29udHJhc3QpO1xuICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLW1lZGl1bSk7XG4gIGZvbnQtd2VpZ2h0OiA3MDA7XG4gIGZvbnQtc2l6ZTogMS42ZW07XG59XG5cbi5wcm9maWxlLXBhbmUgaW9uLWxhYmVsIHtcbiAgbWFyZ2luLXRvcDogMTBweDtcbiAgZm9udC1zaXplOiAxLjJlbTtcbiAgY29sb3I6IHZhcigtLWlvbi1jb2xvci1kYXJrKTtcbiAgZm9udC13ZWlnaHQ6IDcwMDtcbn1cblxuLnByb2ZpbGUtbGlzdCBpb24tbGFiZWxbc2xvdD1zdGFydF0ge1xuICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLWRhcmstdGludCk7XG59XG5cbi5wcm9maWxlLWxpc3QgaW9uLWxhYmVsW3Nsb3Q9ZW5kXSB7XG4gIHRleHQtYWxpZ246IHJpZ2h0O1xuICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLW1lZGl1bSk7XG4gIGZvbnQtc2l6ZTogMTJweDtcbn1cblxuLnByb2ZpbGUtcXVpY2stbGluayBpb24tbGFiZWwge1xuICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLWRhcmstdGludCk7XG59XG5cbmlvbi1idXR0b24ge1xuICBtYXJnaW4tdG9wOiA0MHB4O1xuICBoZWlnaHQ6IDQwcHg7XG59XG5cbmlvbi1saXN0IGlvbi1sYWJlbCB7XG4gIGZvbnQtc2l6ZTogMTRweDtcbn0iXX0= */");

/***/ }),

/***/ "./src/app/pages/profile/profile.page.ts":
/*!***********************************************!*\
  !*** ./src/app/pages/profile/profile.page.ts ***!
  \***********************************************/
/*! exports provided: ProfilePage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ProfilePage", function() { return ProfilePage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
/* harmony import */ var _components_index__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../components/index */ "./src/app/components/index.ts");
/* harmony import */ var _modal_profile_settings_profile_settings_page__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../modal/profile-settings/profile-settings.page */ "./src/app/pages/modal/profile-settings/profile-settings.page.ts");
/* harmony import */ var _jiguang_ionic_jpush_ngx__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @jiguang-ionic/jpush/ngx */ "./node_modules/@jiguang-ionic/jpush/ngx/index.js");
/* harmony import */ var _service_native_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../service/native.service */ "./src/app/service/native.service.ts");
/* harmony import */ var _ionic_native_app_version_ngx__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ionic-native/app-version/ngx */ "./node_modules/@ionic-native/app-version/ngx/index.js");









let ProfilePage = class ProfilePage {
    constructor(platform, navCtrl, modalCtrl, commonUtils, storageUtils, activeRoute, router, jPush, appVersion, nativeService) {
        this.platform = platform;
        this.navCtrl = navCtrl;
        this.modalCtrl = modalCtrl;
        this.commonUtils = commonUtils;
        this.storageUtils = storageUtils;
        this.activeRoute = activeRoute;
        this.router = router;
        this.jPush = jPush;
        this.appVersion = appVersion;
        this.nativeService = nativeService;
        this.userInfo = {
            userName: ''
        };
        this.alertSettings = {};
        this.version = '';
        this.isIOS = false;
        this.platform.ready().then(() => {
            this.isIOS = this.platform.is('ios');
        });
    }
    ionViewWillEnter() {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            this.userInfo = this.storageUtils.get(_components_index__WEBPACK_IMPORTED_MODULE_4__["ProjectConstant"].STORAGE_KEY_USERINFO);
            this.alertSettings = this.storageUtils.get(_components_index__WEBPACK_IMPORTED_MODULE_4__["ProjectConstant"].STORAGE_KEY_ALERT_SETTINGS);
            this.version = yield this.appVersion.getVersionNumber();
        });
    }
    openSettingsView(filter) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            const modal = yield this.modalCtrl.create({
                component: _modal_profile_settings_profile_settings_page__WEBPACK_IMPORTED_MODULE_5__["ProfileSettingsPage"],
                componentProps: {
                    title: filter.title,
                    type: filter.type
                },
                swipeToClose: true
            });
            yield modal.present();
            const { data } = yield modal.onWillDismiss();
            if (data && data.refresh) {
                this.alertSettings = this.storageUtils.get(_components_index__WEBPACK_IMPORTED_MODULE_4__["ProjectConstant"].STORAGE_KEY_ALERT_SETTINGS);
            }
        });
    }
    viewOrderList() {
        this.router.navigate(['../order/list'], {
            relativeTo: this.activeRoute
        });
    }
    viewSupplyList() {
        this.router.navigate(['../supply/list'], {
            relativeTo: this.activeRoute
        });
    }
    viewTicketList() {
        this.router.navigate(['../ticket/list'], {
            relativeTo: this.activeRoute
        });
    }
    logout() {
        this.commonUtils.showConfirm('注销确认', '是否确认注销当前账号').then(res => {
            if (res) {
                // delete registe jpush alias
                if (this.platform.is('hybrid')) {
                    this.jPush.deleteAlias({ sequence: 1, alias: this.userInfo.userAccount }).then(data => {
                        console.log('删除Alias成功：' + JSON.stringify(data));
                    }).catch(err => {
                        console.log('删除Alias失败：' + JSON.stringify(err));
                    });
                }
                this.storageUtils.remove(_components_index__WEBPACK_IMPORTED_MODULE_4__["ProjectConstant"].STORAGE_KEY_USERINFO);
                this.navCtrl.navigateRoot('/');
            }
        });
    }
    checkVersion() {
        if (this.platform.is('hybrid')) {
            this.nativeService.detectionUpgrade(true);
        }
    }
};
ProfilePage.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["Platform"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["NavController"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["ModalController"] },
    { type: _components_index__WEBPACK_IMPORTED_MODULE_4__["CommonUtils"] },
    { type: _components_index__WEBPACK_IMPORTED_MODULE_4__["StorageUtils"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"] },
    { type: _jiguang_ionic_jpush_ngx__WEBPACK_IMPORTED_MODULE_6__["JPush"] },
    { type: _ionic_native_app_version_ngx__WEBPACK_IMPORTED_MODULE_8__["AppVersion"] },
    { type: _service_native_service__WEBPACK_IMPORTED_MODULE_7__["NativeService"] }
];
ProfilePage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-profile',
        template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./profile.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/profile/profile.page.html")).default,
        styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./profile.page.scss */ "./src/app/pages/profile/profile.page.scss")).default]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_3__["Platform"],
        _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["NavController"],
        _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["ModalController"],
        _components_index__WEBPACK_IMPORTED_MODULE_4__["CommonUtils"],
        _components_index__WEBPACK_IMPORTED_MODULE_4__["StorageUtils"],
        _angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"],
        _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"],
        _jiguang_ionic_jpush_ngx__WEBPACK_IMPORTED_MODULE_6__["JPush"],
        _ionic_native_app_version_ngx__WEBPACK_IMPORTED_MODULE_8__["AppVersion"],
        _service_native_service__WEBPACK_IMPORTED_MODULE_7__["NativeService"]])
], ProfilePage);



/***/ })

}]);
//# sourceMappingURL=profile-profile-module-es2015.js.map