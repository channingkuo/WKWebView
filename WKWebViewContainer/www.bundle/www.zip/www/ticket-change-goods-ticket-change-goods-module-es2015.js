(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["ticket-change-goods-ticket-change-goods-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/ticket-change-goods/ticket-change-goods.page.html":
/*!***************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/ticket-change-goods/ticket-change-goods.page.html ***!
  \***************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\n  <ion-toolbar color=\"ysw\">\n    <ion-buttons slot=\"start\">\n      <ion-back-button></ion-back-button>\n    </ion-buttons>\n    <ion-title>替换商品列表</ion-title>\n    <ion-buttons collapse=\"true\" slot=\"end\" *ngIf=\"status === 0\">\n      <ion-button (click)=\"addChangeGoods()\">\n        <ion-icon name=\"add-outline\"></ion-icon>\n      </ion-button>\n    </ion-buttons>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <ion-header collapse=\"condense\">\n    <ion-toolbar color=\"ysw\">\n      <ion-title size=\"large\">替换商品列表</ion-title>\n      <ion-buttons collapse=\"true\" slot=\"end\" *ngIf=\"status === 0\">\n        <ion-button (click)=\"addChangeGoods()\">\n          <ion-icon name=\"add-outline\"></ion-icon>\n        </ion-button>\n      </ion-buttons>\n    </ion-toolbar>\n  </ion-header>\n\n  <ion-list>\n    <ng-container *ngFor=\"let goods of goodsList;index as i;\">\n      <ion-card>\n        <ion-card-content>\n          <ion-item-sliding>\n            <ion-item lines=\"none\">\n              <ion-label class=\"flex flex-column\" style=\"margin-right: 0;\">\n                <ion-label class=\"flex ion-justify-content-start ion-align-items-start goods-goods\">\n                  <ion-img (ionError)=\"imageError($event)\"\n                    [src]=\"goods.goods_thumb || 'assets/imgs/mat/goods-no-image.svg'\" [alt]=\"goods.goods_name\">\n                  </ion-img>\n                  <div class=\"flex ion-justify-content-center ion-align-items-start flex-column\">\n                    <ion-label class=\"flex ion-text-wrap goods-track\">\n                      货道：{{goods.goods_track}}\n                    </ion-label>\n                    <ion-label class=\"flex ion-text-wrap\">\n                      品牌：{{goods.brand_name}}\n                    </ion-label>\n                    <ion-label class=\"flex ion-text-wrap\">\n                      商品：{{goods.goods_name}}\n                    </ion-label>\n                    <ion-label class=\"flex ion-text-wrap\">\n                      规格：{{goods.goods_package}}\n                    </ion-label>\n                    <ion-label class=\"flex ion-text-wrap\">\n                      厂商：{{goods.mfr_name}}\n                    </ion-label>\n                  </div>\n                </ion-label>\n                <div class=\"flex ion-justify-content-center ion-align-items-center swap-icon\">\n                  <ion-icon name=\"swap-vertical-outline\"></ion-icon>\n                </div>\n                <ng-container *ngIf=\"goods.target_goods_id;else noTargetGoods\">\n                  <ion-label class=\"flex ion-justify-content-start ion-align-items-start goods-goods\">\n                    <ion-img (ionError)=\"imageError($event)\"\n                      [src]=\"goods.target_goods_thumb || 'assets/imgs/mat/goods-no-image.svg'\"\n                      [alt]=\"goods.target_goods_name\"></ion-img>\n                    <div class=\"flex ion-justify-content-center ion-align-items-start flex-column\">\n                      <ion-label class=\"flex ion-text-wrap\">\n                        品牌：{{goods.target_brand_name}}\n                      </ion-label>\n                      <ion-label class=\"flex ion-text-wrap\">\n                        商品：{{goods.target_goods_name}}\n                      </ion-label>\n                      <ion-label class=\"flex ion-text-wrap\">\n                        规格：{{goods.target_goods_package}}\n                      </ion-label>\n                      <ion-label class=\"flex ion-text-wrap\">\n                        厂商：{{goods.target_mfr_name}}\n                      </ion-label>\n                    </div>\n                  </ion-label>\n                </ng-container>\n                <ng-template #noTargetGoods>\n                  <ng-container *ngIf=\"goods.new_goods_name;else addGoods\">\n                    <ion-label class=\"flex flex-column ion-justify-content-center ion-align-items-start\">\n                      <ion-label class=\"flex ion-text-wrap\">\n                        商品名：{{goods.new_goods_brand + ' '}}{{goods.new_goods_name}}\n                      </ion-label>\n                      <ion-label class=\"flex ion-text-wrap\">\n                        规格：{{goods.new_goods_package}}\n                      </ion-label>\n                      <ion-label class=\"flex ion-text-wrap\">\n                        厂商：{{goods.new_goods_mfr}}\n                      </ion-label>\n                    </ion-label>\n                    <ion-label class=\"flex ion-text-wrap\">商品图片：</ion-label>\n                    <ion-label class=\"flex ion-justify-content-start ion-align-items-center ion-wrap\">\n                      <ng-container *ngFor=\"let image of ['', '1', '2']\">\n                        <ion-img class=\"new-goods-img\" (ionError)=\"imageError($event)\"\n                          [src]=\"goods['new_image' + image] || 'assets/imgs/mat/goods-no-image.svg'\"\n                          [alt]=\"goods.new_goods_name\">\n                        </ion-img>\n                      </ng-container>\n                    </ion-label>\n                    <ion-label class=\"comments-label\" *ngIf=\"goods.target_comments\">\n                      {{goods.target_comments}}\n                    </ion-label>\n                  </ng-container>\n                  <ng-template #addGoods>\n                    <div class=\"add-change-goods flex flex-column ion-justify-content-center ion-align-items-center\">\n                      <ion-label>未选择替换商品</ion-label>\n                    </div>\n                  </ng-template>\n                </ng-template>\n              </ion-label>\n            </ion-item>\n\n            <ion-item-options side=\"end\">\n              <ion-item-option color=\"primary\" (click)=\"onEdit(goods, i)\">修改</ion-item-option>\n              <ion-item-option color=\"danger\" (click)=\"onDelete(goods, i)\">删除</ion-item-option>\n            </ion-item-options>\n          </ion-item-sliding>\n        </ion-card-content>\n      </ion-card>\n    </ng-container>\n  </ion-list>\n</ion-content>");

/***/ }),

/***/ "./src/app/pages/ticket-change-goods/ticket-change-goods.module.ts":
/*!*************************************************************************!*\
  !*** ./src/app/pages/ticket-change-goods/ticket-change-goods.module.ts ***!
  \*************************************************************************/
/*! exports provided: TicketChangeGoodsPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TicketChangeGoodsPageModule", function() { return TicketChangeGoodsPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm2015/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
/* harmony import */ var _ticket_change_goods_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./ticket-change-goods.page */ "./src/app/pages/ticket-change-goods/ticket-change-goods.page.ts");
/* harmony import */ var _module_index__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../module/index */ "./src/app/pages/module/index.ts");








let TicketChangeGoodsPageModule = class TicketChangeGoodsPageModule {
};
TicketChangeGoodsPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"],
            _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild([
                {
                    path: '',
                    component: _ticket_change_goods_page__WEBPACK_IMPORTED_MODULE_6__["TicketChangeGoodsPage"]
                }
            ]),
            _module_index__WEBPACK_IMPORTED_MODULE_7__["StopPropagationModule"]
        ],
        declarations: [_ticket_change_goods_page__WEBPACK_IMPORTED_MODULE_6__["TicketChangeGoodsPage"]]
    })
], TicketChangeGoodsPageModule);



/***/ }),

/***/ "./src/app/pages/ticket-change-goods/ticket-change-goods.page.scss":
/*!*************************************************************************!*\
  !*** ./src/app/pages/ticket-change-goods/ticket-change-goods.page.scss ***!
  \*************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("ion-item {\n  --padding-start: 0;\n  --inner-padding-end: 0;\n}\n\nion-item-options {\n  border-bottom-width: 0px !important;\n}\n\nion-img {\n  max-width: 100px;\n  width: 100px;\n  height: 100px;\n}\n\nion-img + div {\n  width: calc(100% - 110px);\n  margin-left: 10px;\n  font-size: 0.95em;\n}\n\n.goods-goods {\n  margin-right: 0px;\n}\n\n.swap-icon {\n  margin: 16px 0;\n}\n\n.swap-icon ion-icon {\n  font-size: 1.6em;\n}\n\n.goods-track {\n  font-size: 0.9em;\n  color: var(--ion-color-dark);\n}\n\n.system-no-goods {\n  text-align: center;\n  padding: 6px;\n  min-height: 60px;\n  line-height: 60px;\n  border: 0.55px dashed var(--ion-color-medium-tint);\n  border-radius: 10px;\n}\n\n.new-goods-img {\n  max-width: 60px;\n  width: 60px;\n  height: 60px;\n  margin-right: 10px;\n  margin-bottom: 10px;\n  flex-shrink: 0;\n  border: 0.55px solid var(--ion-color-light-shade);\n}\n\n.comments-label {\n  margin-top: 10px;\n  text-align: center;\n  padding: 6px;\n  min-height: 30px;\n  line-height: 30px;\n  border: 0.55px dashed var(--ion-color-medium-tint);\n  border-radius: 10px;\n  display: block;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Vc2Vycy9jaGFubmluZy9EZXNrdG9wL3lzdy1hcHAtc2VydmljZTQvc3JjL2FwcC9wYWdlcy90aWNrZXQtY2hhbmdlLWdvb2RzL3RpY2tldC1jaGFuZ2UtZ29vZHMucGFnZS5zY3NzIiwic3JjL2FwcC9wYWdlcy90aWNrZXQtY2hhbmdlLWdvb2RzL3RpY2tldC1jaGFuZ2UtZ29vZHMucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0Usa0JBQUE7RUFDQSxzQkFBQTtBQ0NGOztBRENBO0VBQ0UsbUNBQUE7QUNFRjs7QURBQTtFQUNFLGdCQUFBO0VBQ0EsWUFBQTtFQUNBLGFBQUE7QUNHRjs7QUREQTtFQUNFLHlCQUFBO0VBQ0EsaUJBQUE7RUFDQSxpQkFBQTtBQ0lGOztBREZBO0VBQ0UsaUJBQUE7QUNLRjs7QURIQTtFQUNFLGNBQUE7QUNNRjs7QURKRTtFQUNFLGdCQUFBO0FDTUo7O0FESEE7RUFDRSxnQkFBQTtFQUNBLDRCQUFBO0FDTUY7O0FESkE7RUFDRSxrQkFBQTtFQUNBLFlBQUE7RUFDQSxnQkFBQTtFQUNBLGlCQUFBO0VBQ0Esa0RBQUE7RUFDQSxtQkFBQTtBQ09GOztBRExBO0VBQ0UsZUFBQTtFQUNBLFdBQUE7RUFDQSxZQUFBO0VBQ0Esa0JBQUE7RUFDQSxtQkFBQTtFQUNBLGNBQUE7RUFDQSxpREFBQTtBQ1FGOztBRE5BO0VBQ0UsZ0JBQUE7RUFDQSxrQkFBQTtFQUNBLFlBQUE7RUFDQSxnQkFBQTtFQUNBLGlCQUFBO0VBQ0Esa0RBQUE7RUFDQSxtQkFBQTtFQUNBLGNBQUE7QUNTRiIsImZpbGUiOiJzcmMvYXBwL3BhZ2VzL3RpY2tldC1jaGFuZ2UtZ29vZHMvdGlja2V0LWNoYW5nZS1nb29kcy5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJpb24taXRlbSB7XG4gIC0tcGFkZGluZy1zdGFydDogMDtcbiAgLS1pbm5lci1wYWRkaW5nLWVuZDogMDtcbn1cbmlvbi1pdGVtLW9wdGlvbnMge1xuICBib3JkZXItYm90dG9tLXdpZHRoOiAwcHggIWltcG9ydGFudDtcbn1cbmlvbi1pbWcge1xuICBtYXgtd2lkdGg6IDEwMHB4O1xuICB3aWR0aDogMTAwcHg7XG4gIGhlaWdodDogMTAwcHg7XG59XG5pb24taW1nICsgZGl2IHtcbiAgd2lkdGg6IGNhbGMoMTAwJSAtIDExMHB4KTtcbiAgbWFyZ2luLWxlZnQ6IDEwcHg7XG4gIGZvbnQtc2l6ZTogMC45NWVtO1xufVxuLmdvb2RzLWdvb2RzIHtcbiAgbWFyZ2luLXJpZ2h0OiAwcHg7XG59XG4uc3dhcC1pY29uIHtcbiAgbWFyZ2luOiAxNnB4IDA7XG5cbiAgaW9uLWljb24ge1xuICAgIGZvbnQtc2l6ZTogMS42ZW07XG4gIH1cbn1cbi5nb29kcy10cmFjayB7XG4gIGZvbnQtc2l6ZTogMC45ZW07XG4gIGNvbG9yOiB2YXIoLS1pb24tY29sb3ItZGFyayk7XG59XG4uc3lzdGVtLW5vLWdvb2RzIHtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xuICBwYWRkaW5nOiA2cHg7XG4gIG1pbi1oZWlnaHQ6IDYwcHg7XG4gIGxpbmUtaGVpZ2h0OiA2MHB4O1xuICBib3JkZXI6IDAuNTVweCBkYXNoZWQgdmFyKC0taW9uLWNvbG9yLW1lZGl1bS10aW50KTtcbiAgYm9yZGVyLXJhZGl1czogMTBweDtcbn1cbi5uZXctZ29vZHMtaW1nIHtcbiAgbWF4LXdpZHRoOiA2MHB4O1xuICB3aWR0aDogNjBweDtcbiAgaGVpZ2h0OiA2MHB4O1xuICBtYXJnaW4tcmlnaHQ6IDEwcHg7XG4gIG1hcmdpbi1ib3R0b206IDEwcHg7XG4gIGZsZXgtc2hyaW5rOiAwO1xuICBib3JkZXI6IDAuNTVweCBzb2xpZCB2YXIoLS1pb24tY29sb3ItbGlnaHQtc2hhZGUpO1xufVxuLmNvbW1lbnRzLWxhYmVsIHtcbiAgbWFyZ2luLXRvcDogMTBweDtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xuICBwYWRkaW5nOiA2cHg7XG4gIG1pbi1oZWlnaHQ6IDMwcHg7XG4gIGxpbmUtaGVpZ2h0OiAzMHB4O1xuICBib3JkZXI6IDAuNTVweCBkYXNoZWQgdmFyKC0taW9uLWNvbG9yLW1lZGl1bS10aW50KTtcbiAgYm9yZGVyLXJhZGl1czogMTBweDtcbiAgZGlzcGxheTogYmxvY2s7XG59XG4iLCJpb24taXRlbSB7XG4gIC0tcGFkZGluZy1zdGFydDogMDtcbiAgLS1pbm5lci1wYWRkaW5nLWVuZDogMDtcbn1cblxuaW9uLWl0ZW0tb3B0aW9ucyB7XG4gIGJvcmRlci1ib3R0b20td2lkdGg6IDBweCAhaW1wb3J0YW50O1xufVxuXG5pb24taW1nIHtcbiAgbWF4LXdpZHRoOiAxMDBweDtcbiAgd2lkdGg6IDEwMHB4O1xuICBoZWlnaHQ6IDEwMHB4O1xufVxuXG5pb24taW1nICsgZGl2IHtcbiAgd2lkdGg6IGNhbGMoMTAwJSAtIDExMHB4KTtcbiAgbWFyZ2luLWxlZnQ6IDEwcHg7XG4gIGZvbnQtc2l6ZTogMC45NWVtO1xufVxuXG4uZ29vZHMtZ29vZHMge1xuICBtYXJnaW4tcmlnaHQ6IDBweDtcbn1cblxuLnN3YXAtaWNvbiB7XG4gIG1hcmdpbjogMTZweCAwO1xufVxuLnN3YXAtaWNvbiBpb24taWNvbiB7XG4gIGZvbnQtc2l6ZTogMS42ZW07XG59XG5cbi5nb29kcy10cmFjayB7XG4gIGZvbnQtc2l6ZTogMC45ZW07XG4gIGNvbG9yOiB2YXIoLS1pb24tY29sb3ItZGFyayk7XG59XG5cbi5zeXN0ZW0tbm8tZ29vZHMge1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gIHBhZGRpbmc6IDZweDtcbiAgbWluLWhlaWdodDogNjBweDtcbiAgbGluZS1oZWlnaHQ6IDYwcHg7XG4gIGJvcmRlcjogMC41NXB4IGRhc2hlZCB2YXIoLS1pb24tY29sb3ItbWVkaXVtLXRpbnQpO1xuICBib3JkZXItcmFkaXVzOiAxMHB4O1xufVxuXG4ubmV3LWdvb2RzLWltZyB7XG4gIG1heC13aWR0aDogNjBweDtcbiAgd2lkdGg6IDYwcHg7XG4gIGhlaWdodDogNjBweDtcbiAgbWFyZ2luLXJpZ2h0OiAxMHB4O1xuICBtYXJnaW4tYm90dG9tOiAxMHB4O1xuICBmbGV4LXNocmluazogMDtcbiAgYm9yZGVyOiAwLjU1cHggc29saWQgdmFyKC0taW9uLWNvbG9yLWxpZ2h0LXNoYWRlKTtcbn1cblxuLmNvbW1lbnRzLWxhYmVsIHtcbiAgbWFyZ2luLXRvcDogMTBweDtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xuICBwYWRkaW5nOiA2cHg7XG4gIG1pbi1oZWlnaHQ6IDMwcHg7XG4gIGxpbmUtaGVpZ2h0OiAzMHB4O1xuICBib3JkZXI6IDAuNTVweCBkYXNoZWQgdmFyKC0taW9uLWNvbG9yLW1lZGl1bS10aW50KTtcbiAgYm9yZGVyLXJhZGl1czogMTBweDtcbiAgZGlzcGxheTogYmxvY2s7XG59Il19 */");

/***/ }),

/***/ "./src/app/pages/ticket-change-goods/ticket-change-goods.page.ts":
/*!***********************************************************************!*\
  !*** ./src/app/pages/ticket-change-goods/ticket-change-goods.page.ts ***!
  \***********************************************************************/
/*! exports provided: TicketChangeGoodsPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TicketChangeGoodsPage", function() { return TicketChangeGoodsPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _components_index__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../components/index */ "./src/app/components/index.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
/* harmony import */ var _ticket_list_ticket_list_page__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../ticket-list/ticket-list.page */ "./src/app/pages/ticket-list/ticket-list.page.ts");
/* harmony import */ var _ticket_detail_ticket_detail_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../ticket-detail/ticket-detail.page */ "./src/app/pages/ticket-detail/ticket-detail.page.ts");
/* harmony import */ var _modal_ticket_goods_swap_ticket_goods_swap_page__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../modal/ticket-goods-swap/ticket-goods-swap.page */ "./src/app/pages/modal/ticket-goods-swap/ticket-goods-swap.page.ts");
/* harmony import */ var _service_index__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../service/index */ "./src/app/service/index.ts");









let TicketChangeGoodsPage = class TicketChangeGoodsPage {
    constructor(commonUtils, activeRoute, storageUtils, ticketService, ticketDetailPage, modalCtrl) {
        this.commonUtils = commonUtils;
        this.activeRoute = activeRoute;
        this.storageUtils = storageUtils;
        this.ticketService = ticketService;
        this.ticketDetailPage = ticketDetailPage;
        this.modalCtrl = modalCtrl;
        this.goodsList = [];
        this.activeRoute.queryParams.subscribe((params) => {
            this.matId = params.matId;
            this.status = parseInt(params.status, 10);
        });
        this.goodsList = this.storageUtils.get(_components_index__WEBPACK_IMPORTED_MODULE_2__["ProjectConstant"].STORAGE_KEY_TICKET_GOODS_LIST);
        if (this.goodsList.length > 0) {
            this.ticketId = this.goodsList[0].ticket_id;
        }
        this.userInfo = this.storageUtils.get(_components_index__WEBPACK_IMPORTED_MODULE_2__["ProjectConstant"].STORAGE_KEY_USERINFO);
    }
    ngOnInit() {
    }
    addChangeGoods() {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            const modal = yield this.modalCtrl.create({
                component: _modal_ticket_goods_swap_ticket_goods_swap_page__WEBPACK_IMPORTED_MODULE_7__["TicketGoodsSwapPage"],
                componentProps: {
                    matId: this.matId
                },
                swipeToClose: true
            });
            yield modal.present();
            const { data } = yield modal.onWillDismiss();
            if (!this.commonUtils.isNull(data)) {
                console.log(data);
                if (this.checkHasExchangeGoods(data)) {
                    this.commonUtils.showToast('该商品已经在更换商品列表中...');
                    return;
                }
                const payload = Object.assign({}, data);
                payload.ticket_id = this.ticketId;
                yield this.ticketDetailPage.saveTicketGoods(payload);
                this.goodsList = yield this.ticketDetailPage.loadTicketExChangeGoodsList(this.ticketId);
                this.storageUtils.set(_components_index__WEBPACK_IMPORTED_MODULE_2__["ProjectConstant"].STORAGE_KEY_REFRESH, true);
            }
        });
    }
    onEdit(goods, index) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            if (this.checkCanEdit()) {
                const modal = yield this.modalCtrl.create({
                    component: _modal_ticket_goods_swap_ticket_goods_swap_page__WEBPACK_IMPORTED_MODULE_7__["TicketGoodsSwapPage"],
                    componentProps: {
                        ticketGoods: Object.assign({}, goods),
                        matId: this.matId
                    },
                    swipeToClose: true
                });
                yield modal.present();
                const { data } = yield modal.onWillDismiss();
                if (!this.commonUtils.isNull(data)) {
                    const payload = Object.assign({}, data);
                    yield this.ticketDetailPage.saveTicketGoods(payload);
                    this.goodsList = yield this.ticketDetailPage.loadTicketExChangeGoodsList(this.ticketId);
                    this.storageUtils.set(_components_index__WEBPACK_IMPORTED_MODULE_2__["ProjectConstant"].STORAGE_KEY_REFRESH, true);
                }
            }
            else {
                this.commonUtils.showToast('当前状态不可修改！');
            }
        });
    }
    onDelete(goods, index) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            if (this.checkCanEdit()) {
                const res = yield this.commonUtils.showConfirm('确认', '确认删除该记录？');
                if (res) {
                    const loading = this.commonUtils.showLoading('正在删除...');
                    yield this.ticketService.deleteTicketGoods(goods);
                    this.commonUtils.hideLoadingSync(loading);
                    this.goodsList.splice(index, 1);
                }
            }
            else {
                this.commonUtils.showToast('当前状态不可修改！');
            }
        });
    }
    checkHasExchangeGoods(target) {
        let result = false;
        for (const goods of this.goodsList) {
            if (goods.goods_id === target.goods_id && goods.goods_track === target.goods_track) {
                result = true;
                break;
            }
        }
        return result;
    }
    checkCanEdit() {
        let canPopModal = false;
        if (this.status === 0) {
            canPopModal = true;
        }
        else if (this.status === 1) {
            canPopModal = this.userInfo.role === _components_index__WEBPACK_IMPORTED_MODULE_2__["ProjectConstant"].ROLE_SUPER_ADMIN
                || (this.userInfo.role === _components_index__WEBPACK_IMPORTED_MODULE_2__["ProjectConstant"].ROLE_SERIVICE
                    && (this.userInfo.type === _components_index__WEBPACK_IMPORTED_MODULE_2__["ProjectConstant"].AGENT_LEADER || this.userInfo.type === _components_index__WEBPACK_IMPORTED_MODULE_2__["ProjectConstant"].AGENT_STORE_HEADER));
        }
        else if (this.status === 2) {
            canPopModal = false;
        }
        return canPopModal;
    }
    imageError(event) {
        event.target.src = 'assets/imgs/mat/goods-no-image.svg';
    }
    ngOnDestroy() {
        this.storageUtils.remove(_components_index__WEBPACK_IMPORTED_MODULE_2__["ProjectConstant"].STORAGE_KEY_TICKET_GOODS_LIST);
    }
};
TicketChangeGoodsPage.ctorParameters = () => [
    { type: _components_index__WEBPACK_IMPORTED_MODULE_2__["CommonUtils"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_3__["ActivatedRoute"] },
    { type: _components_index__WEBPACK_IMPORTED_MODULE_2__["StorageUtils"] },
    { type: _service_index__WEBPACK_IMPORTED_MODULE_8__["TicketService"] },
    { type: _ticket_detail_ticket_detail_page__WEBPACK_IMPORTED_MODULE_6__["TicketDetailPage"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["ModalController"] }
];
TicketChangeGoodsPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-ticket-change-goods',
        template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./ticket-change-goods.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/ticket-change-goods/ticket-change-goods.page.html")).default,
        providers: [_service_index__WEBPACK_IMPORTED_MODULE_8__["TicketService"], _ticket_list_ticket_list_page__WEBPACK_IMPORTED_MODULE_5__["TicketListPage"], _ticket_detail_ticket_detail_page__WEBPACK_IMPORTED_MODULE_6__["TicketDetailPage"]],
        styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./ticket-change-goods.page.scss */ "./src/app/pages/ticket-change-goods/ticket-change-goods.page.scss")).default]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_components_index__WEBPACK_IMPORTED_MODULE_2__["CommonUtils"],
        _angular_router__WEBPACK_IMPORTED_MODULE_3__["ActivatedRoute"],
        _components_index__WEBPACK_IMPORTED_MODULE_2__["StorageUtils"],
        _service_index__WEBPACK_IMPORTED_MODULE_8__["TicketService"],
        _ticket_detail_ticket_detail_page__WEBPACK_IMPORTED_MODULE_6__["TicketDetailPage"],
        _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["ModalController"]])
], TicketChangeGoodsPage);



/***/ })

}]);
//# sourceMappingURL=ticket-change-goods-ticket-change-goods-module-es2015.js.map