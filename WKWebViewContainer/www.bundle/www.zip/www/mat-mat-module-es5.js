function _toConsumableArray(arr) { return _arrayWithoutHoles(arr) || _iterableToArray(arr) || _nonIterableSpread(); }

function _nonIterableSpread() { throw new TypeError("Invalid attempt to spread non-iterable instance"); }

function _iterableToArray(iter) { if (Symbol.iterator in Object(iter) || Object.prototype.toString.call(iter) === "[object Arguments]") return Array.from(iter); }

function _arrayWithoutHoles(arr) { if (Array.isArray(arr)) { for (var i = 0, arr2 = new Array(arr.length); i < arr.length; i++) { arr2[i] = arr[i]; } return arr2; } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["mat-mat-module"], {
  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/mat/mat.page.html":
  /*!*******************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/mat/mat.page.html ***!
    \*******************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppPagesMatMatPageHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-header>\n  <ion-toolbar color=\"ysw\">\n    <ion-buttons slot=\"start\" *ngIf=\"showBackButton\">\n      <ion-back-button></ion-back-button>\n    </ion-buttons>\n    <ion-title>{{title}}</ion-title>\n    <ion-buttons size=\"small\" collapse=\"true\" slot=\"end\">\n      <ion-button (click)=\"onChooseCityArea()\">\n        <ion-label class=\"icon-text-small\">{{buttonText}}</ion-label>\n      </ion-button>\n    </ion-buttons>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <ion-refresher slot=\"fixed\" (ionRefresh)=\"doRefresh($event)\" pullMax=\"2000\">\n    <ion-refresher-content></ion-refresher-content>\n  </ion-refresher>\n\n  <ion-header collapse=\"condense\">\n    <ion-toolbar color=\"ysw\">\n      <ion-title size=\"large\">{{title}}</ion-title>\n      <ion-buttons collapse=\"true\" slot=\"end\">\n        <ion-button (click)=\"onChooseCityArea()\">\n          <ion-label class=\"icon-text-small\">{{buttonText}}</ion-label>\n        </ion-button>\n      </ion-buttons>\n    </ion-toolbar>\n\n    <ion-toolbar color=\"ysw\">\n      <ion-searchbar color=\"light\" placeholder=\"售药机名称、编号\" showCancelButton=\"focus\" cancelButtonText=\"取消\"\n        inputmode=\"search\" [(ngModel)]=\"queryString\" [debounce]=\"2000\" (ionInput)=\"onSearch($event)\"></ion-searchbar>\n    </ion-toolbar>\n  </ion-header>\n\n  <skeleton [loading]=\"loading\">\n    <ion-list>\n      <ng-container *ngFor=\"let mat of matList\">\n        <ion-card>\n          <ion-card-header (click)=\"viewMatTrack(mat)\">\n            <ion-card-title [color]=\"mat.actived === 0 ? 'medium' : ''\">\n              <div class=\"flex ion-justify-content-start ion-align-items-center\">\n                <ion-label [color]=\"mat.online?'':'danger'\">{{mat.name}}</ion-label>\n                <ion-icon [color]=\"mat.online?'success':'danger'\" *ngIf=\"mat.enableErp\" name=\"share-social-sharp\">\n                </ion-icon>\n                <ion-icon [color]=\"mat.online?'success':'danger'\" *ngIf=\"mat.enableDelivery\" name=\"rocket-sharp\">\n                </ion-icon>\n                <ion-icon src=\"assets/imgs/mat/mat-meituan.svg\" *ngIf=\"mat.enableMeituan\"></ion-icon>\n                <ion-icon class=\"offline-shiny\" color=\"danger\" *ngIf=\"!mat.online\" name=\"flash-off-outline\"></ion-icon>\n              </div>\n            </ion-card-title>\n            <ion-card-subtitle [color]=\"mat.actived === 0 ? 'medium' : ''\">{{mat.externalNo}}</ion-card-subtitle>\n          </ion-card-header>\n\n          <ion-card-content>\n            <div class=\"flex ion-justify-content-start ion-align-items-center\">\n              <ion-icon name=\"pricetags\" style=\"flex-shrink: 0;\"></ion-icon>\n              <ion-badge color=\"primary\">{{mat.location}}</ion-badge>\n              <ion-badge color=\"primary\">{{mat.area}}</ion-badge>\n            </div>\n            <div class=\"flex ion-justify-content-start ion-align-items-center m-t-5\">\n              <ion-icon name=\"home\" style=\"flex-shrink: 0;\"></ion-icon>\n              <ion-label style=\"margin-top: 3px;\">{{mat.storeName}}</ion-label>\n            </div>\n            <div class=\"flex ion-justify-content-start ion-align-items-center m-t-5\">\n              <ion-icon name=\"call\" style=\"flex-shrink: 0;\"></ion-icon>\n              <ion-label style=\"margin-top: 3px;\" (click)=\"showNumberAction(mat.telephone)\" color=\"primary\">\n                {{mat.telephone}}</ion-label>\n            </div>\n            <div class=\"flex ion-justify-content-start ion-align-items-center m-t-5\">\n              <ion-icon name=\"person\" style=\"flex-shrink: 0;\"></ion-icon>\n              <ion-label style=\"margin-top: 3px;\">{{mat.ownerName}} - </ion-label>\n              <ion-label style=\"margin-top: 3px;\" (click)=\"showNumberAction(mat.mobile)\" color=\"primary\">{{mat.mobile}}\n              </ion-label>\n            </div>\n            <div (click)=\"navigationToMat(mat)\" class=\"flex ion-justify-content-between ion-align-items-center m-t-5\">\n              <div class=\"flex ion-justify-content-start ion-align-items-center\">\n                <ion-icon name=\"location\" style=\"flex-shrink: 0;\"></ion-icon>\n                <ion-label style=\"margin-top: 3px;\">{{mat.address}}</ion-label>\n              </div>\n              <ion-icon name=\"chevron-forward\" style=\"flex-shrink: 0;\"></ion-icon>\n            </div>\n            <div class=\"m-t-10 text-right\">\n              <!--\n              <ion-button style=\"height: 32px;\" (click)=\"onlineList(mat)\" size=\"small\" fill=\"solid\" color=\"ysw\">在线记录</ion-button>\n              <ion-button style=\"height: 32px;\" (click)=\"thList(mat)\" size=\"small\" fill=\"solid\" color=\"ysw\">温湿度</ion-button>\n              <ion-button (click)=\"locateMatTrack(mat)\" size=\"small\" color=\"ysw\">货道定位</ion-button>\n              -->\n              <ion-button *ngIf=\"mat.hasCabs\" style=\"height: 32px;\" (click)=\"viewMatCab(mat)\" size=\"small\"\n                fill=\"solid\" color=\"ysw\">格子柜</ion-button>\n              <ion-button style=\"height: 32px;\" (click)=\"viewMatTrack(mat)\" size=\"small\" fill=\"solid\" color=\"ysw\">货道·商品\n              </ion-button>\n              <ion-button style=\"height: 32px;\" (click)=\"showMoreAction(mat)\" size=\"small\" fill=\"solid\" color=\"ysw\">远程控制\n              </ion-button>\n            </div>\n          </ion-card-content>\n        </ion-card>\n      </ng-container>\n    </ion-list>\n\n    <empty-view [data]=\"matList\" message=\"暂无售药机数据~\">\n      <empty-content></empty-content>\n    </empty-view>\n\n    <ion-infinite-scroll threshold=\"100px\" (ionInfinite)=\"onInfinite($event)\">\n      <ion-infinite-scroll-content loadingSpinner=\"bubbles\" loadingText=\"加载更多...\">\n      </ion-infinite-scroll-content>\n    </ion-infinite-scroll>\n  </skeleton>\n\n</ion-content>";
    /***/
  },

  /***/
  "./src/app/pages/mat/mat-routing.module.ts":
  /*!*************************************************!*\
    !*** ./src/app/pages/mat/mat-routing.module.ts ***!
    \*************************************************/

  /*! exports provided: MatPageRoutingModule */

  /***/
  function srcAppPagesMatMatRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "MatPageRoutingModule", function () {
      return MatPageRoutingModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");
    /* harmony import */


    var _mat_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./mat.page */
    "./src/app/pages/mat/mat.page.ts");

    var routes = [{
      path: '',
      component: _mat_page__WEBPACK_IMPORTED_MODULE_3__["MatPage"]
    }, {
      path: 'online',
      loadChildren: function loadChildren() {
        return __webpack_require__.e(
        /*! import() | mat-online-mat-online-module */
        "mat-online-mat-online-module").then(__webpack_require__.bind(null,
        /*! ../mat-online/mat-online.module */
        "./src/app/pages/mat-online/mat-online.module.ts")).then(function (m) {
          return m.MatOnlinePageModule;
        });
      }
    }, {
      path: 'th',
      loadChildren: function loadChildren() {
        return __webpack_require__.e(
        /*! import() | mat-th-mat-th-module */
        "mat-th-mat-th-module").then(__webpack_require__.bind(null,
        /*! ../mat-th/mat-th.module */
        "./src/app/pages/mat-th/mat-th.module.ts")).then(function (m) {
          return m.MatThPageModule;
        });
      }
    }];

    var MatPageRoutingModule = function MatPageRoutingModule() {
      _classCallCheck(this, MatPageRoutingModule);
    };

    MatPageRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
      exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })], MatPageRoutingModule);
    /***/
  },

  /***/
  "./src/app/pages/mat/mat.module.ts":
  /*!*****************************************!*\
    !*** ./src/app/pages/mat/mat.module.ts ***!
    \*****************************************/

  /*! exports provided: MatPageModule */

  /***/
  function srcAppPagesMatMatModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "MatPageModule", function () {
      return MatPageModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/fesm2015/common.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/fesm2015/forms.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
    /* harmony import */


    var _mat_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ./mat-routing.module */
    "./src/app/pages/mat/mat-routing.module.ts");
    /* harmony import */


    var _mat_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ./mat.page */
    "./src/app/pages/mat/mat.page.ts");
    /* harmony import */


    var _module_index__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
    /*! ../module/index */
    "./src/app/pages/module/index.ts");

    var MatPageModule = function MatPageModule() {
      _classCallCheck(this, MatPageModule);
    };

    MatPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _mat_routing_module__WEBPACK_IMPORTED_MODULE_5__["MatPageRoutingModule"], _module_index__WEBPACK_IMPORTED_MODULE_7__["EmptyModule"], _module_index__WEBPACK_IMPORTED_MODULE_7__["SkeletonModule"]],
      declarations: [_mat_page__WEBPACK_IMPORTED_MODULE_6__["MatPage"]]
    })], MatPageModule);
    /***/
  },

  /***/
  "./src/app/pages/mat/mat.page.scss":
  /*!*****************************************!*\
    !*** ./src/app/pages/mat/mat.page.scss ***!
    \*****************************************/

  /*! exports provided: default */

  /***/
  function srcAppPagesMatMatPageScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "ion-icon + ion-label {\n  margin-left: 6px;\n}\n\nion-card-title ion-label {\n  font-size: 0.6em;\n}\n\nion-card-content ion-badge {\n  margin-left: 5px;\n}\n\nion-card-title ion-icon {\n  margin-left: 5px;\n  font-size: 0.6em;\n}\n\nion-card-content ion-label {\n  font-size: 13px;\n}\n\n.offline-shiny {\n  animation: offline-shiny-shiny 1s infinite;\n  -webkit-animation: offline-shiny-shiny 1s infinite;\n}\n\n@-webkit-keyframes offline-shiny-shiny {\n  0% {\n    opacity: 1;\n  }\n  50% {\n    opacity: 0.1;\n  }\n  100% {\n    opacity: 1;\n  }\n}\n\n@keyframes offline-shiny-shiny {\n  0% {\n    opacity: 1;\n  }\n  50% {\n    opacity: 0.1;\n  }\n  100% {\n    opacity: 1;\n  }\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Vc2Vycy9jaGFubmluZy9EZXNrdG9wL3lzdy1hcHAtc2VydmljZTQvc3JjL2FwcC9wYWdlcy9tYXQvbWF0LnBhZ2Uuc2NzcyIsInNyYy9hcHAvcGFnZXMvbWF0L21hdC5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSxnQkFBQTtBQ0NGOztBREVBO0VBQ0UsZ0JBQUE7QUNDRjs7QURFQTtFQUNFLGdCQUFBO0FDQ0Y7O0FERUE7RUFDRSxnQkFBQTtFQUNBLGdCQUFBO0FDQ0Y7O0FERUE7RUFDRSxlQUFBO0FDQ0Y7O0FERUE7RUFDRSwwQ0FBQTtFQUNBLGtEQUFBO0FDQ0Y7O0FEQ0E7RUFDRTtJQUNFLFVBQUE7RUNFRjtFREFBO0lBQ0UsWUFBQTtFQ0VGO0VEQUE7SUFDRSxVQUFBO0VDRUY7QUFDRjs7QURYQTtFQUNFO0lBQ0UsVUFBQTtFQ0VGO0VEQUE7SUFDRSxZQUFBO0VDRUY7RURBQTtJQUNFLFVBQUE7RUNFRjtBQUNGIiwiZmlsZSI6InNyYy9hcHAvcGFnZXMvbWF0L21hdC5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJpb24taWNvbiArIGlvbi1sYWJlbCB7XG4gIG1hcmdpbi1sZWZ0OiA2cHg7XG59XG5cbmlvbi1jYXJkLXRpdGxlIGlvbi1sYWJlbCB7XG4gIGZvbnQtc2l6ZTogMC42ZW07XG59XG5cbmlvbi1jYXJkLWNvbnRlbnQgaW9uLWJhZGdlIHtcbiAgbWFyZ2luLWxlZnQ6IDVweDtcbn1cblxuaW9uLWNhcmQtdGl0bGUgaW9uLWljb24ge1xuICBtYXJnaW4tbGVmdDogNXB4O1xuICBmb250LXNpemU6IDAuNmVtO1xufVxuXG5pb24tY2FyZC1jb250ZW50IGlvbi1sYWJlbCB7XG4gIGZvbnQtc2l6ZTogMTNweDtcbn1cblxuLm9mZmxpbmUtc2hpbnkge1xuICBhbmltYXRpb246IG9mZmxpbmUtc2hpbnktc2hpbnkgMXMgaW5maW5pdGU7XG4gIC13ZWJraXQtYW5pbWF0aW9uOiBvZmZsaW5lLXNoaW55LXNoaW55IDFzIGluZmluaXRlO1xufVxuQGtleWZyYW1lcyBvZmZsaW5lLXNoaW55LXNoaW55IHtcbiAgMCUge1xuICAgIG9wYWNpdHk6IDE7XG4gIH1cbiAgNTAlIHtcbiAgICBvcGFjaXR5OiAwLjE7XG4gIH1cbiAgMTAwJSB7XG4gICAgb3BhY2l0eTogMTtcbiAgfVxufSIsImlvbi1pY29uICsgaW9uLWxhYmVsIHtcbiAgbWFyZ2luLWxlZnQ6IDZweDtcbn1cblxuaW9uLWNhcmQtdGl0bGUgaW9uLWxhYmVsIHtcbiAgZm9udC1zaXplOiAwLjZlbTtcbn1cblxuaW9uLWNhcmQtY29udGVudCBpb24tYmFkZ2Uge1xuICBtYXJnaW4tbGVmdDogNXB4O1xufVxuXG5pb24tY2FyZC10aXRsZSBpb24taWNvbiB7XG4gIG1hcmdpbi1sZWZ0OiA1cHg7XG4gIGZvbnQtc2l6ZTogMC42ZW07XG59XG5cbmlvbi1jYXJkLWNvbnRlbnQgaW9uLWxhYmVsIHtcbiAgZm9udC1zaXplOiAxM3B4O1xufVxuXG4ub2ZmbGluZS1zaGlueSB7XG4gIGFuaW1hdGlvbjogb2ZmbGluZS1zaGlueS1zaGlueSAxcyBpbmZpbml0ZTtcbiAgLXdlYmtpdC1hbmltYXRpb246IG9mZmxpbmUtc2hpbnktc2hpbnkgMXMgaW5maW5pdGU7XG59XG5cbkBrZXlmcmFtZXMgb2ZmbGluZS1zaGlueS1zaGlueSB7XG4gIDAlIHtcbiAgICBvcGFjaXR5OiAxO1xuICB9XG4gIDUwJSB7XG4gICAgb3BhY2l0eTogMC4xO1xuICB9XG4gIDEwMCUge1xuICAgIG9wYWNpdHk6IDE7XG4gIH1cbn0iXX0= */";
    /***/
  },

  /***/
  "./src/app/pages/mat/mat.page.ts":
  /*!***************************************!*\
    !*** ./src/app/pages/mat/mat.page.ts ***!
    \***************************************/

  /*! exports provided: MatPage */

  /***/
  function srcAppPagesMatMatPageTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "MatPage", function () {
      return MatPage;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
    /* harmony import */


    var _components_index__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ../../components/index */
    "./src/app/components/index.ts");
    /* harmony import */


    var _service_index__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! ../../service/index */
    "./src/app/service/index.ts");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");
    /* harmony import */


    var _environments_environment__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ../../../environments/environment */
    "./src/environments/environment.ts");
    /* harmony import */


    var _modal_mat_action_mat_action_page__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
    /*! ../modal/mat-action/mat-action.page */
    "./src/app/pages/modal/mat-action/mat-action.page.ts");
    /* harmony import */


    var js_base64__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(
    /*! js-base64 */
    "./node_modules/js-base64/base64.js");
    /* harmony import */


    var js_base64__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(js_base64__WEBPACK_IMPORTED_MODULE_8__);

    var MatPage = /*#__PURE__*/function () {
      function MatPage(matService, commonUtils, storageUtils, nativeUtils, modalCtrl, actionSheetCtrl, activeRoute, router) {
        var _this = this;

        _classCallCheck(this, MatPage);

        this.matService = matService;
        this.commonUtils = commonUtils;
        this.storageUtils = storageUtils;
        this.nativeUtils = nativeUtils;
        this.modalCtrl = modalCtrl;
        this.actionSheetCtrl = actionSheetCtrl;
        this.activeRoute = activeRoute;
        this.router = router;
        this.title = '售药机管理';
        this.selectedCity = '0';
        this.selectedArea = '0';
        this.showBackButton = false;
        this.online = null;
        this.buttonText = '全部';
        this.queryString = '';
        this.pageIndex = _environments_environment__WEBPACK_IMPORTED_MODULE_6__["environment"].pageIndex;
        this.pageSize = _environments_environment__WEBPACK_IMPORTED_MODULE_6__["environment"].pageSize;
        this.showMore = true;
        this.matList = [];
        this.loading = true;
        this.isStorePriv = false;
        this.activeRoute.queryParams.subscribe(function (params) {
          if (!commonUtils.isNullOrEmptyString(params.title)) {
            _this.title = params.title;
          }

          if (!commonUtils.isNullOrEmptyString(params.online)) {
            _this.online = parseInt(params.online, 10);
          }

          if (!commonUtils.isNullOrEmptyString(params.showBackButton)) {
            _this.showBackButton = params.showBackButton === 'true';
          }
        });
        this.userInfo = this.storageUtils.get(_components_index__WEBPACK_IMPORTED_MODULE_3__["ProjectConstant"].STORAGE_KEY_USERINFO);

        if (this.userInfo.role === 'Service' && (this.userInfo.type === _components_index__WEBPACK_IMPORTED_MODULE_3__["ProjectConstant"].AGENT_STORE || this.userInfo.type === _components_index__WEBPACK_IMPORTED_MODULE_3__["ProjectConstant"].AGENT_STORE_HEADER)) {
          this.isStorePriv = true;
        }
      }

      _createClass(MatPage, [{
        key: "ngOnInit",
        value: function ngOnInit() {
          return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
            return regeneratorRuntime.wrap(function _callee$(_context) {
              while (1) {
                switch (_context.prev = _context.next) {
                  case 0:
                    _context.next = 2;
                    return this.loadMatList(this.queryString, false);

                  case 2:
                    this.matList = _context.sent;
                    this.loading = false;

                  case 4:
                  case "end":
                    return _context.stop();
                }
              }
            }, _callee, this);
          }));
        }
      }, {
        key: "loadMatList",
        value: function loadMatList(queryString) {
          var showLoading = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : true;
          return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee2() {
            var loading, payload, data;
            return regeneratorRuntime.wrap(function _callee2$(_context2) {
              while (1) {
                switch (_context2.prev = _context2.next) {
                  case 0:
                    if (showLoading) {
                      loading = this.commonUtils.showLoading('正在加载...');
                    }

                    payload = {
                      location: this.selectedCity === '0' ? '' : this.selectedCity,
                      area: this.selectedArea === '0' ? '' : this.selectedArea,
                      name: queryString,
                      online: this.online
                    };
                    _context2.next = 4;
                    return this.matService.getMatList(payload, this.pageIndex, this.pageSize);

                  case 4:
                    data = _context2.sent;

                    if (showLoading) {
                      this.commonUtils.hideLoadingSync(loading);
                    }

                    this.showMore = data.list.length >= this.pageSize;
                    this.infiniteScroll.disabled = !this.showMore;
                    return _context2.abrupt("return", data.list);

                  case 9:
                  case "end":
                    return _context2.stop();
                }
              }
            }, _callee2, this);
          }));
        }
      }, {
        key: "onSearch",
        value: function onSearch(event) {
          var _this2 = this;

          if (this.timer) {
            clearTimeout(this.timer);
          }

          this.timer = setTimeout(function () {
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](_this2, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee3() {
              return regeneratorRuntime.wrap(function _callee3$(_context3) {
                while (1) {
                  switch (_context3.prev = _context3.next) {
                    case 0:
                      this.pageIndex = 1;
                      _context3.next = 3;
                      return this.loadMatList(this.queryString);

                    case 3:
                      this.matList = _context3.sent;

                    case 4:
                    case "end":
                      return _context3.stop();
                  }
                }
              }, _callee3, this);
            }));
          }, 2000);
        }
      }, {
        key: "doRefresh",
        value: function doRefresh(event) {
          return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee4() {
            return regeneratorRuntime.wrap(function _callee4$(_context4) {
              while (1) {
                switch (_context4.prev = _context4.next) {
                  case 0:
                    this.pageIndex = 1;
                    _context4.next = 3;
                    return this.loadMatList(this.queryString);

                  case 3:
                    this.matList = _context4.sent;
                    event.target.complete();

                  case 5:
                  case "end":
                    return _context4.stop();
                }
              }
            }, _callee4, this);
          }));
        }
      }, {
        key: "onInfinite",
        value: function onInfinite(event) {
          return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee5() {
            var data;
            return regeneratorRuntime.wrap(function _callee5$(_context5) {
              while (1) {
                switch (_context5.prev = _context5.next) {
                  case 0:
                    this.pageIndex += 1;
                    _context5.next = 3;
                    return this.loadMatList(this.queryString);

                  case 3:
                    data = _context5.sent;
                    this.matList = [].concat(_toConsumableArray(this.matList), _toConsumableArray(data));
                    event.target.complete();

                  case 6:
                  case "end":
                    return _context5.stop();
                }
              }
            }, _callee5, this);
          }));
        }
      }, {
        key: "onChooseCityArea",
        value: function onChooseCityArea() {
          return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee6() {
            var data;
            return regeneratorRuntime.wrap(function _callee6$(_context6) {
              while (1) {
                switch (_context6.prev = _context6.next) {
                  case 0:
                    _context6.next = 2;
                    return this.commonUtils.popLocationPicker(this.selectedCity, this.selectedArea);

                  case 2:
                    data = _context6.sent;
                    this.selectedCity = data.city.value;
                    this.selectedArea = data.area.value;

                    if (this.selectedCity === '0') {
                      this.buttonText = '全部';
                    } else {
                      this.buttonText = data.city.text;

                      if (this.selectedArea !== '0') {
                        this.buttonText += ', ' + data.area.text;
                      }
                    }

                    this.pageIndex = 1;
                    _context6.next = 9;
                    return this.loadMatList(this.queryString);

                  case 9:
                    this.matList = _context6.sent;

                  case 10:
                  case "end":
                    return _context6.stop();
                }
              }
            }, _callee6, this);
          }));
        }
      }, {
        key: "navigationToMat",
        value: function navigationToMat(mat) {
          this.commonUtils.navigation(mat.latitude, mat.longitude, mat.name, mat.address);
        }
      }, {
        key: "locateMatTrack",
        value: function locateMatTrack(mat) {
          console.log(mat);
          this.commonUtils.showToast('暂未开放！');
        }
      }, {
        key: "showNumberAction",
        value: function showNumberAction(phoneNumber) {
          return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee7() {
            var _this3 = this;

            var buttons, actionSheet;
            return regeneratorRuntime.wrap(function _callee7$(_context7) {
              while (1) {
                switch (_context7.prev = _context7.next) {
                  case 0:
                    buttons = [{
                      text: '复制',
                      cssClass: 'ysw-action-sheet',
                      handler: function handler() {
                        _this3.nativeUtils.copyToClipboard(phoneNumber);
                      }
                    }, {
                      text: '拨打',
                      cssClass: 'ysw-action-sheet',
                      handler: function handler() {
                        _this3.nativeUtils.callNumber(phoneNumber);
                      }
                    }, {
                      text: '取消',
                      cssClass: 'ysw-action-sheet',
                      role: 'cancel',
                      handler: function handler() {}
                    }];
                    _context7.next = 3;
                    return this.actionSheetCtrl.create({
                      buttons: buttons
                    });

                  case 3:
                    actionSheet = _context7.sent;
                    _context7.next = 6;
                    return actionSheet.present();

                  case 6:
                  case "end":
                    return _context7.stop();
                }
              }
            }, _callee7, this);
          }));
        }
      }, {
        key: "showMoreAction",
        value: function showMoreAction(mat) {
          return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee8() {
            var modal, _ref, data;

            return regeneratorRuntime.wrap(function _callee8$(_context8) {
              while (1) {
                switch (_context8.prev = _context8.next) {
                  case 0:
                    _context8.next = 2;
                    return this.modalCtrl.create({
                      component: _modal_mat_action_mat_action_page__WEBPACK_IMPORTED_MODULE_7__["MatActionPage"],
                      componentProps: {
                        mat: mat,
                        isStorePriv: this.isStorePriv
                      },
                      backdropDismiss: true,
                      cssClass: 'ysw-action-modal-vertical'
                    });

                  case 2:
                    modal = _context8.sent;
                    _context8.next = 5;
                    return modal.present();

                  case 5:
                    _context8.next = 7;
                    return modal.onWillDismiss();

                  case 7:
                    _ref = _context8.sent;
                    data = _ref.data;

                  case 9:
                  case "end":
                    return _context8.stop();
                }
              }
            }, _callee8, this);
          }));
        }
      }, {
        key: "onlineList",
        value: function onlineList(mat) {
          this.router.navigate(['../online'], {
            relativeTo: this.activeRoute,
            queryParams: {
              matId: mat.id
            }
          });
        }
      }, {
        key: "thList",
        value: function thList(mat) {}
      }, {
        key: "viewMatTrack",
        value: function viewMatTrack(mat) {
          this.router.navigate(['../track'], {
            relativeTo: this.activeRoute,
            queryParams: {
              matId: mat.id,
              matNo: mat.externalNo,
              matName: js_base64__WEBPACK_IMPORTED_MODULE_8__["Base64"].encode(mat.name),
              enableMeituan: mat.enableMeituan
            }
          });
        }
      }, {
        key: "viewMatCab",
        value: function viewMatCab(mat) {
          this.router.navigate(['../cab'], {
            relativeTo: this.activeRoute,
            queryParams: {
              matId: mat.id,
              matName: js_base64__WEBPACK_IMPORTED_MODULE_8__["Base64"].encode(mat.name)
            }
          });
        }
      }]);

      return MatPage;
    }();

    MatPage.ctorParameters = function () {
      return [{
        type: _service_index__WEBPACK_IMPORTED_MODULE_4__["MatService"]
      }, {
        type: _components_index__WEBPACK_IMPORTED_MODULE_3__["CommonUtils"]
      }, {
        type: _components_index__WEBPACK_IMPORTED_MODULE_3__["StorageUtils"]
      }, {
        type: _components_index__WEBPACK_IMPORTED_MODULE_3__["NativeUtils"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ModalController"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ActionSheetController"]
      }, {
        type: _angular_router__WEBPACK_IMPORTED_MODULE_5__["ActivatedRoute"]
      }, {
        type: _angular_router__WEBPACK_IMPORTED_MODULE_5__["Router"]
      }];
    };

    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"])(_ionic_angular__WEBPACK_IMPORTED_MODULE_2__["IonInfiniteScroll"], {
      static: true
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["IonInfiniteScroll"])], MatPage.prototype, "infiniteScroll", void 0);
    MatPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-mat',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./mat.page.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/mat/mat.page.html")).default,
      providers: [_service_index__WEBPACK_IMPORTED_MODULE_4__["MatService"]],
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./mat.page.scss */
      "./src/app/pages/mat/mat.page.scss")).default]
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_service_index__WEBPACK_IMPORTED_MODULE_4__["MatService"], _components_index__WEBPACK_IMPORTED_MODULE_3__["CommonUtils"], _components_index__WEBPACK_IMPORTED_MODULE_3__["StorageUtils"], _components_index__WEBPACK_IMPORTED_MODULE_3__["NativeUtils"], _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ModalController"], _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ActionSheetController"], _angular_router__WEBPACK_IMPORTED_MODULE_5__["ActivatedRoute"], _angular_router__WEBPACK_IMPORTED_MODULE_5__["Router"]])], MatPage);
    /***/
  }
}]);
//# sourceMappingURL=mat-mat-module-es5.js.map