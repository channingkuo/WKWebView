function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["goods-price-alert-goods-price-alert-module"], {
  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/goods-price-alert/goods-price-alert.page.html":
  /*!***********************************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/goods-price-alert/goods-price-alert.page.html ***!
    \***********************************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppPagesGoodsPriceAlertGoodsPriceAlertPageHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-header>\n  <ion-toolbar color=\"ysw\">\n    <ion-buttons slot=\"start\">\n      <ion-back-button></ion-back-button>\n    </ion-buttons>\n    <ion-title>商品价格警报</ion-title>\n    <ion-buttons collapse=\"true\" slot=\"end\">\n      <ion-button (click)=\"onChooseCityArea()\">\n        <ion-label class=\"icon-text-small\">{{buttonText}}</ion-label>\n      </ion-button>\n    </ion-buttons>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <ion-refresher slot=\"fixed\" (ionRefresh)=\"doRefresh($event)\" pullMax=\"2000\">\n    <ion-refresher-content></ion-refresher-content>\n  </ion-refresher>\n\n  <ion-header collapse=\"condense\">\n    <ion-toolbar color=\"ysw\">\n      <ion-title size=\"large\">\n        商品价格警报\n      </ion-title>\n      <ion-buttons collapse=\"true\" slot=\"end\">\n        <ion-button (click)=\"onChooseCityArea()\">\n          <ion-label class=\"icon-text-small\">{{buttonText}}</ion-label>\n        </ion-button>\n      </ion-buttons>\n    </ion-toolbar>\n    <ion-toolbar color=\"ysw\">\n      <ion-searchbar color=\"light\" placeholder=\"售药机名称、编号\" showCancelButton=\"focus\" cancelButtonText=\"取消\"\n        inputmode=\"search\" [(ngModel)]=\"queryString\" [debounce]=\"2000\" (ionInput)=\"onSearch($event)\"></ion-searchbar>\n    </ion-toolbar>\n  </ion-header>\n\n  <skeleton [loading]=\"loading\">\n    <ion-list>\n      <ng-container *ngFor=\"let mat of priceAlert\">\n        <ion-card (click)=\"viewStorageAlertView(mat)\">\n          <ion-card-header>\n            <ion-card-title class=\"flex ion-justify-content-between ion-align-items-center\">\n              <ion-label>{{mat.matName}}</ion-label>\n              <ion-badge color=\"danger\">\n                {{mat.goodsPriceAlertList.length}}\n              </ion-badge>\n            </ion-card-title>\n            <ion-card-subtitle class=\"flex ion-justify-content-between ion-align-items-center\">\n              <ion-label>{{mat.matSerial}}</ion-label>\n              <ion-label>{{mat.goodsPriceAlertList.length}} 个商品价格异常</ion-label>\n            </ion-card-subtitle>\n          </ion-card-header>\n        </ion-card>\n      </ng-container>\n    </ion-list>\n\n    <empty-view [data]=\"priceAlert\" message=\"暂无警报数据~\">\n      <empty-content></empty-content>\n    </empty-view>\n  </skeleton>\n</ion-content>";
    /***/
  },

  /***/
  "./src/app/pages/goods-price-alert/goods-price-alert.module.ts":
  /*!*********************************************************************!*\
    !*** ./src/app/pages/goods-price-alert/goods-price-alert.module.ts ***!
    \*********************************************************************/

  /*! exports provided: GoodsPriceAlertPageModule */

  /***/
  function srcAppPagesGoodsPriceAlertGoodsPriceAlertModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "GoodsPriceAlertPageModule", function () {
      return GoodsPriceAlertPageModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/fesm2015/common.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/fesm2015/forms.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
    /* harmony import */


    var _goods_price_alert_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ./goods-price-alert.page */
    "./src/app/pages/goods-price-alert/goods-price-alert.page.ts");
    /* harmony import */


    var _module_index__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
    /*! ../module/index */
    "./src/app/pages/module/index.ts");

    var GoodsPriceAlertPageModule = function GoodsPriceAlertPageModule() {
      _classCallCheck(this, GoodsPriceAlertPageModule);
    };

    GoodsPriceAlertPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"], _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild([{
        path: '',
        component: _goods_price_alert_page__WEBPACK_IMPORTED_MODULE_6__["GoodsPriceAlertPage"]
      }, {
        path: 'goods',
        loadChildren: function loadChildren() {
          return __webpack_require__.e(
          /*! import() | goods-list-goods-list-module */
          "goods-list-goods-list-module").then(__webpack_require__.bind(null,
          /*! ../goods-list/goods-list.module */
          "./src/app/pages/goods-list/goods-list.module.ts")).then(function (m) {
            return m.GoodsListPageModule;
          });
        }
      }]), _module_index__WEBPACK_IMPORTED_MODULE_7__["EmptyModule"], _module_index__WEBPACK_IMPORTED_MODULE_7__["SkeletonModule"]],
      declarations: [_goods_price_alert_page__WEBPACK_IMPORTED_MODULE_6__["GoodsPriceAlertPage"]]
    })], GoodsPriceAlertPageModule);
    /***/
  },

  /***/
  "./src/app/pages/goods-price-alert/goods-price-alert.page.scss":
  /*!*********************************************************************!*\
    !*** ./src/app/pages/goods-price-alert/goods-price-alert.page.scss ***!
    \*********************************************************************/

  /*! exports provided: default */

  /***/
  function srcAppPagesGoodsPriceAlertGoodsPriceAlertPageScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3BhZ2VzL2dvb2RzLXByaWNlLWFsZXJ0L2dvb2RzLXByaWNlLWFsZXJ0LnBhZ2Uuc2NzcyJ9 */";
    /***/
  },

  /***/
  "./src/app/pages/goods-price-alert/goods-price-alert.page.ts":
  /*!*******************************************************************!*\
    !*** ./src/app/pages/goods-price-alert/goods-price-alert.page.ts ***!
    \*******************************************************************/

  /*! exports provided: GoodsPriceAlertPage */

  /***/
  function srcAppPagesGoodsPriceAlertGoodsPriceAlertPageTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "GoodsPriceAlertPage", function () {
      return GoodsPriceAlertPage;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");
    /* harmony import */


    var _service_index__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ../../service/index */
    "./src/app/service/index.ts");
    /* harmony import */


    var _components_index__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! ../../components/index */
    "./src/app/components/index.ts");

    var GoodsPriceAlertPage = /*#__PURE__*/function () {
      function GoodsPriceAlertPage(matService, commonUtils, storageUtils, router, activatedRoute) {
        _classCallCheck(this, GoodsPriceAlertPage);

        this.matService = matService;
        this.commonUtils = commonUtils;
        this.storageUtils = storageUtils;
        this.router = router;
        this.activatedRoute = activatedRoute;
        this.buttonText = '全部';
        this.selectedCity = '0';
        this.selectedArea = '0';
        this.queryString = '';
        this.priceAlert = [];
        this.loading = true;
      }

      _createClass(GoodsPriceAlertPage, [{
        key: "ngOnInit",
        value: function ngOnInit() {
          return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
            return regeneratorRuntime.wrap(function _callee$(_context) {
              while (1) {
                switch (_context.prev = _context.next) {
                  case 0:
                    _context.next = 2;
                    return this.loadData();

                  case 2:
                    this.priceAlert = _context.sent;
                    this.loading = false;

                  case 4:
                  case "end":
                    return _context.stop();
                }
              }
            }, _callee, this);
          }));
        }
      }, {
        key: "loadData",
        value: function loadData() {
          return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee2() {
            var alertSettings, data;
            return regeneratorRuntime.wrap(function _callee2$(_context2) {
              while (1) {
                switch (_context2.prev = _context2.next) {
                  case 0:
                    // const loading = this.commonUtils.showLoading();
                    alertSettings = this.storageUtils.get(_components_index__WEBPACK_IMPORTED_MODULE_4__["ProjectConstant"].STORAGE_KEY_ALERT_SETTINGS);
                    _context2.next = 3;
                    return this.matService.getMatGoodsPriceAlertInfo(alertSettings.price, this.queryString, this.selectedCity, this.selectedArea);

                  case 3:
                    data = _context2.sent;
                    return _context2.abrupt("return", data);

                  case 5:
                  case "end":
                    return _context2.stop();
                }
              }
            }, _callee2, this);
          }));
        }
      }, {
        key: "doRefresh",
        value: function doRefresh(event) {
          return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee3() {
            return regeneratorRuntime.wrap(function _callee3$(_context3) {
              while (1) {
                switch (_context3.prev = _context3.next) {
                  case 0:
                    _context3.next = 2;
                    return this.loadData();

                  case 2:
                    this.priceAlert = _context3.sent;
                    event.target.complete();

                  case 4:
                  case "end":
                    return _context3.stop();
                }
              }
            }, _callee3, this);
          }));
        }
      }, {
        key: "onSearch",
        value: function onSearch(event) {
          var _this = this;

          if (this.timer) {
            clearTimeout(this.timer);
          }

          this.timer = setTimeout(function () {
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](_this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee4() {
              return regeneratorRuntime.wrap(function _callee4$(_context4) {
                while (1) {
                  switch (_context4.prev = _context4.next) {
                    case 0:
                      _context4.next = 2;
                      return this.loadData();

                    case 2:
                      this.priceAlert = _context4.sent;

                    case 3:
                    case "end":
                      return _context4.stop();
                  }
                }
              }, _callee4, this);
            }));
          }, 2000);
        }
      }, {
        key: "onChooseCityArea",
        value: function onChooseCityArea() {
          return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee5() {
            var data;
            return regeneratorRuntime.wrap(function _callee5$(_context5) {
              while (1) {
                switch (_context5.prev = _context5.next) {
                  case 0:
                    _context5.next = 2;
                    return this.commonUtils.popLocationPicker(this.selectedCity, this.selectedArea);

                  case 2:
                    data = _context5.sent;
                    this.selectedCity = data.city.value;
                    this.selectedArea = data.area.value;

                    if (this.selectedCity === '0') {
                      this.buttonText = '全部';
                    } else {
                      this.buttonText = data.city.text;

                      if (this.selectedArea !== '0') {
                        this.buttonText += ', ' + data.area.text;
                      }
                    }

                    _context5.next = 8;
                    return this.loadData();

                  case 8:
                    this.priceAlert = _context5.sent;

                  case 9:
                  case "end":
                    return _context5.stop();
                }
              }
            }, _callee5, this);
          }));
        }
      }, {
        key: "viewStorageAlertView",
        value: function viewStorageAlertView(mat) {
          var goodsInfo = mat.goodsPriceAlertList;
          this.storageUtils.set(_components_index__WEBPACK_IMPORTED_MODULE_4__["ProjectConstant"].STORAGE_KEY_ALERT_GOODS_INFO, goodsInfo);
          this.router.navigate(['../goods/list'], {
            relativeTo: this.activatedRoute,
            queryParams: {
              title: encodeURI('价格警报：' + mat.matName)
            }
          });
        }
      }]);

      return GoodsPriceAlertPage;
    }();

    GoodsPriceAlertPage.ctorParameters = function () {
      return [{
        type: _service_index__WEBPACK_IMPORTED_MODULE_3__["MatService"]
      }, {
        type: _components_index__WEBPACK_IMPORTED_MODULE_4__["CommonUtils"]
      }, {
        type: _components_index__WEBPACK_IMPORTED_MODULE_4__["StorageUtils"]
      }, {
        type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"]
      }, {
        type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"]
      }];
    };

    GoodsPriceAlertPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-goods-price-alert',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./goods-price-alert.page.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/goods-price-alert/goods-price-alert.page.html")).default,
      providers: [_service_index__WEBPACK_IMPORTED_MODULE_3__["MatService"]],
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./goods-price-alert.page.scss */
      "./src/app/pages/goods-price-alert/goods-price-alert.page.scss")).default]
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_service_index__WEBPACK_IMPORTED_MODULE_3__["MatService"], _components_index__WEBPACK_IMPORTED_MODULE_4__["CommonUtils"], _components_index__WEBPACK_IMPORTED_MODULE_4__["StorageUtils"], _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"], _angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"]])], GoodsPriceAlertPage);
    /***/
  }
}]);
//# sourceMappingURL=goods-price-alert-goods-price-alert-module-es5.js.map