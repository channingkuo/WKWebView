(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["supply-plan-detail-supply-plan-detail-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/supply-plan-detail/supply-plan-detail.page.html":
/*!*************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/supply-plan-detail/supply-plan-detail.page.html ***!
  \*************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\n  <ion-toolbar color=\"ysw\">\n    <ion-buttons slot=\"start\">\n      <ion-back-button></ion-back-button>\n    </ion-buttons>\n    <ion-title>补货计划详情</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <ion-header collapse=\"condense\">\n    <ion-toolbar color=\"ysw\">\n      <ion-title size=\"large\">补货计划详情</ion-title>\n    </ion-toolbar>\n  </ion-header>\n\n  <skeleton [loading]=\"loading\">\n    <ion-list>\n      <ion-card>\n        <ion-card-header>\n          <ion-card-title class=\"flex ion-justify-content-between ion-align-items-center\">\n            <ion-label>\n              {{supplyPlanDetails.planNo}}\n            </ion-label>\n            <ion-badge [color]=\"genLabelColor(supplyPlanDetails.status)\">\n              {{genLabelName(supplyPlanDetails.status)}}\n            </ion-badge>\n          </ion-card-title>\n          <ion-card-subtitle>\n            <ion-label class=\"ion-text-wrap\">\n              {{supplyPlanDetails.matName}} <small>{{supplyPlanDetails.matSerial}}</small>\n            </ion-label>\n          </ion-card-subtitle>\n        </ion-card-header>\n        <ion-card-content>\n          <div class=\"flex ion-justify-content-between ion-align-items-center content-line\">\n            <ion-text>计划类型：</ion-text>\n            <ion-text [color]=\"supplyPlanDetails.type === 0 ? 'ysw' : 'danger'\" class=\"ion-float-right\">\n              {{supplyPlanDetails.type === 0 ? '补货' : '商品撤回'}}\n            </ion-text>\n          </div>\n          <div class=\"flex ion-justify-content-between ion-align-items-center content-line\">\n            <ion-label>创建人员：</ion-label>\n            <ion-label>{{supplyPlanDetails.createdBy}}</ion-label>\n          </div>\n          <div class=\"flex ion-justify-content-between ion-align-items-center content-line\">\n            <ion-label color=\"dark\">创建时间：</ion-label>\n            <ion-label>{{supplyPlanDetails.createdDate| date: 'yyyy-MM-dd HH:mm:ss'}}</ion-label>\n          </div>\n          <div class=\"flex ion-justify-content-between ion-align-items-center content-line\">\n            <ion-label color=\"dark\">最近修改：</ion-label>\n            <ion-label>{{supplyPlanDetails.updatedDate| date: 'yyyy-MM-dd HH:mm:ss'}}</ion-label>\n          </div>\n\n          <div\n            *ngIf=\"(supplyPlanDetails.status === 1 || supplyPlanDetails.status === 6) && supplyPlanDetails.type === 0\"\n            class=\"b-b-split\"></div>\n\n          <div\n            *ngIf=\"(supplyPlanDetails.status === 1 || supplyPlanDetails.status === 6) && supplyPlanDetails.type === 0\"\n            class=\"text-center m-t-10\">\n            <ion-button (click)=\"onSupply()\" fill=\"outline\" expand=\"block\" color=\"danger\">\n              确认商品已经放入售药机内\n            </ion-button>\n          </div>\n        </ion-card-content>\n      </ion-card>\n\n      <ion-card>\n        <split-label class=\"\">货盘商品照片</split-label>\n        <ion-card-content>\n          <div class=\"image-list flex ion-justify-content-start ion-align-items-center\">\n            <ng-container *ngFor=\"let image of supplyImages\">\n              <ion-thumbnail (click)=\"previewImage(image)\" class=\"ion-margin-end some-images\">\n                <img [src]=\"image\" />\n              </ion-thumbnail>\n            </ng-container>\n            <ng-container *ngFor=\"let image of imageUploadNow\">\n              <ion-thumbnail (click)=\"previewImage(image)\" class=\"ion-margin-end some-images\">\n                <img [src]=\"image.url\" />\n              </ion-thumbnail>\n            </ng-container>\n          </div>\n          <ng-container *ngIf=\"!supplyImages.length && !imageUploadNow.length\">\n            <div (click)=\"uploadImage()\" class=\"flex ion-justify-content-center ion-align-items-center content-line\">\n              <ion-text>点击添加</ion-text>\n            </div>\n          </ng-container>\n        </ion-card-content>\n      </ion-card>\n\n      <ion-card>\n        <split-label class=\"\">补货商品详情</split-label>\n\n        <ion-text (click)=\"gotoMatTrack()\" style=\"position: absolute;right: 10px;top: 15px;color: darkviolet;\">\n          查看所有货道\n        </ion-text>\n\n        <ion-card-content *ngFor=\"let supplyPlanDetail of supplyPlanDetails.supplyPlanDetails\"\n          style=\"padding: 0;border-bottom: solid 1px #ffc409;margin-top: 10px;\">\n\n          <div class=\"flex ion-justify-content-around ion-align-items-center\">\n            <div class=\"flex flex-column ion-justify-content-center ion-align-items-center gray-fliter\">\n              <ion-img (ionError)=\"imageError($event)\" *ngIf=\"supplyPlanDetail.leftImage\"\n                [src]=\"supplyPlanDetail.leftImage\" [alt]=\"supplyPlanDetail.leftTrack\" class=\"other-image\">\n              </ion-img>\n              <div *ngIf=\"!supplyPlanDetail.leftImage\" class=\"other-image-no border\">无</div>\n              <ion-label color=\"medium\">{{supplyPlanDetail.leftTrack}}</ion-label>\n            </div>\n            <div class=\"flex flex-column ion-justify-content-center ion-align-items-center\">\n              <ion-img (ionError)=\"imageError($event)\" *ngIf=\"supplyPlanDetail.goodsImage\"\n                [src]=\"supplyPlanDetail.goodsImage\" [alt]=\"supplyPlanDetail.goodsTrack\">\n              </ion-img>\n              <ion-label style=\"margin-bottom: 5px;font-weight: bold;\">\n                {{supplyPlanDetail.goodsTrack}}\n                <ion-badge *ngIf=\"supplyPlanDetail.trackType === 1\" style=\"font-size: 12px;font-weight: normal;\"\n                (click)=\"openMatTrack(supplyPlanDetails.matId, supplyPlanDetail.trackCode, supplyPlanDetail.goodsTrack)\">打开格子</ion-badge>\n              </ion-label>\n            </div>\n            <div class=\"flex flex-column ion-justify-content-center ion-align-items-center gray-fliter\">\n              <ion-img (ionError)=\"imageError($event)\" *ngIf=\"supplyPlanDetail.rightImage\"\n                [src]=\"supplyPlanDetail.rightImage\" [alt]=\"supplyPlanDetail.rightTrack\" class=\"other-image\">\n              </ion-img>\n              <div *ngIf=\"!supplyPlanDetail.rightImage\" class=\"other-image-no border\">无</div>\n              <ion-label color=\"medium\">{{supplyPlanDetail.rightTrack}}</ion-label>\n            </div>\n          </div>\n\n          <div style=\"background: #ffce005e;padding: 0px 10px;\">\n            <div class=\"flex ion-justify-content-between ion-align-items-center content-line\">\n              <ion-text class=\"m-r-5\">\n                最大:{{supplyPlanDetail.maxNumber|| '-'}}{{' ' + supplyPlanDetail.goodsUnit}}</ion-text>\n              <ion-label [color]=\"genStatusColor(supplyPlanDetail.planDetailsStatus)\">\n                {{genStatusName(supplyPlanDetail.planDetailsStatus)}}</ion-label>\n            </div>\n\n            <div class=\"flex ion-justify-content-start ion-align-items-center content-line-title m-t-5\">\n              <ion-label>\n                <ion-text class=\"text-large\" (yswClickStop)=\"copyGoodsName(supplyPlanDetail.goodsName)\">\n                  {{supplyPlanDetail.brandName || ''}} {{supplyPlanDetail.goodsName | stringSecurity}}\n                </ion-text>\n              </ion-label>\n              <ion-label><small class=\"ion-text-lowercase\">{{supplyPlanDetail.goodsPackage}}</small></ion-label>\n              <ion-label><small>{{supplyPlanDetail.mfrName}}</small></ion-label>\n            </div>\n\n            <div class=\"flex ion-justify-content-between ion-align-items-center content-line\">\n              <ion-text>原库存:\n                {{supplyPlanDetail.originalNumber}}{{' ' + supplyPlanDetail.goodsUnit}}\n              </ion-text>\n              <ion-text>补了:\n                {{supplyPlanDetail.supplyNumber}}{{' ' + supplyPlanDetail.goodsUnit}}\n              </ion-text>\n            </div>\n\n            <div class=\"flex ion-justify-content-between ion-align-items-center content-line\">\n              <ion-text>批号:\n                {{supplyPlanDetail.batchNo|| '-'}}\n              </ion-text>\n              <ion-text>效期:\n                {{supplyPlanDetail.expireDate| date: 'yyyy-MM-dd'}}\n              </ion-text>\n            </div>\n\n            <div *ngIf=\"supplyPlanDetail.comments\"\n              class=\"flex ion-justify-content-between ion-align-items-center content-line\">\n              <ion-label color=\"danger\">验证失败原因：{{supplyPlanDetail.comments}}</ion-label>\n            </div>\n          </div>\n        </ion-card-content>\n        <ion-card-content\n          *ngIf=\"!supplyPlanDetails.supplyPlanDetails || supplyPlanDetails.supplyPlanDetails.length===0\">\n          <div class=\"flex ion-justify-content-center ion-align-items-center content-line\">\n            <ion-text>没有数据</ion-text>\n          </div>\n        </ion-card-content>\n      </ion-card>\n    </ion-list>\n  </skeleton>\n\n  <!-- 已完成后不能上传照片 -->\n  <ion-button color=\"ysw\" slot=\"fixed\" (click)=\"uploadImage()\" class=\"supply-image-upload\">\n    <ion-icon name=\"images-outline\"></ion-icon>\n  </ion-button>\n</ion-content>");

/***/ }),

/***/ "./src/app/pages/supply-plan-detail/supply-plan-detail.module.ts":
/*!***********************************************************************!*\
  !*** ./src/app/pages/supply-plan-detail/supply-plan-detail.module.ts ***!
  \***********************************************************************/
/*! exports provided: SupplyPlanDetailPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SupplyPlanDetailPageModule", function() { return SupplyPlanDetailPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm2015/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
/* harmony import */ var _supply_plan_detail_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./supply-plan-detail.page */ "./src/app/pages/supply-plan-detail/supply-plan-detail.page.ts");
/* harmony import */ var _module_index__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../module/index */ "./src/app/pages/module/index.ts");








let SupplyPlanDetailPageModule = class SupplyPlanDetailPageModule {
};
SupplyPlanDetailPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"],
            _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild([
                {
                    path: '',
                    component: _supply_plan_detail_page__WEBPACK_IMPORTED_MODULE_6__["SupplyPlanDetailPage"]
                }, {
                    path: 'mat/track',
                    loadChildren: () => Promise.all(/*! import() | mat-track-mat-track-module */[__webpack_require__.e("common"), __webpack_require__.e("mat-track-mat-track-module")]).then(__webpack_require__.bind(null, /*! ../mat-track/mat-track.module */ "./src/app/pages/mat-track/mat-track.module.ts")).then(m => m.MatTrackPageModule)
                }
            ]),
            _module_index__WEBPACK_IMPORTED_MODULE_7__["EmptyModule"],
            _module_index__WEBPACK_IMPORTED_MODULE_7__["SkeletonModule"],
            _module_index__WEBPACK_IMPORTED_MODULE_7__["SplitLabelModule"],
            _module_index__WEBPACK_IMPORTED_MODULE_7__["StringSecurityModule"],
            _module_index__WEBPACK_IMPORTED_MODULE_7__["StopPropagationModule"]
        ],
        declarations: [_supply_plan_detail_page__WEBPACK_IMPORTED_MODULE_6__["SupplyPlanDetailPage"]]
    })
], SupplyPlanDetailPageModule);



/***/ }),

/***/ "./src/app/pages/supply-plan-detail/supply-plan-detail.page.scss":
/*!***********************************************************************!*\
  !*** ./src/app/pages/supply-plan-detail/supply-plan-detail.page.scss ***!
  \***********************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".supply-image-upload {\n  bottom: calc(var(--ion-safe-area-bottom, 0px) + 70px);\n  right: 20px;\n  width: 45px;\n  height: 45px;\n  --border-radius: 50%;\n  --padding-start: 10px;\n  --padding-end: 10px;\n  --box-shadow: rgba(0, 0, 0, 0.12) 0px 4px 16px 0px;\n}\n.supply-image-upload ion-icon {\n  font-size: 2em;\n}\n.image-list {\n  overflow-x: auto;\n  overflow-y: hidden;\n  margin-top: 6px;\n}\n.image-list::-webkit-scrollbar {\n  display: none;\n}\n.some-images {\n  --border-radius: 6px;\n  --size: 60px;\n  flex-shrink: 0;\n}\n.other-image {\n  width: 60px;\n  height: 60px;\n}\n.other-image-no {\n  width: 60px;\n  height: 60px;\n  text-align: center;\n  line-height: 60px;\n  border-radius: 6px;\n  color: var(--ion-color-light-shade);\n}\n.gray-fliter {\n  filter: grayscale(100%);\n  -moz-filter: grayscale(100%);\n  -o-filter: grayscale(100%);\n  -webkit-filter: grayscale(1);\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Vc2Vycy9jaGFubmluZy9EZXNrdG9wL3lzdy1hcHAtc2VydmljZTQvc3JjL2FwcC9wYWdlcy9zdXBwbHktcGxhbi1kZXRhaWwvc3VwcGx5LXBsYW4tZGV0YWlsLnBhZ2Uuc2NzcyIsInNyYy9hcHAvcGFnZXMvc3VwcGx5LXBsYW4tZGV0YWlsL3N1cHBseS1wbGFuLWRldGFpbC5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSxxREFBQTtFQUNBLFdBQUE7RUFDQSxXQUFBO0VBQ0EsWUFBQTtFQUNBLG9CQUFBO0VBQ0EscUJBQUE7RUFDQSxtQkFBQTtFQUNBLGtEQUFBO0FDQ0Y7QURDRTtFQUNFLGNBQUE7QUNDSjtBREVBO0VBQ0UsZ0JBQUE7RUFDQSxrQkFBQTtFQUNBLGVBQUE7QUNDRjtBRENBO0VBQ0UsYUFBQTtBQ0VGO0FEQUE7RUFDRSxvQkFBQTtFQUNBLFlBQUE7RUFDQSxjQUFBO0FDR0Y7QUREQTtFQUNFLFdBQUE7RUFDQSxZQUFBO0FDSUY7QURGQTtFQUNFLFdBQUE7RUFDQSxZQUFBO0VBQ0Esa0JBQUE7RUFDQSxpQkFBQTtFQUNBLGtCQUFBO0VBQ0EsbUNBQUE7QUNLRjtBREhBO0VBQ0UsdUJBQUE7RUFDQSw0QkFBQTtFQUNBLDBCQUFBO0VBQ0EsNEJBQUE7QUNNRiIsImZpbGUiOiJzcmMvYXBwL3BhZ2VzL3N1cHBseS1wbGFuLWRldGFpbC9zdXBwbHktcGxhbi1kZXRhaWwucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLnN1cHBseS1pbWFnZS11cGxvYWQge1xuICBib3R0b206IGNhbGModmFyKC0taW9uLXNhZmUtYXJlYS1ib3R0b20sIDBweCkgKyA3MHB4KTtcbiAgcmlnaHQ6IDIwcHg7XG4gIHdpZHRoOiA0NXB4O1xuICBoZWlnaHQ6IDQ1cHg7XG4gIC0tYm9yZGVyLXJhZGl1czogNTAlO1xuICAtLXBhZGRpbmctc3RhcnQ6IDEwcHg7XG4gIC0tcGFkZGluZy1lbmQ6IDEwcHg7XG4gIC0tYm94LXNoYWRvdzogcmdiYSgwLCAwLCAwLCAwLjEyKSAwcHggNHB4IDE2cHggMHB4O1xuXG4gIGlvbi1pY29uIHtcbiAgICBmb250LXNpemU6IDJlbTtcbiAgfVxufVxuLmltYWdlLWxpc3Qge1xuICBvdmVyZmxvdy14OiBhdXRvO1xuICBvdmVyZmxvdy15OiBoaWRkZW47XG4gIG1hcmdpbi10b3A6IDZweDtcbn1cbi5pbWFnZS1saXN0Ojotd2Via2l0LXNjcm9sbGJhciB7XG4gIGRpc3BsYXk6IG5vbmU7XG59XG4uc29tZS1pbWFnZXMge1xuICAtLWJvcmRlci1yYWRpdXM6IDZweDtcbiAgLS1zaXplOiA2MHB4O1xuICBmbGV4LXNocmluazogMDtcbn1cbi5vdGhlci1pbWFnZSB7XG4gIHdpZHRoOiA2MHB4O1xuICBoZWlnaHQ6IDYwcHg7XG59XG4ub3RoZXItaW1hZ2Utbm8ge1xuICB3aWR0aDogNjBweDtcbiAgaGVpZ2h0OiA2MHB4O1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gIGxpbmUtaGVpZ2h0OiA2MHB4O1xuICBib3JkZXItcmFkaXVzOiA2cHg7XG4gIGNvbG9yOiB2YXIoLS1pb24tY29sb3ItbGlnaHQtc2hhZGUpO1xufVxuLmdyYXktZmxpdGVyIHtcbiAgZmlsdGVyOiBncmF5c2NhbGUoMTAwJSk7XG4gIC1tb3otZmlsdGVyOiBncmF5c2NhbGUoMTAwJSk7XG4gIC1vLWZpbHRlcjogZ3JheXNjYWxlKDEwMCUpO1xuICAtd2Via2l0LWZpbHRlcjogZ3JheXNjYWxlKDEpO1xufVxuIiwiLnN1cHBseS1pbWFnZS11cGxvYWQge1xuICBib3R0b206IGNhbGModmFyKC0taW9uLXNhZmUtYXJlYS1ib3R0b20sIDBweCkgKyA3MHB4KTtcbiAgcmlnaHQ6IDIwcHg7XG4gIHdpZHRoOiA0NXB4O1xuICBoZWlnaHQ6IDQ1cHg7XG4gIC0tYm9yZGVyLXJhZGl1czogNTAlO1xuICAtLXBhZGRpbmctc3RhcnQ6IDEwcHg7XG4gIC0tcGFkZGluZy1lbmQ6IDEwcHg7XG4gIC0tYm94LXNoYWRvdzogcmdiYSgwLCAwLCAwLCAwLjEyKSAwcHggNHB4IDE2cHggMHB4O1xufVxuLnN1cHBseS1pbWFnZS11cGxvYWQgaW9uLWljb24ge1xuICBmb250LXNpemU6IDJlbTtcbn1cblxuLmltYWdlLWxpc3Qge1xuICBvdmVyZmxvdy14OiBhdXRvO1xuICBvdmVyZmxvdy15OiBoaWRkZW47XG4gIG1hcmdpbi10b3A6IDZweDtcbn1cblxuLmltYWdlLWxpc3Q6Oi13ZWJraXQtc2Nyb2xsYmFyIHtcbiAgZGlzcGxheTogbm9uZTtcbn1cblxuLnNvbWUtaW1hZ2VzIHtcbiAgLS1ib3JkZXItcmFkaXVzOiA2cHg7XG4gIC0tc2l6ZTogNjBweDtcbiAgZmxleC1zaHJpbms6IDA7XG59XG5cbi5vdGhlci1pbWFnZSB7XG4gIHdpZHRoOiA2MHB4O1xuICBoZWlnaHQ6IDYwcHg7XG59XG5cbi5vdGhlci1pbWFnZS1ubyB7XG4gIHdpZHRoOiA2MHB4O1xuICBoZWlnaHQ6IDYwcHg7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgbGluZS1oZWlnaHQ6IDYwcHg7XG4gIGJvcmRlci1yYWRpdXM6IDZweDtcbiAgY29sb3I6IHZhcigtLWlvbi1jb2xvci1saWdodC1zaGFkZSk7XG59XG5cbi5ncmF5LWZsaXRlciB7XG4gIGZpbHRlcjogZ3JheXNjYWxlKDEwMCUpO1xuICAtbW96LWZpbHRlcjogZ3JheXNjYWxlKDEwMCUpO1xuICAtby1maWx0ZXI6IGdyYXlzY2FsZSgxMDAlKTtcbiAgLXdlYmtpdC1maWx0ZXI6IGdyYXlzY2FsZSgxKTtcbn0iXX0= */");

/***/ }),

/***/ "./src/app/pages/supply-plan-detail/supply-plan-detail.page.ts":
/*!*********************************************************************!*\
  !*** ./src/app/pages/supply-plan-detail/supply-plan-detail.page.ts ***!
  \*********************************************************************/
/*! exports provided: SupplyPlanDetailPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SupplyPlanDetailPage", function() { return SupplyPlanDetailPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _components_index__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../components/index */ "./src/app/components/index.ts");
/* harmony import */ var _service_index__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../service/index */ "./src/app/service/index.ts");
/* harmony import */ var _service_mat_cab_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../service/mat.cab.service */ "./src/app/service/mat.cab.service.ts");
/* harmony import */ var _supply_list_supply_list_page__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../supply-list/supply-list.page */ "./src/app/pages/supply-list/supply-list.page.ts");
/* harmony import */ var _modal_image_upload_image_upload_page__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../modal/image-upload/image-upload.page */ "./src/app/pages/modal/image-upload/image-upload.page.ts");
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! moment */ "./node_modules/moment/moment.js");
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(moment__WEBPACK_IMPORTED_MODULE_9__);










let SupplyPlanDetailPage = class SupplyPlanDetailPage {
    constructor(activeRoute, router, commonUtils, nativeUtils, navCtrl, modalCtrl, matService, matCabService, supplyList) {
        this.activeRoute = activeRoute;
        this.router = router;
        this.commonUtils = commonUtils;
        this.nativeUtils = nativeUtils;
        this.navCtrl = navCtrl;
        this.modalCtrl = modalCtrl;
        this.matService = matService;
        this.matCabService = matCabService;
        this.supplyList = supplyList;
        this.loading = true;
        this.supplyPlanDetails = {};
        this.supplyImages = [];
        this.imageUploadNow = [];
        this.activeRoute.queryParams.subscribe((params) => {
            if (!this.commonUtils.isNullOrEmptyString(params.planId)) {
                this.planId = params.planId;
            }
            else {
                this.commonUtils.showToast('补货计划Id不能为空！');
                this.navCtrl.pop();
            }
        });
    }
    ngOnInit() {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            this.supplyPlanDetails = yield this.loadSupplyPlanDetails();
            this.loading = false;
            this.supplyImages = yield this.loadSupplyPlanImages();
        });
    }
    loadSupplyPlanDetails() {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            // const loading = this.commonUtils.showLoading();
            const data = yield this.matService.getMatSupplyPlanDetails(this.planId);
            // this.commonUtils.hideLoadingSync(loading);
            return data;
        });
    }
    loadSupplyPlanImages() {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            const data = yield this.matService.getMatSupplyPlanImages(this.planId);
            return data;
        });
    }
    onSupply() {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            if (this.supplyImages.length <= 0 && this.imageUploadNow.length <= 0) {
                this.commonUtils.showToast('请至少先上传一张补货照片!');
                return;
            }
            const loading = this.commonUtils.showLoading('正在提交补货到售药机...');
            yield this.matService.finishMatSupplyPlan(this.supplyPlanDetails.planId);
            this.commonUtils.hideLoadingSync(loading);
            // refresh data
            this.supplyPlanDetails = yield this.loadSupplyPlanDetails();
        });
    }
    uploadImage() {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            const modal = yield this.modalCtrl.create({
                component: _modal_image_upload_image_upload_page__WEBPACK_IMPORTED_MODULE_8__["ImageUploadPage"],
                componentProps: {
                    mainImageText: '货盘整体照片'
                },
                cssClass: 'ysw-upload-image-vertical',
                swipeToClose: true
            });
            yield modal.present();
            const { data } = yield modal.onWillDismiss();
            if (!this.commonUtils.isNull(data) && data.images.length > 0) {
                // upload images to server
                const loading = this.commonUtils.showLoading('正在上传照片...');
                const images = [];
                data.images.forEach(image => {
                    images.push({
                        fileUrl: image.url.replace(/^data:image\/(jpeg|png|gif|jpg);base64,/, ''),
                        name: moment__WEBPACK_IMPORTED_MODULE_9__().format('YYYY-MM-DD HH:mm:ss')
                    });
                });
                yield this.matService.uploadMatSupplyPlanImages(images, this.supplyPlanDetails.planId);
                this.commonUtils.hideLoadingSync(loading);
                this.imageUploadNow = data.images;
            }
        });
    }
    gotoMatTrack() {
        this.router.navigate(['../mat/track'], {
            relativeTo: this.activeRoute,
            queryParams: {
                matName: Base64.encode(this.supplyPlanDetails.matName),
                matId: this.supplyPlanDetails.matId,
                matNo: this.supplyPlanDetails.matSerial,
                hideActions: 1
            }
        });
    }
    previewImage(url) {
        this.nativeUtils.imageViewer(url);
    }
    copyMatSupplyPlanNumber(matSupplyPlanNumber) {
        this.supplyList.copyMatSupplyPlanNumber(matSupplyPlanNumber);
    }
    genLabelColor(status) {
        return this.supplyList.genLabelColor(status);
    }
    genLabelName(status) {
        return this.supplyList.genLabelName(status);
    }
    genStatusName(status) {
        const case0 = [-1, 0];
        const case1 = [1, 2, 3, 4, 5, 6];
        if (case0.includes(this.supplyPlanDetails.status)) {
            switch (status) {
                case 0: return '未验证';
                default: return '-';
            }
        }
        else if (case1.includes(this.supplyPlanDetails.status)) {
            switch (status) {
                case 0: return '通过';
                default: return '验证失败';
            }
        }
    }
    genStatusColor(status) {
        const case0 = [-1, 0];
        const case1 = [1, 2, 3, 4, 5, 6];
        if (case0.includes(this.supplyPlanDetails.status)) {
            switch (status) {
                case 0: return 'medium';
                default: return '';
            }
        }
        else if (case1.includes(this.supplyPlanDetails.status)) {
            switch (status) {
                case 0: return 'success';
                default: return 'danger';
            }
        }
    }
    imageError(event) {
        event.target.src = 'assets/imgs/mat/goods-no-image.svg';
    }
    copyGoodsName(goodsName) {
        this.nativeUtils.copyToClipboard(goodsName);
    }
    openMatTrack(matId, trackCode, goodsTrack) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            if (yield this.commonUtils.showConfirm('温馨提示', '确定要打开：' + goodsTrack + '号格子？')) {
                const data = yield this.matCabService.openMatTrack(matId, trackCode);
                if (data.success) {
                    this.commonUtils.showToast('打开成功！');
                }
                else {
                    this.commonUtils.showToast(data.message);
                }
            }
        });
    }
};
SupplyPlanDetailPage.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_3__["ActivatedRoute"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"] },
    { type: _components_index__WEBPACK_IMPORTED_MODULE_4__["CommonUtils"] },
    { type: _components_index__WEBPACK_IMPORTED_MODULE_4__["NativeUtils"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["NavController"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ModalController"] },
    { type: _service_index__WEBPACK_IMPORTED_MODULE_5__["MatService"] },
    { type: _service_mat_cab_service__WEBPACK_IMPORTED_MODULE_6__["MatCabService"] },
    { type: _supply_list_supply_list_page__WEBPACK_IMPORTED_MODULE_7__["SupplyListPage"] }
];
SupplyPlanDetailPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-supply-plan-detail',
        template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./supply-plan-detail.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/supply-plan-detail/supply-plan-detail.page.html")).default,
        providers: [_service_index__WEBPACK_IMPORTED_MODULE_5__["MatService"], _supply_list_supply_list_page__WEBPACK_IMPORTED_MODULE_7__["SupplyListPage"], _service_mat_cab_service__WEBPACK_IMPORTED_MODULE_6__["MatCabService"]],
        styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./supply-plan-detail.page.scss */ "./src/app/pages/supply-plan-detail/supply-plan-detail.page.scss")).default]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_3__["ActivatedRoute"],
        _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"],
        _components_index__WEBPACK_IMPORTED_MODULE_4__["CommonUtils"],
        _components_index__WEBPACK_IMPORTED_MODULE_4__["NativeUtils"],
        _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["NavController"],
        _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ModalController"],
        _service_index__WEBPACK_IMPORTED_MODULE_5__["MatService"],
        _service_mat_cab_service__WEBPACK_IMPORTED_MODULE_6__["MatCabService"],
        _supply_list_supply_list_page__WEBPACK_IMPORTED_MODULE_7__["SupplyListPage"]])
], SupplyPlanDetailPage);



/***/ })

}]);
//# sourceMappingURL=supply-plan-detail-supply-plan-detail-module-es2015.js.map