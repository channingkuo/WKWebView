function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["default~ticket-change-goods-ticket-change-goods-module~ticket-detail-ticket-detail-module"], {
  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/ticket-detail/ticket-detail.page.html":
  /*!***************************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/ticket-detail/ticket-detail.page.html ***!
    \***************************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppPagesTicketDetailTicketDetailPageHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-header>\n  <ion-toolbar color=\"ysw\">\n    <ion-buttons slot=\"start\">\n      <ion-back-button></ion-back-button>\n    </ion-buttons>\n    <ion-title>{{ticketId ? '工单详情' : '新工单'}}</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <ion-header collapse=\"condense\">\n    <ion-toolbar color=\"ysw\">\n      <ion-title size=\"large\">{{ticketId ? '工单详情' : '新工单'}}</ion-title>\n    </ion-toolbar>\n  </ion-header>\n\n  <ion-list>\n    <card-swap [editing]=\"editing\" [disabled]=\"!ticketId\" (switch)=\"onEditMainTicket($event)\">\n      <div slot=\"front\">\n        <ion-card>\n          <ion-card-header>\n            <ion-card-title class=\"flex ion-justify-content-between ion-align-items-center\">\n              <ion-label>\n                {{ticketData.ticket_no}}\n                <ion-icon (click)=\"copyOrderNumber(ticketData.ticket_no)\" style=\"font-size: 0.7em;margin-left: 2px;\"\n                  name=\"copy-outline\">\n                </ion-icon>\n              </ion-label>\n              <ion-badge [color]=\"genStatusColor(ticketData.ticket_status)\">\n                {{genStatusName(ticketData.ticket_status)}}\n              </ion-badge>\n            </ion-card-title>\n            <ion-card-subtitle>\n              <ion-label>{{ticketData.mat_name}} <small>{{ticketData.external_no}}</small></ion-label>\n            </ion-card-subtitle>\n          </ion-card-header>\n          <ion-card-content>\n            <div class=\"flex ion-justify-content-between ion-align-items-center content-line\">\n              <ion-label>工单类型：</ion-label>\n              <ion-label [color]=\"genTicketTypeColor(ticketData.ticket_type)\">{{genTicketType(ticketData.ticket_type)}}\n              </ion-label>\n            </div>\n            <div class=\"flex ion-justify-content-between ion-align-items-center content-line\">\n              <ion-label>工单主题：</ion-label>\n              <ion-label>{{ticketData.ticket_subject}}</ion-label>\n            </div>\n            <div class=\"flex ion-justify-content-between ion-align-items-center content-line\">\n              <ion-label>工单描述：</ion-label>\n              <ion-label>{{ticketData.description || '-'}}</ion-label>\n            </div>\n            <collaspe-line>\n              <div class=\"flex ion-justify-content-between ion-align-items-center content-line\">\n                <ion-label>负责人员：</ion-label>\n                <ion-label>{{ticketData.owner_name || '-'}}</ion-label>\n              </div>\n              <div class=\"flex ion-justify-content-between ion-align-items-center content-line\">\n                <ion-label>创建人员：</ion-label>\n                <ion-label>{{ticketData.created_by_name}}</ion-label>\n              </div>\n              <div class=\"flex ion-justify-content-between ion-align-items-center content-line\">\n                <ion-label>创建时间：</ion-label>\n                <ion-label>{{ticketData.created_date| date: 'yyyy-MM-dd HH:mm:ss'}}</ion-label>\n              </div>\n              <div class=\"flex ion-justify-content-between ion-align-items-center content-line\">\n                <ion-label>修改人员：</ion-label>\n                <ion-label>{{ticketData.updated_by_name}}</ion-label>\n              </div>\n              <div class=\"flex ion-justify-content-between ion-align-items-center content-line\">\n                <ion-label>最近修改：</ion-label>\n                <ion-label>{{ticketData.updated_date| date: 'yyyy-MM-dd HH:mm:ss'}}</ion-label>\n              </div>\n            </collaspe-line>\n\n            <div class=\"b-b-split\"></div>\n\n            <div *ngIf=\"ticketData.ticket_status <= 1 && !isStorePriv\" class=\"text-center m-t-10\">\n              <ion-button *ngIf=\"ticketData.ticket_status === 0\" (click)=\"setTicketPadding()\" fill=\"outline\"\n                expand=\"block\" color=\"danger\">\n                设置成处理中\n              </ion-button>\n              <ion-button *ngIf=\"ticketData.ticket_status === 1\" (click)=\"setTicketFinished()\" fill=\"outline\"\n                expand=\"block\" color=\"danger\">\n                处理完成\n              </ion-button>\n            </div>\n          </ion-card-content>\n        </ion-card>\n      </div>\n      <div slot=\"back\">\n        <ion-card>\n          <ion-card-header>\n            <ion-card-title class=\"flex ion-justify-content-between ion-align-items-center\">\n              <ion-label>{{ticketData.ticket_no || '请填写下列内容'}}</ion-label>\n              <ion-badge [color]=\"genStatusColor(ticketData.ticket_status)\">\n                {{genStatusName(ticketData.ticket_status)}}\n              </ion-badge>\n            </ion-card-title>\n          </ion-card-header>\n\n          <ion-card-content style=\"padding: 0;\">\n            <ion-item (click)=\"onChooseMat()\" button detail>\n              <ion-label class=\"flex ion-justify-content-start ion-align-items-center\">\n                关联售药机\n                <ion-label color=\"danger\">*</ion-label>：\n                <ion-label *ngIf=\"ticketData.mat_id\">{{ticketData.mat_name}}</ion-label>\n                <ion-label *ngIf=\"!ticketData.mat_id\" style=\"color: #9a9a9a;\">请选择售药机</ion-label>\n              </ion-label>\n            </ion-item>\n            <ion-item>\n              <ion-label class=\"flex ion-justify-content-start ion-align-items-center\">\n                工单主题\n                <ion-label color=\"danger\">*</ion-label>：\n              </ion-label>\n              <ion-input [(ngModel)]=\"ticketData.ticket_subject\" clearInput type=\"text\" placeholder=\"请填写工单主题\"\n                style=\"margin-left: 5px;\"></ion-input>\n            </ion-item>\n            <ion-item>\n              <ion-label>工单描述：</ion-label>\n              <ion-textarea [(ngModel)]=\"ticketData.description\" placeholder=\"请填写工单描述内容\" style=\"margin-left: 12px;\">\n              </ion-textarea>\n            </ion-item>\n            <ion-item (click)=\"onChooseType()\" button detail>\n              <ion-label class=\"flex ion-justify-content-start ion-align-items-center\">\n                工单类型\n                <ion-label color=\"danger\">*</ion-label>：\n                <ion-label *ngIf=\"ticketData.ticket_type\" style=\"margin-left: 12px;\">\n                  {{genTicketType(ticketData.ticket_type)}}</ion-label>\n                <ion-label *ngIf=\"!ticketData.ticket_type\" style=\"margin-left: 12px;color: #9a9a9a;\">请选择工单类型</ion-label>\n              </ion-label>\n            </ion-item>\n            <ion-item *ngIf=\"ticketId\" (click)=\"onChooseOwner()\" button detail>\n              <ion-label class=\"flex ion-justify-content-start ion-align-items-center\">\n                负责人\n                <ion-label color=\"danger\">*</ion-label>：\n                <ion-label *ngIf=\"ticketData.owner_id\" style=\"margin-left: 25px;\">{{ticketData.owner_name}}</ion-label>\n                <ion-label *ngIf=\"!ticketData.owner_id\" style=\"margin-left: 25px;color: #9a9a9a;\">请选择工单负责人</ion-label>\n              </ion-label>\n            </ion-item>\n            <!--\n            <ion-item disabled>\n              <ion-label class=\"flex ion-justify-content-start ion-align-items-center\">\n                工单状态\n                <ion-label color=\"danger\">*</ion-label>：\n                {{genStatusName(ticketData.ticket_status)}}\n              </ion-label>\n            </ion-item>\n            <ion-item disabled>\n              <ion-label class=\"ion-text-wrap\">\n                创建人：{{(ticketData.created_by_name || '-') + ' @ ' }}{{ticketData.created_date| date: 'yyyy-MM-dd HH:mm:ss'}}\n              </ion-label>\n            </ion-item>\n            <ion-item disabled>\n              <ion-label class=\"ion-text-wrap\">\n                修改人：{{(ticketData.updated_by_name || '-') + ' @ ' }}{{ticketData.updated_date| date: 'yyyy-MM-dd HH:mm:ss'}}\n              </ion-label>\n            </ion-item>\n            -->\n            <div class=\"action-buttons flex ion-justify-content-around ion-align-items-center\">\n              <ion-button class=\"w-45p\" size=\"small\" (click)=\"onReset()\" expand=\"block\" color=\"medium\">重 置</ion-button>\n              <ion-button class=\"w-45p\" size=\"small\" (click)=\"onSaveTicket()\" expand=\"block\" color=\"ysw\">保 存\n              </ion-button>\n            </div>\n          </ion-card-content>\n        </ion-card>\n      </div>\n    </card-swap>\n\n    <ng-container [ngSwitch]=\"ticketData.ticket_type\">\n      <ng-container *ngSwitchCase=\"3\">\n        <ion-card>\n          <split-label class=\"\">新建商品列表</split-label>\n\n          <ion-icon *ngIf=\"goodsList.length > 0 && ticketData.ticket_status === 0\" (click)=\"addNewGoods()\"\n            class=\"add-change-goods-icon\" color=\"dark\" name=\"add-outline\">\n          </ion-icon>\n          <ion-card-content class=\"m-t-5\" style=\"padding: 0;\">\n            <ng-container *ngFor=\"let goods of goodsList;index as i;\">\n              <ion-item-sliding>\n                <ion-item class=\"change-goods-scroll\">\n                  \n                  <ion-thumbnail item-start>\n                    <img [src]=\"goods.new_image\" />\n                  </ion-thumbnail>\n\n                  <ion-label (click)=\"viewNewGoods(goods)\" class=\"text-large\" style=\"margin-left: 10px;\">\n                    {{goods.new_goods_brand}} {{goods.new_goods_name}}\n                    \n                    <ion-label style=\"font-size: 13px;\">\n                      {{goods.new_goods_package}}\n                    </ion-label>\n                    <ion-label style=\"font-size: 13px;\">\n                      {{goods.new_goods_mfr}}\n                    </ion-label>\n                  </ion-label>\n                </ion-item>\n\n                <ion-item-options side=\"end\">\n                  <!--\n                  <ion-item-option color=\"primary\" (click)=\"viewNewGoods(goods, i)\">修改</ion-item-option>\n                  -->\n                  <ion-item-option color=\"danger\" (click)=\"onDelete(goods, i)\">删除</ion-item-option>\n                </ion-item-options>\n              </ion-item-sliding>\n            </ng-container>\n\n            <div (click)=\"addNewGoods()\" *ngIf=\"ticketData.ticket_status !== 2\" style=\"margin: 20px 10px 10px 10px;\"\n              class=\"add-change-goods flex flex-column ion-justify-content-center ion-align-items-center\">\n              <ion-icon name=\"add-outline\"></ion-icon>\n              <ion-label>点击新建商品</ion-label>\n            </div>\n          </ion-card-content>\n        </ion-card>\n      </ng-container>\n      <ng-container *ngSwitchCase=\"1\">\n        <ion-card>\n          <split-label class=\"\">更换商品列表</split-label>\n\n          <ion-icon *ngIf=\"goodsList.length > 0 && ticketData.ticket_status === 0\" (click)=\"addChangeGoods()\"\n            class=\"add-change-goods-icon\" color=\"dark\" name=\"add-outline\">\n          </ion-icon>\n          <ion-card-content class=\"m-t-5\" style=\"padding: 0;\">\n            <ng-container *ngFor=\"let goods of goodsList;index as i;\">\n              <ion-item-sliding>\n                <ion-item lines=\"none\"\n                  class=\"change-goods-scroll flex ion-justify-content-between ion-align-items-center\">\n                  <ion-label (click)=\"viewTrack(goods)\" class=\"text-large\">{{goods.goods_track}}</ion-label>\n\n                  <ion-label (click)=\"viewChangeGoods(goods)\">\n                    <ion-thumbnail class=\"change-goods-thumb\">\n                      <img [src]=\"goods.goods_thumb\" />\n                    </ion-thumbnail>\n                  </ion-label>\n\n                  <ion-label (click)=\"viewChangeGoods(goods)\"\n                    class=\"flex ion-justify-content-center ion-align-items-center\">\n                    <ion-icon class=\"text-large\" name=\"swap-horizontal-outline\"></ion-icon>\n                  </ion-label>\n\n                  <ion-label (click)=\"viewChangeGoods(goods)\">\n                    <ion-thumbnail class=\"change-goods-thumb\">\n                      <img [src]=\"goods.target_goods_thumb\" />\n                    </ion-thumbnail>\n                  </ion-label>\n                </ion-item>\n\n                <ion-item-options side=\"end\">\n                  <ion-item-option color=\"primary\" (click)=\"onEdit(goods, i)\">修改</ion-item-option>\n                  <ion-item-option color=\"danger\" (click)=\"onDelete(goods, i)\">删除</ion-item-option>\n                </ion-item-options>\n              </ion-item-sliding>\n            </ng-container>\n\n            <div (click)=\"addChangeGoods()\" *ngIf=\"ticketData.ticket_status !== 2\" style=\"margin: 20px 10px 10px 10px;\"\n              class=\"add-change-goods flex flex-column ion-justify-content-center ion-align-items-center\">\n              <ion-icon name=\"add-outline\"></ion-icon>\n              <ion-label>点击添加需更换的商品</ion-label>\n            </div>\n          </ion-card-content>\n        </ion-card>\n      </ng-container>\n      <ng-container *ngSwitchCase=\"2\">\n        <ion-card>\n          <!-- <ion-card-header>\n            <ion-card-title>\n              abc——机器异常\n            </ion-card-title>\n            <ion-card-subtitle>\n              abc\n            </ion-card-subtitle>\n          </ion-card-header> -->\n          <ion-card-content style=\"padding: 15px;\">\n            <div class=\"add-change-goods flex ion-justify-content-center ion-align-items-center\">\n              <ion-label>机器警报暂时请在PC上新建</ion-label>\n            </div>\n          </ion-card-content>\n        </ion-card>\n      </ng-container>\n      <!--\n      <ng-container *ngSwitchDefault>\n        <ion-card>\n          <ion-card-content>\n            <div class=\"add-change-goods flex ion-justify-content-center ion-align-items-center\"\n              style=\"padding-top: 10px;\">\n              <ion-label>请先选择工单类型</ion-label>\n            </div>\n          </ion-card-content>\n        </ion-card>\n      </ng-container>-->\n    </ng-container>\n  </ion-list>\n</ion-content>";
    /***/
  },

  /***/
  "./src/app/pages/ticket-detail/ticket-detail.page.scss":
  /*!*************************************************************!*\
    !*** ./src/app/pages/ticket-detail/ticket-detail.page.scss ***!
    \*************************************************************/

  /*! exports provided: default */

  /***/
  function srcAppPagesTicketDetailTicketDetailPageScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = ".add-change-goods {\n  border: 0.55px dashed var(--ion-color-medium-tint);\n  padding: 2px 0 10px 0;\n  border-radius: 10px;\n  font-size: 13px;\n}\n.add-change-goods ion-icon {\n  font-size: 2em;\n  color: var(--ion-color-medium-tint);\n}\n.add-change-goods ion-label {\n  color: var(--ion-color-medium-tint);\n}\n.add-change-goods:active {\n  background-color: var(--ion-color-light);\n}\n.change-goods-scroll {\n  overflow-x: auto;\n  overflow-y: hidden;\n}\n.change-goods-card {\n  position: relative;\n  overflow: visible;\n  margin-top: 0;\n}\n.add-change-goods-icon {\n  position: absolute;\n  right: 4px;\n  top: -28px;\n  font-size: 2em;\n}\n.change-goods-scroll::-webkit-scrollbar {\n  display: none !important;\n}\n.change-goods-thumb {\n  --size: 60px;\n  --border-radius: 6px;\n  border-radius: 6px;\n  border: 0.55px solid var(--ion-color-light);\n  flex-shrink: 0;\n}\n.action-buttons {\n  padding: 15px;\n}\n.action-buttons ion-button {\n  height: 36px;\n}\nion-item-options {\n  border-bottom-width: 0px !important;\n}\nion-item-option {\n  font-size: 14px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Vc2Vycy9jaGFubmluZy9EZXNrdG9wL3lzdy1hcHAtc2VydmljZTQvc3JjL2FwcC9wYWdlcy90aWNrZXQtZGV0YWlsL3RpY2tldC1kZXRhaWwucGFnZS5zY3NzIiwic3JjL2FwcC9wYWdlcy90aWNrZXQtZGV0YWlsL3RpY2tldC1kZXRhaWwucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0Usa0RBQUE7RUFDQSxxQkFBQTtFQUNBLG1CQUFBO0VBQ0EsZUFBQTtBQ0NGO0FEQ0U7RUFDRSxjQUFBO0VBQ0EsbUNBQUE7QUNDSjtBRENFO0VBQ0UsbUNBQUE7QUNDSjtBREVBO0VBQ0Usd0NBQUE7QUNDRjtBRENBO0VBQ0UsZ0JBQUE7RUFDQSxrQkFBQTtBQ0VGO0FEQUE7RUFDRSxrQkFBQTtFQUNBLGlCQUFBO0VBQ0EsYUFBQTtBQ0dGO0FEREE7RUFDRSxrQkFBQTtFQUNBLFVBQUE7RUFDQSxVQUFBO0VBQ0EsY0FBQTtBQ0lGO0FERkE7RUFDRSx3QkFBQTtBQ0tGO0FESEE7RUFDRSxZQUFBO0VBQ0Esb0JBQUE7RUFDQSxrQkFBQTtFQUNBLDJDQUFBO0VBQ0EsY0FBQTtBQ01GO0FESEE7RUFDRSxhQUFBO0FDTUY7QURKQTtFQUNFLFlBQUE7QUNPRjtBRExBO0VBQ0UsbUNBQUE7QUNRRjtBRE5BO0VBQ0UsZUFBQTtBQ1NGIiwiZmlsZSI6InNyYy9hcHAvcGFnZXMvdGlja2V0LWRldGFpbC90aWNrZXQtZGV0YWlsLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5hZGQtY2hhbmdlLWdvb2RzIHtcbiAgYm9yZGVyOiAwLjU1cHggZGFzaGVkIHZhcigtLWlvbi1jb2xvci1tZWRpdW0tdGludCk7XG4gIHBhZGRpbmc6IDJweCAwIDEwcHggMDtcbiAgYm9yZGVyLXJhZGl1czogMTBweDtcbiAgZm9udC1zaXplOiAxM3B4O1xuXG4gIGlvbi1pY29uIHtcbiAgICBmb250LXNpemU6IDJlbTtcbiAgICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLW1lZGl1bS10aW50KTtcbiAgfVxuICBpb24tbGFiZWwge1xuICAgIGNvbG9yOiB2YXIoLS1pb24tY29sb3ItbWVkaXVtLXRpbnQpO1xuICB9XG59XG4uYWRkLWNoYW5nZS1nb29kczphY3RpdmUge1xuICBiYWNrZ3JvdW5kLWNvbG9yOiB2YXIoLS1pb24tY29sb3ItbGlnaHQpO1xufVxuLmNoYW5nZS1nb29kcy1zY3JvbGwge1xuICBvdmVyZmxvdy14OiBhdXRvO1xuICBvdmVyZmxvdy15OiBoaWRkZW47XG59XG4uY2hhbmdlLWdvb2RzLWNhcmQge1xuICBwb3NpdGlvbjogcmVsYXRpdmU7XG4gIG92ZXJmbG93OiB2aXNpYmxlO1xuICBtYXJnaW4tdG9wOiAwO1xufVxuLmFkZC1jaGFuZ2UtZ29vZHMtaWNvbiB7XG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgcmlnaHQ6IDRweDtcbiAgdG9wOiAtMjhweDtcbiAgZm9udC1zaXplOiAyZW07XG59XG4uY2hhbmdlLWdvb2RzLXNjcm9sbDo6LXdlYmtpdC1zY3JvbGxiYXIge1xuICBkaXNwbGF5OiBub25lICFpbXBvcnRhbnQ7XG59XG4uY2hhbmdlLWdvb2RzLXRodW1iIHtcbiAgLS1zaXplOiA2MHB4O1xuICAtLWJvcmRlci1yYWRpdXM6IDZweDtcbiAgYm9yZGVyLXJhZGl1czogNnB4O1xuICBib3JkZXI6IDAuNTVweCBzb2xpZCB2YXIoLS1pb24tY29sb3ItbGlnaHQpO1xuICBmbGV4LXNocmluazogMDtcbn1cblxuLmFjdGlvbi1idXR0b25zIHtcbiAgcGFkZGluZzogMTVweDtcbn1cbi5hY3Rpb24tYnV0dG9ucyBpb24tYnV0dG9uIHtcbiAgaGVpZ2h0OiAzNnB4O1xufVxuaW9uLWl0ZW0tb3B0aW9ucyB7XG4gIGJvcmRlci1ib3R0b20td2lkdGg6IDBweCAhaW1wb3J0YW50O1xufVxuaW9uLWl0ZW0tb3B0aW9uIHtcbiAgZm9udC1zaXplOiAxNHB4O1xufSIsIi5hZGQtY2hhbmdlLWdvb2RzIHtcbiAgYm9yZGVyOiAwLjU1cHggZGFzaGVkIHZhcigtLWlvbi1jb2xvci1tZWRpdW0tdGludCk7XG4gIHBhZGRpbmc6IDJweCAwIDEwcHggMDtcbiAgYm9yZGVyLXJhZGl1czogMTBweDtcbiAgZm9udC1zaXplOiAxM3B4O1xufVxuLmFkZC1jaGFuZ2UtZ29vZHMgaW9uLWljb24ge1xuICBmb250LXNpemU6IDJlbTtcbiAgY29sb3I6IHZhcigtLWlvbi1jb2xvci1tZWRpdW0tdGludCk7XG59XG4uYWRkLWNoYW5nZS1nb29kcyBpb24tbGFiZWwge1xuICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLW1lZGl1bS10aW50KTtcbn1cblxuLmFkZC1jaGFuZ2UtZ29vZHM6YWN0aXZlIHtcbiAgYmFja2dyb3VuZC1jb2xvcjogdmFyKC0taW9uLWNvbG9yLWxpZ2h0KTtcbn1cblxuLmNoYW5nZS1nb29kcy1zY3JvbGwge1xuICBvdmVyZmxvdy14OiBhdXRvO1xuICBvdmVyZmxvdy15OiBoaWRkZW47XG59XG5cbi5jaGFuZ2UtZ29vZHMtY2FyZCB7XG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcbiAgb3ZlcmZsb3c6IHZpc2libGU7XG4gIG1hcmdpbi10b3A6IDA7XG59XG5cbi5hZGQtY2hhbmdlLWdvb2RzLWljb24ge1xuICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gIHJpZ2h0OiA0cHg7XG4gIHRvcDogLTI4cHg7XG4gIGZvbnQtc2l6ZTogMmVtO1xufVxuXG4uY2hhbmdlLWdvb2RzLXNjcm9sbDo6LXdlYmtpdC1zY3JvbGxiYXIge1xuICBkaXNwbGF5OiBub25lICFpbXBvcnRhbnQ7XG59XG5cbi5jaGFuZ2UtZ29vZHMtdGh1bWIge1xuICAtLXNpemU6IDYwcHg7XG4gIC0tYm9yZGVyLXJhZGl1czogNnB4O1xuICBib3JkZXItcmFkaXVzOiA2cHg7XG4gIGJvcmRlcjogMC41NXB4IHNvbGlkIHZhcigtLWlvbi1jb2xvci1saWdodCk7XG4gIGZsZXgtc2hyaW5rOiAwO1xufVxuXG4uYWN0aW9uLWJ1dHRvbnMge1xuICBwYWRkaW5nOiAxNXB4O1xufVxuXG4uYWN0aW9uLWJ1dHRvbnMgaW9uLWJ1dHRvbiB7XG4gIGhlaWdodDogMzZweDtcbn1cblxuaW9uLWl0ZW0tb3B0aW9ucyB7XG4gIGJvcmRlci1ib3R0b20td2lkdGg6IDBweCAhaW1wb3J0YW50O1xufVxuXG5pb24taXRlbS1vcHRpb24ge1xuICBmb250LXNpemU6IDE0cHg7XG59Il19 */";
    /***/
  },

  /***/
  "./src/app/pages/ticket-detail/ticket-detail.page.ts":
  /*!***********************************************************!*\
    !*** ./src/app/pages/ticket-detail/ticket-detail.page.ts ***!
    \***********************************************************/

  /*! exports provided: TicketDetailPage */

  /***/
  function srcAppPagesTicketDetailTicketDetailPageTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "TicketDetailPage", function () {
      return TicketDetailPage;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _service_index__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! ../../service/index */
    "./src/app/service/index.ts");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
    /* harmony import */


    var _components_index__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ../../components/index */
    "./src/app/components/index.ts");
    /* harmony import */


    var _ticket_list_ticket_list_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ../ticket-list/ticket-list.page */
    "./src/app/pages/ticket-list/ticket-list.page.ts");
    /* harmony import */


    var _modal_mat_select_mat_select_page__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
    /*! ../modal/mat-select/mat-select.page */
    "./src/app/pages/modal/mat-select/mat-select.page.ts");
    /* harmony import */


    var _modal_user_select_user_select_page__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(
    /*! ../modal/user-select/user-select.page */
    "./src/app/pages/modal/user-select/user-select.page.ts");
    /* harmony import */


    var _modal_ticket_goods_swap_ticket_goods_swap_page__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(
    /*! ../modal/ticket-goods-swap/ticket-goods-swap.page */
    "./src/app/pages/modal/ticket-goods-swap/ticket-goods-swap.page.ts");
    /* harmony import */


    var _modal_new_goods_new_goods_page__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(
    /*! ../modal/new-goods/new-goods.page */
    "./src/app/pages/modal/new-goods/new-goods.page.ts");

    var TicketDetailPage = /*#__PURE__*/function () {
      function TicketDetailPage(ticketService, activeRoute, router, modalCtrl, nativeUtils, ticketListPage, commonUtils, storageUtils, actionSheetCtrl) {
        var _this = this;

        _classCallCheck(this, TicketDetailPage);

        this.ticketService = ticketService;
        this.activeRoute = activeRoute;
        this.router = router;
        this.modalCtrl = modalCtrl;
        this.nativeUtils = nativeUtils;
        this.ticketListPage = ticketListPage;
        this.commonUtils = commonUtils;
        this.storageUtils = storageUtils;
        this.actionSheetCtrl = actionSheetCtrl;
        this.editing = false;
        this.ticketData = {};
        this.goodsList = [];
        this.matAlertList = [];
        this.isStorePriv = false;
        this.activeRoute.queryParams.subscribe(function (params) {
          if (!_this.commonUtils.isNullOrEmptyString(params.ticketId)) {
            _this.ticketId = params.ticketId;
          }

          if (!_this.commonUtils.isNullOrEmptyString(params.editing)) {
            _this.editing = params.editing && params.editing === 'true';
          }
        }); // 处理子页面返回刷新当前页面

        var refresh = this.storageUtils.get(_components_index__WEBPACK_IMPORTED_MODULE_5__["ProjectConstant"].STORAGE_KEY_REFRESH);

        if (refresh) {
          setTimeout(function () {
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](_this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
              return regeneratorRuntime.wrap(function _callee$(_context) {
                while (1) {
                  switch (_context.prev = _context.next) {
                    case 0:
                      if (!(this.ticketData.ticket_type === _components_index__WEBPACK_IMPORTED_MODULE_5__["ProjectConstant"].TICKET_CHANGE_GOODS || this.ticketData.ticket_type === _components_index__WEBPACK_IMPORTED_MODULE_5__["ProjectConstant"].TICKET_NEW_GOODS)) {
                        _context.next = 4;
                        break;
                      }

                      _context.next = 3;
                      return this.loadTicketExChangeGoodsList();

                    case 3:
                      this.goodsList = _context.sent;

                    case 4:
                    case "end":
                      return _context.stop();
                  }
                }
              }, _callee, this);
            }));
          }, 1000);
        }

        this.userInfo = this.storageUtils.get(_components_index__WEBPACK_IMPORTED_MODULE_5__["ProjectConstant"].STORAGE_KEY_USERINFO);

        if (this.userInfo.role === 'Service' && (this.userInfo.type === _components_index__WEBPACK_IMPORTED_MODULE_5__["ProjectConstant"].AGENT_STORE || this.userInfo.type === _components_index__WEBPACK_IMPORTED_MODULE_5__["ProjectConstant"].AGENT_STORE_HEADER)) {
          this.isStorePriv = true;
        }
      }

      _createClass(TicketDetailPage, [{
        key: "ngOnInit",
        value: function ngOnInit() {
          return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee2() {
            return regeneratorRuntime.wrap(function _callee2$(_context2) {
              while (1) {
                switch (_context2.prev = _context2.next) {
                  case 0:
                    if (this.commonUtils.isNullOrEmptyString(this.ticketId)) {
                      _context2.next = 11;
                      break;
                    }

                    _context2.next = 3;
                    return this.loadTicketData();

                  case 3:
                    this.ticketData = _context2.sent;

                    if (!(this.ticketData.ticket_type === _components_index__WEBPACK_IMPORTED_MODULE_5__["ProjectConstant"].TICKET_CHANGE_GOODS || this.ticketData.ticket_type === _components_index__WEBPACK_IMPORTED_MODULE_5__["ProjectConstant"].TICKET_NEW_GOODS)) {
                      _context2.next = 10;
                      break;
                    }

                    _context2.next = 7;
                    return this.loadTicketExChangeGoodsList();

                  case 7:
                    this.goodsList = _context2.sent;
                    _context2.next = 11;
                    break;

                  case 10:
                    if (this.ticketData.ticket_type === _components_index__WEBPACK_IMPORTED_MODULE_5__["ProjectConstant"].TICKET_MAT_ALERT) {
                      console.log('获取关联警报！');
                    }

                  case 11:
                  case "end":
                    return _context2.stop();
                }
              }
            }, _callee2, this);
          }));
        }
      }, {
        key: "loadTicketData",
        value: function loadTicketData() {
          return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee3() {
            var loading, data;
            return regeneratorRuntime.wrap(function _callee3$(_context3) {
              while (1) {
                switch (_context3.prev = _context3.next) {
                  case 0:
                    loading = this.commonUtils.showLoading();
                    _context3.next = 3;
                    return this.ticketService.ticketDetail(this.ticketId);

                  case 3:
                    data = _context3.sent;
                    this.commonUtils.hideLoadingSync(loading);
                    return _context3.abrupt("return", data);

                  case 6:
                  case "end":
                    return _context3.stop();
                }
              }
            }, _callee3, this);
          }));
        }
      }, {
        key: "loadTicketExChangeGoodsList",
        value: function loadTicketExChangeGoodsList(ticketId) {
          return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee4() {
            var data;
            return regeneratorRuntime.wrap(function _callee4$(_context4) {
              while (1) {
                switch (_context4.prev = _context4.next) {
                  case 0:
                    _context4.next = 2;
                    return this.ticketService.ticketExChangeGoodsList(ticketId || this.ticketId);

                  case 2:
                    data = _context4.sent;
                    return _context4.abrupt("return", data);

                  case 4:
                  case "end":
                    return _context4.stop();
                }
              }
            }, _callee4, this);
          }));
        }
      }, {
        key: "onEditMainTicket",
        value: function onEditMainTicket(editing) {
          return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee5() {
            return regeneratorRuntime.wrap(function _callee5$(_context5) {
              while (1) {
                switch (_context5.prev = _context5.next) {
                  case 0:
                    if (editing) {
                      _context5.next = 4;
                      break;
                    }

                    _context5.next = 3;
                    return this.loadTicketData();

                  case 3:
                    this.ticketData = _context5.sent;

                  case 4:
                  case "end":
                    return _context5.stop();
                }
              }
            }, _callee5, this);
          }));
        }
      }, {
        key: "onReset",
        value: function onReset() {
          return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee6() {
            var res;
            return regeneratorRuntime.wrap(function _callee6$(_context6) {
              while (1) {
                switch (_context6.prev = _context6.next) {
                  case 0:
                    _context6.next = 2;
                    return this.commonUtils.showConfirm('确认', '是否确定放弃修改部分？');

                  case 2:
                    res = _context6.sent;

                    if (!res) {
                      _context6.next = 11;
                      break;
                    }

                    if (this.commonUtils.isNullOrEmptyString(this.ticketId)) {
                      _context6.next = 10;
                      break;
                    }

                    _context6.next = 7;
                    return this.loadTicketData();

                  case 7:
                    this.ticketData = _context6.sent;
                    _context6.next = 11;
                    break;

                  case 10:
                    this.ticketData = {};

                  case 11:
                  case "end":
                    return _context6.stop();
                }
              }
            }, _callee6, this);
          }));
        }
      }, {
        key: "onSaveTicket",
        value: function onSaveTicket() {
          return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee7() {
            var _this2 = this;

            var loading, savedTicket;
            return regeneratorRuntime.wrap(function _callee7$(_context7) {
              while (1) {
                switch (_context7.prev = _context7.next) {
                  case 0:
                    this.ticketData.owner_id = 16;

                    if (!this.commonUtils.isNull(this.ticketData.mat_id)) {
                      _context7.next = 4;
                      break;
                    }

                    this.commonUtils.showToast('请选择关联售药机！');
                    return _context7.abrupt("return");

                  case 4:
                    if (!this.commonUtils.isNullOrEmptyString(this.ticketData.ticket_subject)) {
                      _context7.next = 7;
                      break;
                    }

                    this.commonUtils.showToast('请填写工单主题！');
                    return _context7.abrupt("return");

                  case 7:
                    if (!this.commonUtils.isNull(this.ticketData.ticket_type)) {
                      _context7.next = 10;
                      break;
                    }

                    this.commonUtils.showToast('请选择工单类型！');
                    return _context7.abrupt("return");

                  case 10:
                    if (!this.commonUtils.isNull(this.ticketData.owner_id)) {
                      _context7.next = 13;
                      break;
                    }

                    this.commonUtils.showToast('请选择工单负责人！');
                    return _context7.abrupt("return");

                  case 13:
                    loading = this.commonUtils.showLoading('正在提交...');
                    _context7.next = 16;
                    return this.ticketService.saveTicketData(this.ticketData);

                  case 16:
                    savedTicket = _context7.sent;
                    this.ticketId = savedTicket.id;
                    this.commonUtils.hideLoadingSync(loading);
                    _context7.next = 21;
                    return this.loadTicketData();

                  case 21:
                    this.ticketData = _context7.sent;
                    setTimeout(function () {
                      _this2.cardSwapComponent.close();
                    }, 500);

                  case 23:
                  case "end":
                    return _context7.stop();
                }
              }
            }, _callee7, this);
          }));
        }
      }, {
        key: "addChangeGoods",
        value: function addChangeGoods() {
          return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee8() {
            var modal, _ref, data, payload;

            return regeneratorRuntime.wrap(function _callee8$(_context8) {
              while (1) {
                switch (_context8.prev = _context8.next) {
                  case 0:
                    if (!(this.ticketData.ticket_status !== 0)) {
                      _context8.next = 3;
                      break;
                    }

                    this.commonUtils.showToast('请先点击“保存”按钮再来添加跟换商品！');
                    return _context8.abrupt("return");

                  case 3:
                    _context8.next = 5;
                    return this.modalCtrl.create({
                      component: _modal_ticket_goods_swap_ticket_goods_swap_page__WEBPACK_IMPORTED_MODULE_9__["TicketGoodsSwapPage"],
                      componentProps: {
                        matId: this.ticketData.mat_id
                      },
                      swipeToClose: true
                    });

                  case 5:
                    modal = _context8.sent;
                    _context8.next = 8;
                    return modal.present();

                  case 8:
                    _context8.next = 10;
                    return modal.onWillDismiss();

                  case 10:
                    _ref = _context8.sent;
                    data = _ref.data;

                    if (this.commonUtils.isNull(data)) {
                      _context8.next = 19;
                      break;
                    }

                    payload = Object.assign({}, data);
                    _context8.next = 16;
                    return this.saveTicketGoods(payload);

                  case 16:
                    _context8.next = 18;
                    return this.loadTicketExChangeGoodsList();

                  case 18:
                    this.goodsList = _context8.sent;

                  case 19:
                  case "end":
                    return _context8.stop();
                }
              }
            }, _callee8, this);
          }));
        }
      }, {
        key: "saveTicketGoods",
        value: function saveTicketGoods(data) {
          return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee9() {
            var payload, loading;
            return regeneratorRuntime.wrap(function _callee9$(_context9) {
              while (1) {
                switch (_context9.prev = _context9.next) {
                  case 0:
                    payload = Object.assign({}, data);

                    if (payload.new_image) {
                      payload.new_image = payload.new_image.replace(/^data:image\/(jpeg|png|gif|jpg);base64,/, '');
                    }

                    if (payload.new_image1) {
                      payload.new_image1 = payload.new_image1.replace(/^data:image\/(jpeg|png|gif|jpg);base64,/, '');
                    }

                    if (payload.new_image2) {
                      payload.new_image2 = payload.new_image2.replace(/^data:image\/(jpeg|png|gif|jpg);base64,/, '');
                    }

                    loading = this.commonUtils.showLoading('正在提交...');
                    payload.ticket_id = this.ticketId;
                    _context9.next = 8;
                    return this.ticketService.saveTicketGoods(payload);

                  case 8:
                    this.commonUtils.hideLoadingSync(loading);

                  case 9:
                  case "end":
                    return _context9.stop();
                }
              }
            }, _callee9, this);
          }));
        }
      }, {
        key: "onChooseMat",
        value: function onChooseMat() {
          return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee10() {
            var modal, _ref2, data;

            return regeneratorRuntime.wrap(function _callee10$(_context10) {
              while (1) {
                switch (_context10.prev = _context10.next) {
                  case 0:
                    if (!(this.goodsList.length > 0)) {
                      _context10.next = 3;
                      break;
                    }

                    this.commonUtils.showAlert('警告', null, '替换商品删除后才能调整关联售药机！');
                    return _context10.abrupt("return");

                  case 3:
                    _context10.next = 5;
                    return this.modalCtrl.create({
                      component: _modal_mat_select_mat_select_page__WEBPACK_IMPORTED_MODULE_7__["MatSelectPage"],
                      componentProps: {
                        selected: {
                          name: this.ticketData.mat_name,
                          id: this.ticketData.mat_id
                        }
                      },
                      cssClass: 'ysw-common-modal-vertical',
                      swipeToClose: true
                    });

                  case 5:
                    modal = _context10.sent;
                    _context10.next = 8;
                    return modal.present();

                  case 8:
                    _context10.next = 10;
                    return modal.onWillDismiss();

                  case 10:
                    _ref2 = _context10.sent;
                    data = _ref2.data;

                    if (!this.commonUtils.isNull(data) && !this.commonUtils.isNull(data.id)) {
                      this.ticketData.mat_name = data.name;
                      this.ticketData.mat_id = data.id;
                    }

                  case 13:
                  case "end":
                    return _context10.stop();
                }
              }
            }, _callee10, this);
          }));
        }
      }, {
        key: "onChooseType",
        value: function onChooseType() {
          return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee11() {
            var _this3 = this;

            var buttons, actionSheet;
            return regeneratorRuntime.wrap(function _callee11$(_context11) {
              while (1) {
                switch (_context11.prev = _context11.next) {
                  case 0:
                    buttons = [{
                      text: '跟换商品',
                      cssClass: 'ysw-action-sheet',
                      handler: function handler() {
                        if (_this3.ticketData.ticket_type !== 1 && _this3.matAlertList.length > 0) {
                          _this3.commonUtils.showAlert('警告', null, '关联的机器警报删除后才能调整工单类型！');
                        } else {
                          _this3.ticketData.ticket_type = 1;
                        }
                      }
                    }, {
                      text: '新建商品',
                      cssClass: 'ysw-action-sheet',
                      handler: function handler() {
                        if (_this3.ticketData.ticket_type !== 3 && (_this3.goodsList.length > 3 || _this3.matAlertList.length > 3)) {
                          _this3.commonUtils.showAlert('警告', null, '关联警报及商品删除后才能调整工单类型！');
                        } else {
                          _this3.ticketData.ticket_type = 3;
                        }
                      }
                    }, {
                      text: '机器警报',
                      cssClass: 'ysw-action-sheet',
                      handler: function handler() {
                        if (_this3.ticketData.ticket_type !== 2 && _this3.goodsList.length > 0) {
                          _this3.commonUtils.showAlert('警告', null, '替换商品删除后才能调整工单类型！');
                        } else {
                          _this3.ticketData.ticket_type = 2;
                        }
                      }
                    }, {
                      text: '取消',
                      cssClass: 'ysw-action-sheet',
                      role: 'cancel',
                      handler: function handler() {}
                    }];
                    _context11.next = 3;
                    return this.actionSheetCtrl.create({
                      header: '工单类型',
                      buttons: buttons
                    });

                  case 3:
                    actionSheet = _context11.sent;
                    _context11.next = 6;
                    return actionSheet.present();

                  case 6:
                  case "end":
                    return _context11.stop();
                }
              }
            }, _callee11, this);
          }));
        }
      }, {
        key: "onChooseOwner",
        value: function onChooseOwner() {
          return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee12() {
            var modal, _ref3, data;

            return regeneratorRuntime.wrap(function _callee12$(_context12) {
              while (1) {
                switch (_context12.prev = _context12.next) {
                  case 0:
                    _context12.next = 2;
                    return this.modalCtrl.create({
                      component: _modal_user_select_user_select_page__WEBPACK_IMPORTED_MODULE_8__["UserSelectPage"],
                      componentProps: {},
                      cssClass: 'ysw-common-modal-vertical',
                      swipeToClose: true
                    });

                  case 2:
                    modal = _context12.sent;
                    _context12.next = 5;
                    return modal.present();

                  case 5:
                    _context12.next = 7;
                    return modal.onWillDismiss();

                  case 7:
                    _ref3 = _context12.sent;
                    data = _ref3.data;

                    if (!this.commonUtils.isNull(data) && !this.commonUtils.isNull(data.id)) {
                      this.ticketData.owner_name = data.realName;
                      this.ticketData.owner_id = data.id;
                    }

                  case 10:
                  case "end":
                    return _context12.stop();
                }
              }
            }, _callee12, this);
          }));
        }
      }, {
        key: "viewTrack",
        value: function viewTrack(goods) {
          return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee13() {
            return regeneratorRuntime.wrap(function _callee13$(_context13) {
              while (1) {
                switch (_context13.prev = _context13.next) {
                  case 0:
                    this.router.navigate(['tabs/home/mat/track'], {
                      queryParams: {
                        matName: Base64.encode(this.ticketData.mat_name),
                        matId: this.ticketData.mat_id,
                        query: goods.goods_track
                      }
                    });

                  case 1:
                  case "end":
                    return _context13.stop();
                }
              }
            }, _callee13, this);
          }));
        }
      }, {
        key: "viewChangeGoods",
        value: function viewChangeGoods(goods) {
          return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee14() {
            var modal, _ref4, data, payload;

            return regeneratorRuntime.wrap(function _callee14$(_context14) {
              while (1) {
                switch (_context14.prev = _context14.next) {
                  case 0:
                    _context14.next = 2;
                    return this.modalCtrl.create({
                      component: _modal_ticket_goods_swap_ticket_goods_swap_page__WEBPACK_IMPORTED_MODULE_9__["TicketGoodsSwapPage"],
                      componentProps: {
                        ticketGoods: Object.assign({}, goods),
                        matId: this.ticketData.mat_id
                      },
                      swipeToClose: true
                    });

                  case 2:
                    modal = _context14.sent;
                    _context14.next = 5;
                    return modal.present();

                  case 5:
                    _context14.next = 7;
                    return modal.onWillDismiss();

                  case 7:
                    _ref4 = _context14.sent;
                    data = _ref4.data;

                    if (this.commonUtils.isNull(data)) {
                      _context14.next = 16;
                      break;
                    }

                    payload = Object.assign({}, data);
                    _context14.next = 13;
                    return this.saveTicketGoods(payload);

                  case 13:
                    _context14.next = 15;
                    return this.loadTicketExChangeGoodsList();

                  case 15:
                    this.goodsList = _context14.sent;

                  case 16:
                  case "end":
                    return _context14.stop();
                }
              }
            }, _callee14, this);
          }));
        }
      }, {
        key: "setTicketPadding",
        value: function setTicketPadding() {
          return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee15() {
            var res, loading;
            return regeneratorRuntime.wrap(function _callee15$(_context15) {
              while (1) {
                switch (_context15.prev = _context15.next) {
                  case 0:
                    _context15.next = 2;
                    return this.commonUtils.showConfirm('确认', '确定是否提交改工单？提交后无法修改数据！');

                  case 2:
                    res = _context15.sent;

                    if (!res) {
                      _context15.next = 11;
                      break;
                    }

                    loading = this.commonUtils.showLoading('正在提交...');
                    _context15.next = 7;
                    return this.ticketService.setTicketPendding(this.ticketData);

                  case 7:
                    this.commonUtils.hideLoadingSync(loading);
                    _context15.next = 10;
                    return this.loadTicketData();

                  case 10:
                    this.ticketData = _context15.sent;

                  case 11:
                  case "end":
                    return _context15.stop();
                }
              }
            }, _callee15, this);
          }));
        }
      }, {
        key: "setTicketFinished",
        value: function setTicketFinished() {
          return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee16() {
            var res, loading;
            return regeneratorRuntime.wrap(function _callee16$(_context16) {
              while (1) {
                switch (_context16.prev = _context16.next) {
                  case 0:
                    _context16.next = 2;
                    return this.commonUtils.showConfirm('确认', '确定把该工单标记为已完成？');

                  case 2:
                    res = _context16.sent;

                    if (!res) {
                      _context16.next = 11;
                      break;
                    }

                    loading = this.commonUtils.showLoading('正在提交...');
                    _context16.next = 7;
                    return this.ticketService.archiveTicket(this.ticketData.id);

                  case 7:
                    this.commonUtils.hideLoadingSync(loading);
                    _context16.next = 10;
                    return this.loadTicketData();

                  case 10:
                    this.ticketData = _context16.sent;

                  case 11:
                  case "end":
                    return _context16.stop();
                }
              }
            }, _callee16, this);
          }));
        }
      }, {
        key: "onEdit",
        value: function onEdit(goods, index) {
          return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee17() {
            var modal, _ref5, data, payload;

            return regeneratorRuntime.wrap(function _callee17$(_context17) {
              while (1) {
                switch (_context17.prev = _context17.next) {
                  case 0:
                    if (!this.checkCanEdit()) {
                      _context17.next = 20;
                      break;
                    }

                    _context17.next = 3;
                    return this.modalCtrl.create({
                      component: _modal_ticket_goods_swap_ticket_goods_swap_page__WEBPACK_IMPORTED_MODULE_9__["TicketGoodsSwapPage"],
                      componentProps: {
                        ticketGoods: Object.assign({}, goods),
                        matId: this.ticketData.mat_id
                      },
                      swipeToClose: true
                    });

                  case 3:
                    modal = _context17.sent;
                    _context17.next = 6;
                    return modal.present();

                  case 6:
                    _context17.next = 8;
                    return modal.onWillDismiss();

                  case 8:
                    _ref5 = _context17.sent;
                    data = _ref5.data;

                    if (this.commonUtils.isNull(data)) {
                      _context17.next = 18;
                      break;
                    }

                    payload = Object.assign({}, data);
                    _context17.next = 14;
                    return this.saveTicketGoods(payload);

                  case 14:
                    _context17.next = 16;
                    return this.loadTicketExChangeGoodsList(this.ticketId);

                  case 16:
                    this.goodsList = _context17.sent;
                    this.storageUtils.set(_components_index__WEBPACK_IMPORTED_MODULE_5__["ProjectConstant"].STORAGE_KEY_REFRESH, true);

                  case 18:
                    _context17.next = 21;
                    break;

                  case 20:
                    this.commonUtils.showToast('当前状态不可修改！');

                  case 21:
                  case "end":
                    return _context17.stop();
                }
              }
            }, _callee17, this);
          }));
        }
      }, {
        key: "onDelete",
        value: function onDelete(goods, index) {
          return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee18() {
            var res, loading;
            return regeneratorRuntime.wrap(function _callee18$(_context18) {
              while (1) {
                switch (_context18.prev = _context18.next) {
                  case 0:
                    if (!this.checkCanEdit()) {
                      _context18.next = 12;
                      break;
                    }

                    _context18.next = 3;
                    return this.commonUtils.showConfirm('确认', '确认删除该记录？');

                  case 3:
                    res = _context18.sent;

                    if (!res) {
                      _context18.next = 10;
                      break;
                    }

                    loading = this.commonUtils.showLoading('正在删除...');
                    _context18.next = 8;
                    return this.ticketService.deleteTicketGoods(goods);

                  case 8:
                    this.commonUtils.hideLoadingSync(loading);
                    this.goodsList.splice(index, 1);

                  case 10:
                    _context18.next = 13;
                    break;

                  case 12:
                    this.commonUtils.showToast('当前状态不可修改！');

                  case 13:
                  case "end":
                    return _context18.stop();
                }
              }
            }, _callee18, this);
          }));
        }
      }, {
        key: "genStatusColor",
        value: function genStatusColor(status) {
          return this.ticketListPage.genStatusColor(status);
        }
      }, {
        key: "genStatusName",
        value: function genStatusName(status) {
          return this.ticketListPage.genStatusName(status);
        }
      }, {
        key: "genTicketTypeColor",
        value: function genTicketTypeColor(type) {
          return this.ticketListPage.genTicketTypeColor(type);
        }
      }, {
        key: "genTicketType",
        value: function genTicketType(type) {
          return this.ticketListPage.genTicketType(type);
        }
      }, {
        key: "copyOrderNumber",
        value: function copyOrderNumber(ticketNo) {
          this.nativeUtils.copyToClipboard(ticketNo);
        }
      }, {
        key: "ngOnDestroy",
        value: function ngOnDestroy() {
          this.storageUtils.remove(_components_index__WEBPACK_IMPORTED_MODULE_5__["ProjectConstant"].STORAGE_KEY_REFRESH);
        }
      }, {
        key: "checkCanEdit",
        value: function checkCanEdit() {
          var canPopModal = false;

          if (this.ticketData.ticket_status === 0) {
            canPopModal = true;
          } else if (this.ticketData.ticket_status === 1) {
            canPopModal = this.userInfo.role === _components_index__WEBPACK_IMPORTED_MODULE_5__["ProjectConstant"].ROLE_SUPER_ADMIN || this.userInfo.role === _components_index__WEBPACK_IMPORTED_MODULE_5__["ProjectConstant"].ROLE_SERIVICE && (this.userInfo.type === _components_index__WEBPACK_IMPORTED_MODULE_5__["ProjectConstant"].AGENT_LEADER || this.userInfo.type === _components_index__WEBPACK_IMPORTED_MODULE_5__["ProjectConstant"].AGENT_STORE_HEADER);
          } else if (this.ticketData.ticket_status === 2) {
            canPopModal = false;
          }

          return canPopModal;
        }
      }, {
        key: "addNewGoods",
        value: function addNewGoods() {
          return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee19() {
            var modal, _ref6, data, payload;

            return regeneratorRuntime.wrap(function _callee19$(_context19) {
              while (1) {
                switch (_context19.prev = _context19.next) {
                  case 0:
                    _context19.next = 2;
                    return this.modalCtrl.create({
                      component: _modal_new_goods_new_goods_page__WEBPACK_IMPORTED_MODULE_10__["NewGoodsPage"],
                      componentProps: {},
                      swipeToClose: true
                    });

                  case 2:
                    modal = _context19.sent;
                    _context19.next = 5;
                    return modal.present();

                  case 5:
                    _context19.next = 7;
                    return modal.onWillDismiss();

                  case 7:
                    _ref6 = _context19.sent;
                    data = _ref6.data;

                    if (this.commonUtils.isNull(data)) {
                      _context19.next = 30;
                      break;
                    }

                    payload = Object.assign({}, data);
                    payload.new_goods_name = data.goodsName;
                    payload.new_goods_package = data.goodsPackage;
                    payload.new_goods_mfr = data.goodsMfr;
                    payload.new_approved_code = data.approvedCode;
                    payload.new_goods_brand = data.goodsBrand;
                    payload.new_bar_code = data.barCode;
                    payload.raw_goods_id = data.rawGoodsId;
                    payload.created_goods_id = data.createdGoodsId;
                    payload.goods_id = -1;
                    payload.goods_track = "0-0-0";
                    payload.ticket_id = this.ticketId;
                    payload.new_image = data.goodsImage;
                    payload.new_image1 = data.goodsImage1;
                    payload.new_image2 = data.goodsImage2;
                    _context19.next = 27;
                    return this.saveTicketGoods(payload);

                  case 27:
                    _context19.next = 29;
                    return this.loadTicketExChangeGoodsList();

                  case 29:
                    this.goodsList = _context19.sent;

                  case 30:
                  case "end":
                    return _context19.stop();
                }
              }
            }, _callee19, this);
          }));
        }
      }, {
        key: "viewNewGoods",
        value: function viewNewGoods(goods) {
          return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee20() {
            var modal;
            return regeneratorRuntime.wrap(function _callee20$(_context20) {
              while (1) {
                switch (_context20.prev = _context20.next) {
                  case 0:
                    goods.goodsName = goods.new_goods_name;
                    goods.goodsPackage = goods.new_goods_package;
                    goods.goodsMfr = goods.new_goods_mfr;
                    goods.approvedCode = goods.new_approved_code;
                    goods.goodsBrand = goods.new_goods_brand;
                    goods.barCode = goods.new_bar_code;
                    goods.rawGoodsId = goods.raw_goods_id;
                    goods.createdGoodsId = goods.created_goods_id;
                    goods.goodsImage = goods.new_image;
                    goods.goodsImage1 = goods.new_image1;
                    goods.goodsImage2 = goods.new_image2;
                    _context20.next = 13;
                    return this.modalCtrl.create({
                      component: _modal_new_goods_new_goods_page__WEBPACK_IMPORTED_MODULE_10__["NewGoodsPage"],
                      componentProps: {
                        goods: goods
                      },
                      swipeToClose: true
                    });

                  case 13:
                    modal = _context20.sent;
                    _context20.next = 16;
                    return modal.present();

                  case 16:
                  case "end":
                    return _context20.stop();
                }
              }
            }, _callee20, this);
          }));
        }
      }]);

      return TicketDetailPage;
    }();

    TicketDetailPage.ctorParameters = function () {
      return [{
        type: _service_index__WEBPACK_IMPORTED_MODULE_2__["TicketService"]
      }, {
        type: _angular_router__WEBPACK_IMPORTED_MODULE_3__["ActivatedRoute"]
      }, {
        type: _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["ModalController"]
      }, {
        type: _components_index__WEBPACK_IMPORTED_MODULE_5__["NativeUtils"]
      }, {
        type: _ticket_list_ticket_list_page__WEBPACK_IMPORTED_MODULE_6__["TicketListPage"]
      }, {
        type: _components_index__WEBPACK_IMPORTED_MODULE_5__["CommonUtils"]
      }, {
        type: _components_index__WEBPACK_IMPORTED_MODULE_5__["StorageUtils"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["ActionSheetController"]
      }];
    };

    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"])(_components_index__WEBPACK_IMPORTED_MODULE_5__["CardSwapComponent"], {
      static: true
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _components_index__WEBPACK_IMPORTED_MODULE_5__["CardSwapComponent"])], TicketDetailPage.prototype, "cardSwapComponent", void 0);
    TicketDetailPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-ticket-detail',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./ticket-detail.page.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/ticket-detail/ticket-detail.page.html")).default,
      providers: [_service_index__WEBPACK_IMPORTED_MODULE_2__["TicketService"], _ticket_list_ticket_list_page__WEBPACK_IMPORTED_MODULE_6__["TicketListPage"]],
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./ticket-detail.page.scss */
      "./src/app/pages/ticket-detail/ticket-detail.page.scss")).default]
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_service_index__WEBPACK_IMPORTED_MODULE_2__["TicketService"], _angular_router__WEBPACK_IMPORTED_MODULE_3__["ActivatedRoute"], _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["ModalController"], _components_index__WEBPACK_IMPORTED_MODULE_5__["NativeUtils"], _ticket_list_ticket_list_page__WEBPACK_IMPORTED_MODULE_6__["TicketListPage"], _components_index__WEBPACK_IMPORTED_MODULE_5__["CommonUtils"], _components_index__WEBPACK_IMPORTED_MODULE_5__["StorageUtils"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["ActionSheetController"]])], TicketDetailPage);
    /***/
  }
}]);
//# sourceMappingURL=default~ticket-change-goods-ticket-change-goods-module~ticket-detail-ticket-detail-module-es5.js.map