function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["supply-detail-supply-detail-module"], {
  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/supply-detail/supply-detail.page.html":
  /*!***************************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/supply-detail/supply-detail.page.html ***!
    \***************************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppPagesSupplyDetailSupplyDetailPageHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-header>\n  <ion-toolbar color=\"ysw\">\n    <ion-buttons slot=\"start\">\n      <ion-back-button></ion-back-button>\n    </ion-buttons>\n    <ion-title>补货单详情</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <ion-header collapse=\"condense\">\n    <ion-toolbar color=\"ysw\">\n      <ion-title size=\"large\">补货单详情</ion-title>\n    </ion-toolbar>\n  </ion-header>\n\n  <skeleton [loading]=\"loading\">\n    <ion-list>\n      <ion-card>\n        <ion-card-header>\n          <ion-card-title class=\"flex ion-justify-content-between ion-align-items-center\">\n            <ion-label>\n              {{supplyDetails.supplyNo}}\n              <ion-icon (yswClickStop)=\"copyMatSupplyNumber(supplyDetails.supplyNo)\" name=\"copy-outline\"></ion-icon>\n            </ion-label>\n          </ion-card-title>\n          <ion-card-subtitle>\n            <ion-label class=\"ion-text-wrap\">\n              {{supplyDetails.matName}} {{supplyDetails.matSerial}}\n            </ion-label>\n          </ion-card-subtitle>\n        </ion-card-header>\n        <ion-card-content>\n          <div *ngIf=\"supplyDetails.planNo\" class=\"flex ion-justify-content-between ion-align-items-center content-line\">\n            <ion-label color=\"dark\">补货计划：</ion-label>\n            <ion-label (yswClickStop)=\"viewSupplyPlan(supplyDetails.planId)\">{{supplyDetails.planNo}}</ion-label>\n          </div>\n          <div class=\"flex ion-justify-content-between ion-align-items-center content-line\">\n            <ion-label color=\"dark\">创建人员：</ion-label>\n            <ion-label>{{supplyDetails.createdBy}}</ion-label>\n          </div>\n          <div class=\"flex ion-justify-content-between ion-align-items-center content-line\">\n            <ion-label color=\"dark\">创建时间：</ion-label>\n            <ion-label>{{supplyDetails.createdDate| date: 'yyyy-MM-dd HH:mm:ss'}}</ion-label>\n          </div>\n        </ion-card-content>\n      </ion-card>\n      \n      <ion-card>\n        <split-label class=\"\">补货商品详情</split-label>\n        \n        <ion-card-content *ngFor=\"let supplyDetail of supplyDetails.supplyPlanDetails\">\n          \n          <div class=\"flex ion-justify-content-between ion-align-items-center content-line\">\n            <ion-label>\n              <ion-text class=\"text-large m-r-5\">{{supplyDetail.goodsTrack}}</ion-text>\n            </ion-label>\n          </div>\n          \n          <div class=\"flex ion-justify-content-start ion-align-items-center content-line-title\">\n            <ion-label>\n              <ion-text class=\"text-large\" (yswClickStop)=\"copyGoodsName(supplyDetail.goodsName)\">\n                {{supplyDetail.brandName || ''}} {{supplyDetail.goodsName | stringSecurity}}\n              </ion-text>\n              <small class=\"ion-text-lowercase\">{{supplyDetail.goodsPackage}}</small>\n            </ion-label>\n            <ion-label><small>{{supplyDetail.mfrName}}</small></ion-label>\n          </div>\n\n          <div class=\"flex ion-justify-content-between ion-align-items-center content-line\">\n            <ion-text>原数量: </ion-text>\n            <ion-label>              \n              {{supplyDetail.originalNumber}}{{' ' + supplyDetail.goodsUnit}}\n            </ion-label>\n          </div>\n\n          <div class=\"flex ion-justify-content-between ion-align-items-center content-line\">\n            <ion-text>补了: </ion-text>\n            <ion-label>{{supplyDetail.supplyNumber}}{{' ' + supplyDetail.goodsUnit}}</ion-label>\n          </div>\n\n          <div class=\"flex ion-justify-content-between ion-align-items-center content-line\">\n            <ion-text>补后数量: </ion-text>\n            <ion-label>{{supplyDetail.currentNumber}}{{' ' + supplyDetail.goodsUnit}}</ion-label>\n          </div>\n        \n          <div class=\"b-b-split\"></div>\n        </ion-card-content>\n      </ion-card>\n    </ion-list>\n  </skeleton>\n</ion-content>";
    /***/
  },

  /***/
  "./src/app/pages/supply-detail/supply-detail.module.ts":
  /*!*************************************************************!*\
    !*** ./src/app/pages/supply-detail/supply-detail.module.ts ***!
    \*************************************************************/

  /*! exports provided: SupplyDetailPageModule */

  /***/
  function srcAppPagesSupplyDetailSupplyDetailModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "SupplyDetailPageModule", function () {
      return SupplyDetailPageModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/fesm2015/common.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/fesm2015/forms.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
    /* harmony import */


    var _supply_detail_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ./supply-detail.page */
    "./src/app/pages/supply-detail/supply-detail.page.ts");
    /* harmony import */


    var _module_index__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
    /*! ../module/index */
    "./src/app/pages/module/index.ts");

    var SupplyDetailPageModule = function SupplyDetailPageModule() {
      _classCallCheck(this, SupplyDetailPageModule);
    };

    SupplyDetailPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"], _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild([{
        path: '',
        component: _supply_detail_page__WEBPACK_IMPORTED_MODULE_6__["SupplyDetailPage"]
      }, {
        path: 'plan/detail',
        loadChildren: function loadChildren() {
          return Promise.all(
          /*! import() | supply-plan-detail-supply-plan-detail-module */
          [__webpack_require__.e("common"), __webpack_require__.e("supply-plan-detail-supply-plan-detail-module")]).then(__webpack_require__.bind(null,
          /*! ../supply-plan-detail/supply-plan-detail.module */
          "./src/app/pages/supply-plan-detail/supply-plan-detail.module.ts")).then(function (m) {
            return m.SupplyPlanDetailPageModule;
          });
        }
      }]), _module_index__WEBPACK_IMPORTED_MODULE_7__["EmptyModule"], _module_index__WEBPACK_IMPORTED_MODULE_7__["SkeletonModule"], _module_index__WEBPACK_IMPORTED_MODULE_7__["SplitLabelModule"], _module_index__WEBPACK_IMPORTED_MODULE_7__["StringSecurityModule"], _module_index__WEBPACK_IMPORTED_MODULE_7__["StopPropagationModule"]],
      declarations: [_supply_detail_page__WEBPACK_IMPORTED_MODULE_6__["SupplyDetailPage"]]
    })], SupplyDetailPageModule);
    /***/
  },

  /***/
  "./src/app/pages/supply-detail/supply-detail.page.scss":
  /*!*************************************************************!*\
    !*** ./src/app/pages/supply-detail/supply-detail.page.scss ***!
    \*************************************************************/

  /*! exports provided: default */

  /***/
  function srcAppPagesSupplyDetailSupplyDetailPageScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3BhZ2VzL3N1cHBseS1kZXRhaWwvc3VwcGx5LWRldGFpbC5wYWdlLnNjc3MifQ== */";
    /***/
  },

  /***/
  "./src/app/pages/supply-detail/supply-detail.page.ts":
  /*!***********************************************************!*\
    !*** ./src/app/pages/supply-detail/supply-detail.page.ts ***!
    \***********************************************************/

  /*! exports provided: SupplyDetailPage */

  /***/
  function srcAppPagesSupplyDetailSupplyDetailPageTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "SupplyDetailPage", function () {
      return SupplyDetailPage;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");
    /* harmony import */


    var _components_index__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! ../../components/index */
    "./src/app/components/index.ts");
    /* harmony import */


    var _service_index__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ../../service/index */
    "./src/app/service/index.ts");
    /* harmony import */


    var _supply_list_supply_list_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ../supply-list/supply-list.page */
    "./src/app/pages/supply-list/supply-list.page.ts");

    var SupplyDetailPage = /*#__PURE__*/function () {
      function SupplyDetailPage(activeRoute, router, commonUtils, navCtrl, matService, nativeUtils, supplyList) {
        var _this = this;

        _classCallCheck(this, SupplyDetailPage);

        this.activeRoute = activeRoute;
        this.router = router;
        this.commonUtils = commonUtils;
        this.navCtrl = navCtrl;
        this.matService = matService;
        this.nativeUtils = nativeUtils;
        this.supplyList = supplyList;
        this.loading = true;
        this.supplyDetails = {};
        this.activeRoute.queryParams.subscribe(function (params) {
          if (!_this.commonUtils.isNullOrEmptyString(params.supplyId)) {
            _this.supplyId = params.supplyId;
          } else {
            _this.commonUtils.showToast('补货单Id不能为空！');

            _this.navCtrl.pop();
          }
        });
      }

      _createClass(SupplyDetailPage, [{
        key: "ngOnInit",
        value: function ngOnInit() {
          return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
            return regeneratorRuntime.wrap(function _callee$(_context) {
              while (1) {
                switch (_context.prev = _context.next) {
                  case 0:
                    _context.next = 2;
                    return this.loadSupplyDetails();

                  case 2:
                    this.supplyDetails = _context.sent;
                    this.loading = false;

                  case 4:
                  case "end":
                    return _context.stop();
                }
              }
            }, _callee, this);
          }));
        }
      }, {
        key: "loadSupplyDetails",
        value: function loadSupplyDetails() {
          return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee2() {
            var data;
            return regeneratorRuntime.wrap(function _callee2$(_context2) {
              while (1) {
                switch (_context2.prev = _context2.next) {
                  case 0:
                    _context2.next = 2;
                    return this.matService.getMatSupplyDetails(this.supplyId);

                  case 2:
                    data = _context2.sent;
                    return _context2.abrupt("return", data);

                  case 4:
                  case "end":
                    return _context2.stop();
                }
              }
            }, _callee2, this);
          }));
        }
      }, {
        key: "viewSupplyPlan",
        value: function viewSupplyPlan(planId) {
          this.router.navigate(['../plan/detail'], {
            relativeTo: this.activeRoute,
            queryParams: {
              planId: planId
            }
          });
        }
      }, {
        key: "copyMatSupplyNumber",
        value: function copyMatSupplyNumber(matSupplyPlanNumber) {
          this.supplyList.copyMatSupplyPlanNumber(matSupplyPlanNumber);
        }
      }, {
        key: "copyGoodsName",
        value: function copyGoodsName(goodsName) {
          this.nativeUtils.copyToClipboard(goodsName);
        }
      }]);

      return SupplyDetailPage;
    }();

    SupplyDetailPage.ctorParameters = function () {
      return [{
        type: _angular_router__WEBPACK_IMPORTED_MODULE_3__["ActivatedRoute"]
      }, {
        type: _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"]
      }, {
        type: _components_index__WEBPACK_IMPORTED_MODULE_4__["CommonUtils"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["NavController"]
      }, {
        type: _service_index__WEBPACK_IMPORTED_MODULE_5__["MatService"]
      }, {
        type: _components_index__WEBPACK_IMPORTED_MODULE_4__["NativeUtils"]
      }, {
        type: _supply_list_supply_list_page__WEBPACK_IMPORTED_MODULE_6__["SupplyListPage"]
      }];
    };

    SupplyDetailPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-supply-detail',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./supply-detail.page.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/supply-detail/supply-detail.page.html")).default,
      providers: [_service_index__WEBPACK_IMPORTED_MODULE_5__["MatService"], _supply_list_supply_list_page__WEBPACK_IMPORTED_MODULE_6__["SupplyListPage"]],
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./supply-detail.page.scss */
      "./src/app/pages/supply-detail/supply-detail.page.scss")).default]
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_3__["ActivatedRoute"], _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"], _components_index__WEBPACK_IMPORTED_MODULE_4__["CommonUtils"], _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["NavController"], _service_index__WEBPACK_IMPORTED_MODULE_5__["MatService"], _components_index__WEBPACK_IMPORTED_MODULE_4__["NativeUtils"], _supply_list_supply_list_page__WEBPACK_IMPORTED_MODULE_6__["SupplyListPage"]])], SupplyDetailPage);
    /***/
  }
}]);
//# sourceMappingURL=supply-detail-supply-detail-module-es5.js.map