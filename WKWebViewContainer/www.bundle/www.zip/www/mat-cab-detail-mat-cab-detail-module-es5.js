function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["mat-cab-detail-mat-cab-detail-module"], {
  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/mat-cab-detail/mat-cab-detail.page.html":
  /*!*****************************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/mat-cab-detail/mat-cab-detail.page.html ***!
    \*****************************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppPagesMatCabDetailMatCabDetailPageHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-header>\n  <ion-toolbar color=\"ysw\">\n    <ion-buttons slot=\"start\">\n      <ion-back-button></ion-back-button>\n    </ion-buttons>\n    <ion-title>柜子详情 - {{matName}}</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <ion-header collapse=\"condense\">\n    <ion-toolbar color=\"ysw\">\n      <ion-title size=\"large\">柜子详情 - {{matName}}</ion-title>\n    </ion-toolbar>\n  </ion-header>\n\n  <skeleton [loading]=\"loading\">\n    <ion-list>\n      <ng-container *ngFor=\"let matCab of cabOrderList\">\n        <ion-card>\n          <ion-card-header (click)=\"matCab.clicked = !matCab.clicked\">\n            <ion-card-title class=\"flex ion-justify-content-between ion-align-items-center m-b-5\">\n              <div style=\"width: 100%;\">\n                <div class=\"flex ion-justify-content-between ion-align-items-center\">\n                  <div class=\"cab-name\">取货柜编号:{{' ' + matCab.cellName}}</div>\n                  <ion-badge *ngIf=\"matCab.orderStatusCode\" [color]=\"genStatusColor(matCab.orderStatusCode)\" style=\"flex-shrink: 0;\">{{matCab.orderStatusName}}</ion-badge>\n                  <ion-badge *ngIf=\"!matCab.orderStatusCode\" color=\"success\" style=\"flex-shrink: 0;\">空闲中</ion-badge>\n                </div>\n\n                <ng-container *ngIf=\"matCab.ipOrderNo; else noOrder\">\n                  <div class=\"flex ion-justify-content-between ion-align-items-center m-b-5 m-t-10\">\n                    <div class=\"cab-order\">已关联订单:<ion-label>{{' ' + matCab.ipOrderNo}}</ion-label></div>\n                    <ion-icon [name]=\"matCab.clicked ? 'chevron-up' : 'chevron-down'\" style=\"flex-shrink: 0;\"></ion-icon>\n                  </div>\n                </ng-container>\n                <ng-template #noOrder>\n                  <div class=\"flex ion-justify-content-center ion-align-items-center m-t-10\">\n                    <ion-button style=\"height: 32px;margin-right: 10px;\" (click)=\"openCabCell(matCab)\" size=\"small\" fill=\"solid\" color=\"ysw\">\n                      打开格子\n                    </ion-button>\n\n                    <ion-button style=\"height: 32px;\" (click)=\"onChooseOrder(matCab)\" size=\"small\" fill=\"solid\" color=\"ysw\">\n                      关联订单\n                    </ion-button>\n                  </div>\n                </ng-template>\n              </div>\n            </ion-card-title>\n          </ion-card-header>\n          <ion-card-content *ngIf=\"matCab.ipOrderNo && matCab.clicked\">\n            <ng-container *ngFor=\"let goods of matCab.goodsInfo\">\n              <div (click)=\"viewOrder(matCab)\"\n                class=\"flex ion-justify-content-start ion-align-items-center cab-goods\">\n                <ion-img (ionError)=\"imageError($event)\" style=\"flex-shrink: 0;width:80px;\"\n                  [src]=\"goods.goodsThumb || 'assets/imgs/mat/goods-no-image.svg'\" [alt]=\"goods.goodsName\"></ion-img>\n                <div style=\"width:100%;\">\n                  <div class=\"text-right\">{{goods.brandName || ''}}{{' ' + goods.goodsName}}</div>\n                  <div class=\"text-right text-small\">{{goods.goodsPackage}}</div>\n                  <div class=\"text-right\">{{'x ' + goods.quantity}}</div>\n                </div>\n              </div>\n            </ng-container>\n          </ion-card-content>\n        </ion-card>\n      </ng-container>\n    </ion-list>\n\n    <empty-view [data]=\"cabOrderList\" message=\"暂无售药机格子柜~\">\n      <empty-content></empty-content>\n    </empty-view>\n  </skeleton>\n</ion-content>";
    /***/
  },

  /***/
  "./src/app/pages/mat-cab-detail/mat-cab-detail.module.ts":
  /*!***************************************************************!*\
    !*** ./src/app/pages/mat-cab-detail/mat-cab-detail.module.ts ***!
    \***************************************************************/

  /*! exports provided: MatCabDetailPageModule */

  /***/
  function srcAppPagesMatCabDetailMatCabDetailModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "MatCabDetailPageModule", function () {
      return MatCabDetailPageModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/fesm2015/common.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/fesm2015/forms.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
    /* harmony import */


    var _guard_login_guard_guard__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ../../guard/login-guard.guard */
    "./src/app/guard/login-guard.guard.ts");
    /* harmony import */


    var _mat_cab_detail_page__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
    /*! ./mat-cab-detail.page */
    "./src/app/pages/mat-cab-detail/mat-cab-detail.page.ts");
    /* harmony import */


    var _module_index__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(
    /*! ../module/index */
    "./src/app/pages/module/index.ts");

    var MatCabDetailPageModule = function MatCabDetailPageModule() {
      _classCallCheck(this, MatCabDetailPageModule);
    };

    MatCabDetailPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"], _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild([{
        path: '',
        component: _mat_cab_detail_page__WEBPACK_IMPORTED_MODULE_7__["MatCabDetailPage"]
      }, {
        path: 'order',
        loadChildren: function loadChildren() {
          return Promise.all(
          /*! import() | order-list-order-list-module */
          [__webpack_require__.e("default~order-detail-order-detail-module~order-list-order-list-module"), __webpack_require__.e("order-list-order-list-module")]).then(__webpack_require__.bind(null,
          /*! ../order-list/order-list.module */
          "./src/app/pages/order-list/order-list.module.ts")).then(function (m) {
            return m.OrderListPageModule;
          });
        },
        canActivate: [_guard_login_guard_guard__WEBPACK_IMPORTED_MODULE_6__["LoginGuardGuard"]]
      }]), _module_index__WEBPACK_IMPORTED_MODULE_8__["EmptyModule"], _module_index__WEBPACK_IMPORTED_MODULE_8__["SkeletonModule"]],
      declarations: [_mat_cab_detail_page__WEBPACK_IMPORTED_MODULE_7__["MatCabDetailPage"]]
    })], MatCabDetailPageModule);
    /***/
  },

  /***/
  "./src/app/pages/mat-cab-detail/mat-cab-detail.page.scss":
  /*!***************************************************************!*\
    !*** ./src/app/pages/mat-cab-detail/mat-cab-detail.page.scss ***!
    \***************************************************************/

  /*! exports provided: default */

  /***/
  function srcAppPagesMatCabDetailMatCabDetailPageScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "ion-icon + ion-label {\n  margin-left: 6px;\n}\n\nion-card-title ion-label {\n  font-size: 0.6em;\n}\n\nion-card-content ion-badge {\n  margin-left: 5px;\n}\n\nion-card-title ion-icon {\n  margin-left: 5px;\n  font-size: 0.6em;\n}\n\nion-card-content ion-label {\n  font-size: 13px;\n}\n\n.cab-name {\n  font-size: 0.6em;\n  color: var(--ion-color-dark-tint);\n}\n\n.cab-order {\n  font-size: 0.6em;\n  color: var(--ion-color-dark-tint);\n}\n\n.cab-order ion-label {\n  font-size: 0.9em;\n  color: var(--ion-color-dark);\n}\n\n.color-mute {\n  color: var(--ion-color-medium-tint);\n}\n\n.cab-status-time-info {\n  font-size: 0.6em;\n  color: var(--ion-color-medium-tint);\n}\n\n.cab-status-time-info ion-label + ion-label {\n  margin-left: 10px;\n}\n\n.cab-goods + .cab-goods {\n  border-top: 0.55px solid var(--ion-color-light);\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Vc2Vycy9jaGFubmluZy9EZXNrdG9wL3lzdy1hcHAtc2VydmljZTQvc3JjL2FwcC9wYWdlcy9tYXQtY2FiLWRldGFpbC9tYXQtY2FiLWRldGFpbC5wYWdlLnNjc3MiLCJzcmMvYXBwL3BhZ2VzL21hdC1jYWItZGV0YWlsL21hdC1jYWItZGV0YWlsLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLGdCQUFBO0FDQ0Y7O0FERUE7RUFDRSxnQkFBQTtBQ0NGOztBREVBO0VBQ0UsZ0JBQUE7QUNDRjs7QURFQTtFQUNFLGdCQUFBO0VBQ0EsZ0JBQUE7QUNDRjs7QURFQTtFQUNFLGVBQUE7QUNDRjs7QURFQTtFQUNFLGdCQUFBO0VBQ0EsaUNBQUE7QUNDRjs7QURDQTtFQUNFLGdCQUFBO0VBQ0EsaUNBQUE7QUNFRjs7QURBRTtFQUNFLGdCQUFBO0VBQ0EsNEJBQUE7QUNFSjs7QURDQTtFQUNFLG1DQUFBO0FDRUY7O0FEQUE7RUFDRSxnQkFBQTtFQUNBLG1DQUFBO0FDR0Y7O0FEREU7RUFDRSxpQkFBQTtBQ0dKOztBREFBO0VBQ0UsK0NBQUE7QUNHRiIsImZpbGUiOiJzcmMvYXBwL3BhZ2VzL21hdC1jYWItZGV0YWlsL21hdC1jYWItZGV0YWlsLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbImlvbi1pY29uICsgaW9uLWxhYmVsIHtcbiAgbWFyZ2luLWxlZnQ6IDZweDtcbn1cblxuaW9uLWNhcmQtdGl0bGUgaW9uLWxhYmVsIHtcbiAgZm9udC1zaXplOiAwLjZlbTtcbn1cblxuaW9uLWNhcmQtY29udGVudCBpb24tYmFkZ2Uge1xuICBtYXJnaW4tbGVmdDogNXB4O1xufVxuXG5pb24tY2FyZC10aXRsZSBpb24taWNvbiB7XG4gIG1hcmdpbi1sZWZ0OiA1cHg7XG4gIGZvbnQtc2l6ZTogMC42ZW07XG59XG5cbmlvbi1jYXJkLWNvbnRlbnQgaW9uLWxhYmVsIHtcbiAgZm9udC1zaXplOiAxM3B4O1xufVxuXG4uY2FiLW5hbWUge1xuICBmb250LXNpemU6IDAuNmVtO1xuICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLWRhcmstdGludCk7XG59XG4uY2FiLW9yZGVyIHtcbiAgZm9udC1zaXplOiAwLjZlbTtcbiAgY29sb3I6IHZhcigtLWlvbi1jb2xvci1kYXJrLXRpbnQpO1xuXG4gIGlvbi1sYWJlbCB7XG4gICAgZm9udC1zaXplOiAwLjllbTtcbiAgICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLWRhcmspO1xuICB9XG59XG4uY29sb3ItbXV0ZSB7XG4gIGNvbG9yOiB2YXIoLS1pb24tY29sb3ItbWVkaXVtLXRpbnQpO1xufVxuLmNhYi1zdGF0dXMtdGltZS1pbmZvIHtcbiAgZm9udC1zaXplOiAwLjZlbTtcbiAgY29sb3I6IHZhcigtLWlvbi1jb2xvci1tZWRpdW0tdGludCk7XG5cbiAgaW9uLWxhYmVsICsgaW9uLWxhYmVsIHtcbiAgICBtYXJnaW4tbGVmdDogMTBweDtcbiAgfVxufVxuLmNhYi1nb29kcyArIC5jYWItZ29vZHMge1xuICBib3JkZXItdG9wOiAwLjU1cHggc29saWQgdmFyKC0taW9uLWNvbG9yLWxpZ2h0KTtcbn1cbiIsImlvbi1pY29uICsgaW9uLWxhYmVsIHtcbiAgbWFyZ2luLWxlZnQ6IDZweDtcbn1cblxuaW9uLWNhcmQtdGl0bGUgaW9uLWxhYmVsIHtcbiAgZm9udC1zaXplOiAwLjZlbTtcbn1cblxuaW9uLWNhcmQtY29udGVudCBpb24tYmFkZ2Uge1xuICBtYXJnaW4tbGVmdDogNXB4O1xufVxuXG5pb24tY2FyZC10aXRsZSBpb24taWNvbiB7XG4gIG1hcmdpbi1sZWZ0OiA1cHg7XG4gIGZvbnQtc2l6ZTogMC42ZW07XG59XG5cbmlvbi1jYXJkLWNvbnRlbnQgaW9uLWxhYmVsIHtcbiAgZm9udC1zaXplOiAxM3B4O1xufVxuXG4uY2FiLW5hbWUge1xuICBmb250LXNpemU6IDAuNmVtO1xuICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLWRhcmstdGludCk7XG59XG5cbi5jYWItb3JkZXIge1xuICBmb250LXNpemU6IDAuNmVtO1xuICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLWRhcmstdGludCk7XG59XG4uY2FiLW9yZGVyIGlvbi1sYWJlbCB7XG4gIGZvbnQtc2l6ZTogMC45ZW07XG4gIGNvbG9yOiB2YXIoLS1pb24tY29sb3ItZGFyayk7XG59XG5cbi5jb2xvci1tdXRlIHtcbiAgY29sb3I6IHZhcigtLWlvbi1jb2xvci1tZWRpdW0tdGludCk7XG59XG5cbi5jYWItc3RhdHVzLXRpbWUtaW5mbyB7XG4gIGZvbnQtc2l6ZTogMC42ZW07XG4gIGNvbG9yOiB2YXIoLS1pb24tY29sb3ItbWVkaXVtLXRpbnQpO1xufVxuLmNhYi1zdGF0dXMtdGltZS1pbmZvIGlvbi1sYWJlbCArIGlvbi1sYWJlbCB7XG4gIG1hcmdpbi1sZWZ0OiAxMHB4O1xufVxuXG4uY2FiLWdvb2RzICsgLmNhYi1nb29kcyB7XG4gIGJvcmRlci10b3A6IDAuNTVweCBzb2xpZCB2YXIoLS1pb24tY29sb3ItbGlnaHQpO1xufSJdfQ== */";
    /***/
  },

  /***/
  "./src/app/pages/mat-cab-detail/mat-cab-detail.page.ts":
  /*!*************************************************************!*\
    !*** ./src/app/pages/mat-cab-detail/mat-cab-detail.page.ts ***!
    \*************************************************************/

  /*! exports provided: MatCabDetailPage */

  /***/
  function srcAppPagesMatCabDetailMatCabDetailPageTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "MatCabDetailPage", function () {
      return MatCabDetailPage;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");
    /* harmony import */


    var _service_mat_cab_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ../../service/mat.cab.service */
    "./src/app/service/mat.cab.service.ts");
    /* harmony import */


    var _components_index__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! ../../components/index */
    "./src/app/components/index.ts");
    /* harmony import */


    var _modal_order_select_order_select_page__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ../modal/order-select/order-select.page */
    "./src/app/pages/modal/order-select/order-select.page.ts");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");

    var MatCabDetailPage = /*#__PURE__*/function () {
      function MatCabDetailPage(activeRoute, commonUtils, matCabService, router, modalCtrl) {
        var _this = this;

        _classCallCheck(this, MatCabDetailPage);

        this.activeRoute = activeRoute;
        this.commonUtils = commonUtils;
        this.matCabService = matCabService;
        this.router = router;
        this.modalCtrl = modalCtrl;
        this.cabOrderList = [];
        this.loading = true;
        this.activeRoute.queryParams.subscribe(function (params) {
          _this.cabId = params.cabId;
          _this.matId = params.matId;
          _this.matName = Base64.decode(params.matName);
        });
      }

      _createClass(MatCabDetailPage, [{
        key: "ngOnInit",
        value: function ngOnInit() {
          return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
            return regeneratorRuntime.wrap(function _callee$(_context) {
              while (1) {
                switch (_context.prev = _context.next) {
                  case 0:
                    _context.next = 2;
                    return this.loadMatCabOrderList();

                  case 2:
                    this.cabOrderList = _context.sent;
                    this.loading = false;

                  case 4:
                  case "end":
                    return _context.stop();
                }
              }
            }, _callee, this);
          }));
        }
      }, {
        key: "loadMatCabOrderList",
        value: function loadMatCabOrderList() {
          return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee2() {
            var data;
            return regeneratorRuntime.wrap(function _callee2$(_context2) {
              while (1) {
                switch (_context2.prev = _context2.next) {
                  case 0:
                    if (!this.commonUtils.isNull(this.cabId)) {
                      _context2.next = 3;
                      break;
                    }

                    this.commonUtils.showToast('格子柜Id丢失！');
                    return _context2.abrupt("return");

                  case 3:
                    _context2.next = 5;
                    return this.matCabService.getMatCabOrderList(this.cabId);

                  case 5:
                    data = _context2.sent;
                    return _context2.abrupt("return", data);

                  case 7:
                  case "end":
                    return _context2.stop();
                }
              }
            }, _callee2, this);
          }));
        }
      }, {
        key: "openCabCell",
        value: function openCabCell(cell) {
          return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee3() {
            var data;
            return regeneratorRuntime.wrap(function _callee3$(_context3) {
              while (1) {
                switch (_context3.prev = _context3.next) {
                  case 0:
                    _context3.next = 2;
                    return this.commonUtils.showConfirm('温馨提示', '确定要打开：' + cell.cellName + '号格子？');

                  case 2:
                    if (!_context3.sent) {
                      _context3.next = 7;
                      break;
                    }

                    _context3.next = 5;
                    return this.matCabService.openMatCabCell(this.matId, this.cabId, cell.cabCellId);

                  case 5:
                    data = _context3.sent;

                    if (data.success) {
                      this.commonUtils.showToast('打开成功！');
                    } else {
                      this.commonUtils.showToast(data.message);
                    }

                  case 7:
                  case "end":
                    return _context3.stop();
                }
              }
            }, _callee3, this);
          }));
        }
      }, {
        key: "onChooseOrder",
        value: function onChooseOrder(cell) {
          return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee4() {
            var modal, _ref, data, result;

            return regeneratorRuntime.wrap(function _callee4$(_context4) {
              while (1) {
                switch (_context4.prev = _context4.next) {
                  case 0:
                    _context4.next = 2;
                    return this.modalCtrl.create({
                      component: _modal_order_select_order_select_page__WEBPACK_IMPORTED_MODULE_5__["OrderSelectPage"],
                      componentProps: {
                        matId: this.matId,
                        orderStatus: '30,40'
                      },
                      cssClass: 'ysw-common-modal-vertical',
                      swipeToClose: true
                    });

                  case 2:
                    modal = _context4.sent;
                    _context4.next = 5;
                    return modal.present();

                  case 5:
                    _context4.next = 7;
                    return modal.onWillDismiss();

                  case 7:
                    _ref = _context4.sent;
                    data = _ref.data;

                    if (this.commonUtils.isNull(data)) {
                      _context4.next = 19;
                      break;
                    }

                    _context4.next = 12;
                    return this.commonUtils.showConfirm('温馨提示', '确定该订单商品已经放入' + cell.cellName + '号格子且已经关闭格子？');

                  case 12:
                    if (!_context4.sent) {
                      _context4.next = 19;
                      break;
                    }

                    _context4.next = 15;
                    return this.matCabService.linkMatCabOrder(cell.cabId, cell.cabCellId, data.orderId, data.orderNumber);

                  case 15:
                    result = _context4.sent;
                    _context4.next = 18;
                    return this.loadMatCabOrderList();

                  case 18:
                    this.cabOrderList = _context4.sent;

                  case 19:
                  case "end":
                    return _context4.stop();
                }
              }
            }, _callee4, this);
          }));
        }
      }, {
        key: "viewOrder",
        value: function viewOrder(matCab) {
          this.router.navigate(['../order/detail'], {
            relativeTo: this.activeRoute,
            queryParams: {
              orderId: Base64.encode(JSON.stringify(matCab.orderId))
            }
          });
        }
      }, {
        key: "imageError",
        value: function imageError(event) {
          event.target.src = 'assets/imgs/mat/goods-no-image.svg';
        }
      }, {
        key: "genStatusColor",
        value: function genStatusColor(status) {
          var statusColor = '';

          switch (status) {
            case 52:
            case 55:
            case 54:
              statusColor = 'success';
              break;

            case 30:
            case 40:
            case 42:
              statusColor = 'primary';
              break;

            case 41:
            case -19:
            case -21:
              statusColor = 'warning';
              break;

            case -23:
              statusColor = 'info';
              break;

            case -22:
            case -12:
              statusColor = 'danger';
              break;

            case -10:
            case -11:
            case -13:
              statusColor = 'dark';
              break;

            default:
              return '';
          }

          return statusColor;
        }
      }]);

      return MatCabDetailPage;
    }();

    MatCabDetailPage.ctorParameters = function () {
      return [{
        type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"]
      }, {
        type: _components_index__WEBPACK_IMPORTED_MODULE_4__["CommonUtils"]
      }, {
        type: _service_mat_cab_service__WEBPACK_IMPORTED_MODULE_3__["MatCabService"]
      }, {
        type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["ModalController"]
      }];
    };

    MatCabDetailPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-mat-cab-detail',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./mat-cab-detail.page.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/mat-cab-detail/mat-cab-detail.page.html")).default,
      providers: [_service_mat_cab_service__WEBPACK_IMPORTED_MODULE_3__["MatCabService"]],
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./mat-cab-detail.page.scss */
      "./src/app/pages/mat-cab-detail/mat-cab-detail.page.scss")).default]
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"], _components_index__WEBPACK_IMPORTED_MODULE_4__["CommonUtils"], _service_mat_cab_service__WEBPACK_IMPORTED_MODULE_3__["MatCabService"], _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"], _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["ModalController"]])], MatCabDetailPage);
    /***/
  }
}]);
//# sourceMappingURL=mat-cab-detail-mat-cab-detail-module-es5.js.map